/*
 * adc_driver.c
 *
 *  Created on: 2017/07/27
 *      Author: D-CLUE
 */

#include "em_cmu.h"
#include "em_adc.h"
#include "em_gpio.h"

#include "adc_driver.h"
#include "main.h"

#if defined (HARDWARE_ASICS)
const uint32_t ADC_CH_TABLE[2] = {
	adcPosSelAPORT2XCH11, // REF VOLTAGE PC11
	adcPosSelAPORT2XCH21, // BATTERY VOLTAGE PF5
};
#else
const uint32_t ADC_CH_TABLE[5] = {
	adcPosSelAPORT3XCH2,  // EMG CH1
    adcPosSelAPORT4XCH3,  // EMG CH2
    adcPosSelAPORT3XCH4,  // EMG CH3
    adcPosSelAPORT4XCH5,  // EMG CH4
	adcPosSelAPORT2XCH21, // Battery
};
#endif

void adc_driver_init(void)
{
	CMU_ClockEnable(cmuClock_ADC0, true);

	ADC_Init_TypeDef init = {
	    .ovsRateSel =   adcOvsRateSel2,
#if defined( _ADC_CTRL_LPFMODE_MASK )
	  /** Lowpass or decoupling capacitor filter to use. */
	    .lpfMode;
#endif
	    .warmUpMode = adcWarmupNormal,
	    .timebase = _ADC_CTRL_TIMEBASE_DEFAULT,
	    .prescale = _ADC_CTRL_PRESC_DEFAULT,
	    .tailgate = false,
#if defined( _ADC_CTRL_ADCCLKMODE_MASK )
	    .em2ClockConfig = adcEm2Disabled,
#endif
	};

    ADC_InitSingle_TypeDef singleInit = {
	    .prsSel = adcPRSSELCh0,              /* PRS ch0 (if enabled). */                          \
		.acqTime = adcAcqTime1,              /* 1 ADC_CLK cycle acquisition time. */              \
		.reference = adcRefVDD,              /* 1.25V internal reference. */                      \
		.resolution = adcRes12Bit,           /* 12 bit resolution. */                             \
		.posSel = adcPosSelAPORT2XCH21,      /* Select node BUS0XCH0 as posSel */                 \
		.negSel = adcNegSelVSS,              /* Select VSS as negSel */                           \
		.diff = false,                       /* Single ended input. */                            \
		.prsEnable = false,                  /* PRS disabled. */                                  \
		.leftAdjust = false,                 /* Right adjust. */                                  \
		.rep = false,                        /* Deactivate conversion after one scan sequence. */ \
		.singleDmaEm2Wu = false,             /* No EM2 DMA wakeup from single FIFO DVL */         \
		.fifoOverwrite = false               /* Discard new data on full FIFO. */                 \
	};

	init.timebase = ADC_TimebaseCalc(0);
	init.prescale = ADC_PrescaleCalc(7000000, 0);
	ADC_Init(ADC0, &init);

	singleInit.posSel = adcPosSelAPORT2XCH19;
	ADC_InitSingle(ADC0, &singleInit);

#if defined (HARDWARE_ASICS)
	GPIO_PinModeSet(REF_VOLTAGE_PORT, REF_VOLTAGE_PIN, gpioModeInput, 0);
	GPIO_PinModeSet(BATTERY_VOLTAGE_PORT, BATTERY_VOLTAGE_PIN, gpioModeInput, 0);
#else
	GPIO_PinModeSet(EMG_CH1_PORT, EMG_CH1_PIN, gpioModeInput, 0);
	GPIO_PinModeSet(EMG_CH2_PORT, EMG_CH2_PIN, gpioModeInput, 0);
	GPIO_PinModeSet(EMG_CH3_PORT, EMG_CH3_PIN, gpioModeInput, 0);
	GPIO_PinModeSet(EMG_CH4_PORT, EMG_CH4_PIN, gpioModeInput, 0);
	GPIO_PinModeSet(BATTERY_PORT, BATTERY_PIN, gpioModeInput, 0);
	GPIO_PinModeSet(gpioPortC, 11, gpioModePushPull, 1);
#endif

}

uint32_t adc_driver_read(uint32_t ch)
{
	uint32_t adc_value;

	ADC_InitSingle_TypeDef singleInit = {
	    .prsSel = adcPRSSELCh0,              /* PRS ch0 (if enabled). */                          \
		.acqTime = adcAcqTime1,              /* 1 ADC_CLK cycle acquisition time. */              \
		.reference = adcRefVDD,              /* 1.25V internal reference. */                      \
		.resolution = adcRes12Bit,           /* 12 bit resolution. */                             \
		.posSel = ADC_CH_TABLE[ch],          /* Select node BUS0XCH0 as posSel */                 \
		.negSel = adcNegSelVSS,              /* Select VSS as negSel */                           \
		.diff = false,                       /* Single ended input. */                            \
		.prsEnable = false,                  /* PRS disabled. */                                  \
		.leftAdjust = false,                 /* Right adjust. */                                  \
		.rep = false,                        /* Deactivate conversion after one scan sequence. */ \
		.singleDmaEm2Wu = false,             /* No EM2 DMA wakeup from single FIFO DVL */         \
		.fifoOverwrite = false               /* Discard new data on full FIFO. */                 \
	};
	ADC_InitSingle(ADC0, &singleInit);

	ADC_Start(ADC0, adcStartSingle);
	while (ADC0->STATUS & ADC_STATUS_SINGLEACT);
	adc_value = (ADC_DataSingleGet(ADC0));
	ADC_Start(ADC0, adcStartSingle);
	while (ADC0->STATUS & ADC_STATUS_SINGLEACT);
	adc_value = (ADC_DataSingleGet(ADC0));

	return adc_value;
}
