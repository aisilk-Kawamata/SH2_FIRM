/*
 * adc_driver.h
 *
 *  Created on: 2017/07/27
 *      Author: D-CLUE
 */
#include "main.h"
#ifndef ADC_DRIVER_H_
#define ADC_DRIVER_H_

#define EMG_CH1_PORT    gpioPortD
#define EMG_CH1_PIN     10
#define EMG_CH2_PORT    gpioPortD
#define EMG_CH2_PIN     11
#define EMG_CH3_PORT    gpioPortD
#define EMG_CH3_PIN     12
#define EMG_CH4_PORT    gpioPortD
#define EMG_CH4_PIN     13

#define BATTERY_PORT    gpioPortF
#define BATTERY_PIN     3

#if defined (HARDWARE_ASICS)
	#define BATTERY_VOLTAGE_CH	1
#else
	#define BATTERY_VOLTAGE_CH	4
#endif

#define REF_VOLTAGE_PORT        gpioPortC
#define REF_VOLTAGE_PIN         11
#define BATTERY_VOLTAGE_PORT    gpioPortF
#define BATTERY_VOLTAGE_PIN     5

extern void adc_driver_init(void);
extern uint32_t adc_driver_read(uint32_t ch);

#endif /* ADC_DRIVER_H_ */
