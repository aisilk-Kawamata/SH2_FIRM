/*
 * ecg.c
 *
 *  Created on: 2017/08/08
 *      Author: D-CLUE
 */
#include "em_emu.h"
#include "em_cmu.h"

#include "main.h"

int16_t ecg_rawdata;
uint8_t ecg_hrdata1;
uint8_t ecg_hrdata2;

void ecg_rawdata_set(int16_t data)
{
	ecg_rawdata = data;
}

int16_t ecg_rawdata_get(void)
{
	return ecg_rawdata;
}

void ecg_hrdata1_set(uint8_t data)
{
	ecg_hrdata1 = data;
}

uint8_t ecg_hrdata1_get(void)
{
	return ecg_hrdata1;
}

void ecg_hrdata2_set(uint8_t data)
{
	ecg_hrdata2 = data;
}

uint8_t ecg_hrdata2_get(void)
{
	return ecg_hrdata2;
}
