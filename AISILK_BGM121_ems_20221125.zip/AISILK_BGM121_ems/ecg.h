/*
 * ecg.h
 *
 *  Created on: 2017/08/08
 *      Author: D-CLUE
 */

#ifndef ECG_H_
#define ECG_H_

extern void ecg_rawdata_set(int16_t data);
extern int16_t ecg_rawdata_get(void);
extern void ecg_hrdata1_set(uint8_t data);
extern uint8_t ecg_hrdata1_get(void);
extern void ecg_hrdata2_set(uint8_t data);
extern uint8_t ecg_hrdata2_get(void);

#endif /* ECG_H_ */
