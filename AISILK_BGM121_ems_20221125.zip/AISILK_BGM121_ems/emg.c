

/*
 * emg.c
 *
 *  Created on: 2017/07/28
 *      Author: D-CLUE
 */
/* Bluetooth stack headers */
#include "bg_types.h"
#include "native_gecko.h"
#include "gatt_db.h"

#include "em_emu.h"
#include "em_cmu.h"
#include "em_gpio.h"

#include "main.h"
#include "math.h"
#include "adc_driver.h"
#include "uart_driver.h"
#include "emg.h"
#include "ecg.h"
#include "spi_driver.h"

//#define FILTER_TYPE2                        1 /* 50, 60Hz, 0.2Hz, cheby2 */
#define FILTER_TYPE3                        1 /* 50, 60Hz, 1Hz, cheby2 */
//#define FILTER_TYPE4                        1 /* 50, 60Hz, 2Hz, cheby2 */

#if FILTER_TYPE2
#define IIR_X_NUM (5)
#define IIR_Y_NUM (4)
float coef_a_50[IIR_X_NUM] = {
     0.99376785,
    -3.78051756,
     5.58302149,
    -3.78051756,
     0.99376785,
};
float coef_b_50[IIR_Y_NUM] = {
     0.98757454,
    -3.76870025,
     5.58298265,
    -3.79233488,
};
float coef_a_60[IIR_X_NUM] = {
     0.99376785,
    -3.69592792,
     5.42392247,
    -3.69592792,
     0.99376785,
};
float coef_b_60[IIR_Y_NUM] = {
     0.98757454,
    -3.68437502,
     5.42388363,
    -3.70748082,
};
#endif

#if FILTER_TYPE3
#define IIR_X_NUM (5)
#define IIR_Y_NUM (4)
float coef_a_50[IIR_X_NUM] = {
     0.96922991,
    -3.68716968,
     5.44516475,
    -3.68716968,
     0.96922991,
};
float coef_b_50[IIR_Y_NUM] = {
     0.93940685,
    -3.62954189,
     5.44421772,
    -3.74479748,
};
float coef_a_60[IIR_X_NUM] = {
     0.96922991,
    -3.60466872,
     5.28999344,
    -3.60466872,
     0.96922991,
};
float coef_b_60[IIR_Y_NUM] = {
     0.93940685,
    -3.54833035,
     5.28904641,
    -3.66100708,
};
#endif

#if FILTER_TYPE4
#define IIR_X_NUM (5)
#define IIR_Y_NUM (4)
float coef_a_50[IIR_X_NUM] = {
     0.93943404,
    -3.57381947,
     5.27776529,
    -3.57381947,
     0.93943404,
};
float coef_b_50[IIR_Y_NUM] = {
     0.88253976,
    -3.46210593,
     5.27409362,
    -3.685533,
};
float coef_a_60[IIR_X_NUM] = {
     0.93943404,
    -3.49385473,
     5.127362,
    -3.49385473,
     0.93943404,
};
float coef_b_60[IIR_Y_NUM] = {
     0.88253976,
    -3.3846408,
     5.12369033,
    -3.60306865,
};
#endif

float       iir_x[NUM_SAMPLES][IIR_X_NUM];
float       iir_y[NUM_SAMPLES][IIR_Y_NUM];
float       y[NUM_SAMPLES][300];
uint32_t    y_cnt[NUM_SAMPLES];

bool        Measure_Flag;
bool        Send_Can_Flag;

#define     NUM_ECG_DATA (30)
#define     NUM_ECG_SAMPLE (20)
int16_t     ECG_Data[NUM_SAMPLES][NUM_ECG_DATA];
int16_t     ECG_Send_Data[NUM_SAMPLES][2];
uint32_t    ECG_Data_Cnt;
uint32_t    ECG_Data_Read_Cnt;
bool        ECG_Data_OverFlow;
uint32_t    Analysis_Data_Write_Cnt; // 後解析ログカウンタ
bool        Analysis_Data_OverFlow;  // 後解析ログオーバーフロー
uint64_t    Analysis_Time;
uint32_t    Analysis_Data_Write_Address;
uint32_t    Analysis_Data_Read_Address;

uint8_t     Send_Timing_Cnt;
uint8_t     Send_Data[ATT_DEFAULT_PAYLOAD_LEN];

uint16_t    dbg_cnt = 0;

float lfilter(uint32_t i);
void Save_ECG_Data(int16_t ch1_data, int16_t ch2_data, int16_t ch3_data, int16_t ch4_data);
void Save_Analysis_Data_To_SRAM(int16_t ch1_data, int16_t ch2_data, int16_t ch3_data, int16_t ch4_data);
void emg_data_send(void);

void emg_data_init(void)
{
	Send_Can_Flag = false;
    ECG_Data_Cnt = 0;
    ECG_Data_Read_Cnt = 0;
    ECG_Data_OverFlow = false;
    Analysis_Data_Write_Cnt = 0;
    Analysis_Data_OverFlow = false;

    lfilter_init();

    Send_Timing_Cnt = 1;
}

uint32_t dbg_ad[NUM_SAMPLES];

void emg_data_get(void)
{
    uint32_t ad_ch = 0;
    int32_t  ad_val[NUM_SAMPLES];
    float    ret_notch;
    int16_t  analysis_data[NUM_SAMPLES];
    int16_t  l_ecg_data[NUM_SAMPLES];
    uint32_t dc_offset;

    /* 筋電 or 心電 */
    if (confData[ad_ch].Kind_ECG_EMG == CONF_KIND_EMG) {

    		/* DCオフセットキャンセル処理 */
    		dc_offset = (adc_driver_read(4) / 2);
    		//dc_offset = 0;

		for(ad_ch=0; ad_ch<NUM_SAMPLES; ad_ch++) {
			ad_val[ad_ch] = adc_driver_read(ad_ch) - dc_offset - 621;
			dbg_ad[ad_ch] = ad_val[ad_ch];

			if (confData[ad_ch].Notch_ON_OFF == CONF_NOTCH_ON) {
				for(int j=0; j<(IIR_X_NUM-1); j++) {
					iir_x[ad_ch][j] = iir_x[ad_ch][j + 1];
				}
				iir_x[ad_ch][(IIR_X_NUM-1)] = (float)ad_val[ad_ch];

				// ノッチフィルタ
				ret_notch = lfilter(ad_ch);

				for(int j=0; j<(IIR_Y_NUM-1); j++) {
					iir_y[ad_ch][j] = iir_y[ad_ch][j + 1];
				}
				iir_y[ad_ch][(IIR_Y_NUM-1)] = ret_notch;
			}
			else {
				ret_notch = ad_val[ad_ch];
			}

			// 後解析用
			analysis_data[ad_ch] = (int16_t)ret_notch;

            // RMS(二乗のみ)
            y[ad_ch][y_cnt[ad_ch]++] = (ret_notch * ret_notch);
            if (y_cnt[ad_ch] >= EMG_Tint) {
                y_cnt[ad_ch] = 0;
                if (ad_ch == (NUM_SAMPLES-1)) {
                    Send_Can_Flag = true;
                }
            }
        }
    }
	else {

		ad_ch = 0;
		ad_val[ad_ch] = (int32_t)ecg_rawdata_get();

		if (confData[ad_ch].Notch_ON_OFF == CONF_NOTCH_ON) {
			for(int j=0; j<(IIR_X_NUM-1); j++) {
				iir_x[ad_ch][j] = iir_x[ad_ch][j + 1];
			}
			iir_x[ad_ch][(IIR_X_NUM-1)] = (float)ad_val[ad_ch];

			// ノッチフィルタ
			ret_notch = lfilter(ad_ch);

			for(int j=0; j<(IIR_Y_NUM-1); j++) {
				iir_y[ad_ch][j] = iir_y[ad_ch][j + 1];
			}
			iir_y[ad_ch][(IIR_Y_NUM-1)] = ret_notch;
		}
		else {
			ret_notch = ad_val[ad_ch];
		}

		// 後解析用
		analysis_data[ad_ch] = (int16_t)ret_notch;

		y[ad_ch][y_cnt[ad_ch]++] = ret_notch;
		if (y_cnt[ad_ch] >= (ECG_Tav + 10)) {
			y_cnt[ad_ch] = 0;
			//if (ad_ch == (NUM_SAMPLES-1)) {
				Send_Can_Flag = true;
			//}
		}
		l_ecg_data[ad_ch] = (int16_t)ret_notch;
		l_ecg_data[1] = 0;
		l_ecg_data[2] = 0;
		l_ecg_data[3] = 0;

		Save_ECG_Data(
	    			l_ecg_data[0],
				l_ecg_data[1],
				l_ecg_data[2],
				l_ecg_data[3]);
	}

    // 後解析用
    Save_Analysis_Data_To_SRAM(
        analysis_data[0],
        analysis_data[1],
        analysis_data[2],
        analysis_data[3]);

    if (Send_Timing_Cnt < 20) {
    	    Send_Timing_Cnt++;

    	    if (Send_Timing_Cnt == 10) {
    	      if (CLed_Req_Flag == true) {
    	    	  	CLed_Req_Flag = false;
    	    		disp_led_strong();
    	      }
    	    }
    }
    else {
    		Send_Timing_Cnt = 1;
    		if (Send_Can_Flag == true) {
    			emg_data_send();
    		}
    }
}

void lfilter_init(void)
{
    for (int ad_ch=0; ad_ch<NUM_SAMPLES; ad_ch++) {
        for (int j=0; j<IIR_X_NUM; j++){ iir_x[ad_ch][j] = 0; }
        for (int j=0; j<IIR_Y_NUM; j++){ iir_y[ad_ch][j] = 0; }
        for (int j=0; j<300; j++){ y[ad_ch][j] = 0; }
        y_cnt[ad_ch] = 0;
        Analysis_Data_Write_Cnt = 0;
        Analysis_Data_OverFlow = false;
    }
    //dbg_time_s_cnt = 0;
    dbg_cnt = 1;
}

float lfilter(uint32_t i)
{
    float sum_a = 0;
    float sum_b = 0;

    for (int j=0; j<IIR_X_NUM; j++) {
        if (confData[i].Notch_Fc == CONF_NOTCH_FC_50) {
            sum_a += coef_a_50[j] * iir_x[i][j];
        }
        else {
            sum_a += coef_a_60[j] * iir_x[i][j];
        }
    }

    for (int j=0; j<IIR_Y_NUM; j++)
    {
        if (confData[i].Notch_Fc == CONF_NOTCH_FC_50) {
            sum_b += coef_b_50[j] * iir_y[i][j];
        }
        else {
            sum_b += coef_b_60[j] * iir_y[i][j];
        }
    }
    return (sum_a - sum_b);
}

void Save_ECG_Data(int16_t ch1_data, int16_t ch2_data, int16_t ch3_data, int16_t ch4_data)
{
    ECG_Data[0][ECG_Data_Cnt] = ch1_data;
    ECG_Data[1][ECG_Data_Cnt] = ch2_data;
    ECG_Data[2][ECG_Data_Cnt] = ch3_data;
    ECG_Data[3][ECG_Data_Cnt] = ch4_data;

    if (ECG_Data_Cnt < (NUM_ECG_DATA-1)) {
        ECG_Data_Cnt++;
    }
    else {
        ECG_Data_Cnt = 0;
        ECG_Data_OverFlow = true;
    }
}

void Read_ECG_Data(void)
{
  int ad_ch;
  int j;
  int32_t data;

  for(ad_ch=0; ad_ch<NUM_SAMPLES; ad_ch++)
  {
    ECG_Send_Data[ad_ch][0] = 0;
    ECG_Send_Data[ad_ch][1] = 0;
  }

  ECG_Data_Read_Cnt = ECG_Data_Cnt;
  /* 前半20/40msの心電情報 */
  for(j=0; j<ECG_Tav; j++)
  {
    ECG_Send_Data[0][0] = ECG_Data[0][ECG_Data_Read_Cnt];
    ECG_Send_Data[1][0] = ECG_Data[1][ECG_Data_Read_Cnt];
    ECG_Send_Data[2][0] = ECG_Data[2][ECG_Data_Read_Cnt];
    ECG_Send_Data[3][0] = ECG_Data[3][ECG_Data_Read_Cnt];
    if (ECG_Data_Read_Cnt >= (NUM_ECG_DATA - 1)) {
      ECG_Data_Read_Cnt = 0;
    }
    else {
      ECG_Data_Read_Cnt++;
    }
  }
  data = (int32_t)((float)(ECG_Send_Data[0][0] / NUM_ECG_SAMPLE) * (float)confData[0].Digital_Gain);
  if (data > 32767) { data = 32767; }
  else if (data < -32768) { data = -32768; }
  ECG_Send_Data[0][0] = (int16_t)(data);

  data = (int32_t)((float)(ECG_Send_Data[1][0] / NUM_ECG_SAMPLE) * (float)confData[1].Digital_Gain);
  if (data > 32767) { data = 32767; }
  else if (data < -32768) { data = -32768; }
  ECG_Send_Data[1][0] = (int16_t)(data);

  data = (int32_t)((float)(ECG_Send_Data[2][0] / NUM_ECG_SAMPLE) * (float)confData[2].Digital_Gain);
  if (data > 32767) { data = 32767; }
  else if (data < -32768) { data = -32768; }
  ECG_Send_Data[2][0] = (int16_t)(data);

  data = (int32_t)((float)(ECG_Send_Data[3][0] / NUM_ECG_SAMPLE) * (float)confData[3].Digital_Gain);
  if (data > 32767) { data = 32767; }
  else if (data < -32768) { data = -32768; }
  ECG_Send_Data[3][0] = (int16_t)(data);

  ECG_Data_Read_Cnt = ECG_Data_Cnt + 10;
  if (ECG_Data_Read_Cnt > NUM_ECG_DATA) {
    ECG_Data_Read_Cnt = ECG_Data_Read_Cnt - NUM_ECG_DATA;
  }

  /* 後半20/40msの心電情報 */
  for(j=0; j<ECG_Tav; j++)
  {
    ECG_Send_Data[0][1] = ECG_Data[0][ECG_Data_Read_Cnt];
    ECG_Send_Data[1][1] = ECG_Data[1][ECG_Data_Read_Cnt];
    ECG_Send_Data[2][1] = ECG_Data[2][ECG_Data_Read_Cnt];
    ECG_Send_Data[3][1] = ECG_Data[3][ECG_Data_Read_Cnt];
    if (ECG_Data_Read_Cnt >= (NUM_ECG_DATA - 1)) {
      ECG_Data_Read_Cnt = 0;
    }
    else {
      ECG_Data_Read_Cnt++;
    }
  }
  data = (int32_t)((float)(ECG_Send_Data[0][1] / NUM_ECG_SAMPLE) * (float)confData[0].Digital_Gain);
  if (data > 32767) { data = 32767; }
  else if (data < -32768) { data = -32768; }
  ECG_Send_Data[0][1] = (int16_t)(data);

  data = (int32_t)((float)(ECG_Send_Data[1][1] / NUM_ECG_SAMPLE) * (float)confData[1].Digital_Gain);
  if (data > 32767) { data = 32767; }
  else if (data < -32768) { data = -32768; }
  ECG_Send_Data[1][1] = (int16_t)(data);

  data = (int32_t)((float)(ECG_Send_Data[2][1] / NUM_ECG_SAMPLE) * (float)confData[2].Digital_Gain);
  if (data > 32767) { data = 32767; }
  else if (data < -32768) { data = -32768; }
  ECG_Send_Data[2][1] = (int16_t)(data);

  data = (int32_t)((float)(ECG_Send_Data[3][1] / NUM_ECG_SAMPLE) * (float)confData[3].Digital_Gain);
  if (data > 32767) { data = 32767; }
  else if (data < -32768) { data = -32768; }
  ECG_Send_Data[3][1] = (int16_t)(data);
}

void Save_Analysis_Data_To_SRAM(int16_t ch1_data, int16_t ch2_data, int16_t ch3_data, int16_t ch4_data)
{
    //SRAM_Write_Data(Analysis_Data_Write_Address, ch1_data);
    Analysis_Data_Write_Address += 2;
    //SRAM_Write_Data(Analysis_Data_Write_Address, ch2_data);
    Analysis_Data_Write_Address += 2;
    //SRAM_Write_Data(Analysis_Data_Write_Address, ch3_data);
    Analysis_Data_Write_Address += 2;
    //SRAM_Write_Data(Analysis_Data_Write_Address, ch4_data);
    Analysis_Data_Write_Address += 2;

    if (Analysis_Data_Write_Address >= ANALYSIS_MAX_ADDRESS) {
        Analysis_Data_OverFlow = true;
        Analysis_Data_Write_Address = 0x00000000;
    }
    Analysis_Data_Write_Cnt++;
}

void Read_Analysis_Data_init_From_SRAM(void)
{
    if (Analysis_Data_OverFlow == true) {
        Analysis_Time = Sync_Time - NUM_ANALYSIS_DATA;
        Analysis_Data_Read_Address = Analysis_Data_Write_Address;
        dbg_cnt = 1;
    }
    else {
        Analysis_Time = Sync_Time - Analysis_Data_Write_Cnt;
        Analysis_Data_Read_Address = 0x00000000;
        dbg_cnt = 1;
    }
}

void emg_data_send(void)
{
	uint32_t i;
	float y_sum;
	uint64_t Sensor_Time = Sync_Time - (HR_SEND_TIMEOUT / 2);
	uint64_t Sensor_Time_ECG1;
	uint64_t Sensor_Time_ECG2;
	int16_t data[NUM_SAMPLES];
	int32_t data1;
	float f_emg_data;

	for (i=0; i<ATT_DEFAULT_PAYLOAD_LEN; i++) {
		Send_Data[i] = 0;
	}

	if (confData[0].Kind_ECG_EMG == CONF_KIND_EMG) {
		/************/
		/* 筋電情報 */
		/************/
		for(i=0; i<NUM_SAMPLES; i++)
		{
			y_sum = 0;
			// RMS(平均平方根)
			for (int j=0; j<EMG_Tint; j++)
			{
				y_sum += y[i][j];
			}
			f_emg_data = (sqrt((y_sum/EMG_Tint)));

			data1 = (int32_t)((float)f_emg_data * (float)confData[i].Digital_Gain);
			if (data1 > 32767) { data1 = 32767; }
			else if (data1 < -32768) { data1 = -32768; }
			data[i] = (int16_t)data1;
		}

		Send_Data[0] = ATT_DEFAULT_PAYLOAD_LEN;
		Send_Data[1] = REPORT_DATA;
		Send_Data[2] = ((uint64_t)Sensor_Time >> 40);
		Send_Data[3] = ((uint64_t)Sensor_Time >> 32);
		Send_Data[4] = ((uint64_t)Sensor_Time >> 24);
		Send_Data[5] = ((uint64_t)Sensor_Time >> 16);
		Send_Data[6] = ((uint64_t)Sensor_Time >>	 8);
		Send_Data[7] = ((uint64_t)Sensor_Time >>	 0);
		Send_Data[8] = (data[0] >> 8) & 0xFF;
		Send_Data[9] = (data[0] >> 0) & 0xFF;
		Send_Data[10] = (data[1] >> 8) & 0xFF;
		Send_Data[11] = (data[1] >> 0) & 0xFF;
		Send_Data[12] = (data[2] >> 8) & 0xFF;
		Send_Data[13] = (data[2] >> 0) & 0xFF;
		Send_Data[14] = (data[3] >> 8) & 0xFF;
		Send_Data[15] = (data[3] >> 0) & 0xFF;
#if !defined (HARDWARE_ASICS)
		gecko_cmd_gatt_server_send_characteristic_notification(
            Connection_Id, gattdb_heart_rate_measurement, ATT_DEFAULT_PAYLOAD_LEN, Send_Data);
#endif
	}
	else {
		/************/
		/* 心電情報 */
		/************/
		Read_ECG_Data();
		Sensor_Time_ECG1 = (Sensor_Time - 10);
		Sensor_Time_ECG2 = (Sensor_Time);
		Send_Data[0] = ATT_DEFAULT_PAYLOAD_LEN;
		Send_Data[1] = REPORT_DATA;
		Send_Data[2] = ((uint64_t)Sensor_Time_ECG1 >> 40);
		Send_Data[3] = ((uint64_t)Sensor_Time_ECG1 >> 32);
		Send_Data[4] = ((uint64_t)Sensor_Time_ECG1 >> 24);
		Send_Data[5] = ((uint64_t)Sensor_Time_ECG1 >> 16);
		Send_Data[6] = ((uint64_t)Sensor_Time_ECG1 >>	 8);
		Send_Data[7] = ((uint64_t)Sensor_Time_ECG1 >>	 0);
		Send_Data[8] = (ECG_Send_Data[0][0] >> 8) & 0xFF;
		Send_Data[9] = (ECG_Send_Data[0][0] >> 0) & 0xFF;

		//uart0_driver_put_char((ECG_Send_Data[0][0] >> 8) & 0xFF);
		//uart0_driver_put_char((ECG_Send_Data[0][0] >> 0) & 0xFF);

		Send_Data[10] = (ECG_Send_Data[1][0] >> 8) & 0xFF;
		Send_Data[11] = (ECG_Send_Data[1][0] >> 0) & 0xFF;
		Send_Data[12] = (ECG_Send_Data[2][0] >> 8) & 0xFF;
		Send_Data[13] = (ECG_Send_Data[2][0] >> 0) & 0xFF;
		Send_Data[14] = (ECG_Send_Data[3][0] >> 8) & 0xFF;
		Send_Data[15] = (ECG_Send_Data[3][0] >> 0) & 0xFF;
		Send_Data[16] = ((uint64_t)Sensor_Time_ECG2 >> 40);
		Send_Data[17] = ((uint64_t)Sensor_Time_ECG2 >> 32);
		Send_Data[18] = ((uint64_t)Sensor_Time_ECG2 >> 24);
		Send_Data[19] = ((uint64_t)Sensor_Time_ECG2 >> 16);
		Send_Data[20] = ((uint64_t)Sensor_Time_ECG2 >>  8);
		Send_Data[21] = ((uint64_t)Sensor_Time_ECG2 >>  0);
		Send_Data[22] = (ECG_Send_Data[0][1] >> 8) & 0xFF;
		Send_Data[23] = (ECG_Send_Data[0][1] >> 0) & 0xFF;
		Send_Data[24] = (ECG_Send_Data[1][1] >> 8) & 0xFF;
		Send_Data[25] = (ECG_Send_Data[1][1] >> 0) & 0xFF;
		Send_Data[26] = (ECG_Send_Data[2][1] >> 8) & 0xFF;
		Send_Data[27] = (ECG_Send_Data[2][1] >> 0) & 0xFF;
		Send_Data[28] = (ECG_Send_Data[3][1] >> 8) & 0xFF;
		Send_Data[29] = (ECG_Send_Data[3][1] >> 0) & 0xFF;
		Send_Data[30] = (ecg_hrdata1_get()) & 0xFF;
		Send_Data[31] = (ecg_hrdata2_get()) & 0xFF;
#if !defined (HARDWARE_ASICS)
		gecko_cmd_gatt_server_send_characteristic_notification(
            Connection_Id, gattdb_heart_rate_measurement, ATT_DEFAULT_PAYLOAD_LEN, Send_Data);
#endif
	}
}
