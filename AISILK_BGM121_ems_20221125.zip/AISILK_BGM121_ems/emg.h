/*
 * emg.h
 *
 *  Created on: 2017/07/28
 *      Author: D-CLUE
 */

#ifndef EMG_H_
#define EMG_H_

/** Heart Rate measurement period in ms. */
#define HR_IND_TIMEOUT											1	 /* [ms] */
#define HR_SEND_TIMEOUT											20 /* [ms] */

extern void emg_data_init(void);
extern void emg_data_get(void);
extern void lfilter_init(void);

#endif /* EMG_H_ */
