/*
 * ems.c
 *
 *  Created on: 2018/04/09
 *      Author: scrum
 */

#include <stdio.h>
#include <time.h>
#include "bg_types.h"
#include "native_gecko.h"

#include "em_emu.h"
#include "em_cmu.h"
#include "em_gpio.h"
#include "em_idac.h"

#include "ems.h"

/* i2c */
#include "i2cspm.h"
#include "i2c_driver.h"

/* idac */
#include "idac_driver.h"

/* timer */
#include "timer_driver.h"

/* spi */
#include "spi_driver.h"

/* adc */
#include "adc_driver.h"

typedef enum{
	EMS_START_UP,		//起動時リセット（+-ボタン10秒長押し）
	EMS_NORMAL,			//通常動作
	EMS_STANBY,			//スタンバイ状態
	EMS_PAUSE,			//一時停止
	EMS_PAIRING,		//ペアリングモード
}E_STAT;

#define	EMS_STANDBY_COUNTER			(60*30)	//スタンバイタイマー
//#define	EMS_STANDBY_COUNTER			(60*1)	//スタンバイタマー
#define	EMS_PAUSE_COUNTER			(60*2)	//pauseタイマー

typedef struct{
	E_STAT				stat;				/* 装置ステータス*/
	uint16_t			standby_counter;	/* カウンタ*/
	uint16_t			pause_counter;		/* pauseカウンタ*/
	uint8_t  			error_code;
}T_EMS_STAT;
static T_EMS_STAT	tEMSStat;

typedef struct{
	uint16_t	timer1_5us_counter;
	uint16_t	timer1_1ms_counter;
	uint16_t	timer1_1s_counter;
	uint16_t	timer1_33ms3_counter;
}T_TIMER;

static T_TIMER tTimer;

typedef struct{
	uint16_t	pause_timer1_5us_counter;
	uint16_t	pause_timer1_1ms_counter;
	uint16_t	pause_timer1_1s_counter;
	uint16_t	timer1_33ms3_counter;
}T_TIMER_PAUSE;

static T_TIMER_PAUSE tTimerPause;

typedef struct{
	uint16_t	pairing_timer1_5us_counter;
	uint16_t	pairing_timer1_1ms_counter;
}T_TIMER_PAIRING;

static T_TIMER_PAIRING tTimerPairing;

typedef struct{
	  uint8_t               stat;			/* */
	  uint8_t               count;			/* */
}T_HVCONT_OUT;

static T_HVCONT_OUT	tHvCont;

typedef struct{
	  uint8_t               stat_up;		/* */
	  uint8_t				stat_up_long;	/* */
	  uint8_t               stat_down;		/* */
	  uint8_t				stat_down_long;	/* */
	  uint8_t               stat_mode;		/* */
	  uint8_t               stat_mode_long;	/* */
	  uint8_t               stat_det;		/* 電極剥がれ*/
	  uint8_t               stat_charge;	/* 充電*/

	  uint8_t               count_up;		/* */
	  uint8_t               count_down;		/* */
	  uint8_t               count_mode;		/* */
	  uint16_t              count_mode_long;/* */
	  uint16_t				count_down_long;/* */
	  uint16_t              count_up_long;	/* */

	  uint16_t              count_det_0;		/* 0x11電極剥がれ*/
	  uint16_t              count_det_1;		/* 0x18電極剥がれ*/
	  uint16_t              count_det_2;		/* 0x12電極剥がれ*/
	  uint16_t              count_det_3;		/* 0x14電極剥がれ*/
	  uint16_t              count_no_det_0;		/* 0x11電極剥がれなし*/
	  uint16_t              count_no_det_1;		/* 0x18電極剥がれなし*/
	  uint16_t              count_no_det_2;		/* 0x12電極剥がれなし*/
	  uint16_t              count_no_det_3;		/* 0x14電極剥がれなし*/
	  uint8_t               count_charge;		/* 充電*/
	  uint8_t               count_same_charge;	/* 充電*/
	  uint8_t               count_change_charge;/* 充電*/

	  bool					stat_up_flag;		/*stat_up状態切り替え用*/
}T_KEY;
static T_KEY	tKey;

typedef struct{
	int16_t 	led_status;
	int16_t 	lednum;
	int16_t 	led_table_num;
	uint16_t	led_1ms_counter;
	bool 		led_flag;
	bool		led_ON_flag;
}T_LED;
static T_LED	tLed;

typedef struct{
	bool 		set_step_flag;
	uint16_t 	idacStep;
	uint16_t 	stepcount;
	uint16_t 	idac_stop_count;
	bool 		idac_start_flag;
	bool 		idac_stop_flag;
	uint32_t	timer1_idac_counter;
	bool 		idac_flag;
}T_IDAC;
static T_IDAC	tIdac;

typedef struct{
	uint16_t 	charge_count;
	uint16_t 	charge_error_check_count;
	uint16_t 	charge_status;
	bool 		charge_start_flag;
	uint16_t	battery_1s_counter;
	uint8_t		battery_error_count;
	bool 		battery_error_flag;
}T_CHARGE;
static T_CHARGE	tCharge;

typedef struct{
	uint8_t		timer1_sco_flag;
	uint16_t	timer1_sco_counter;
	uint16_t	timer1_impulse_change_counter;
	uint16_t	timer1_impulse_counter;
	uint16_t	timer1_burst_time;
	uint16_t	timer1_selectems_change_counter;
	uint16_t	timer1_selectems_counter;
	uint8_t		selectems_num;
	uint8_t		mode_num;
	uint16_t	mode_1s_counter;

	uint8_t 	mode_status;//0:static 1:dynamic 2:pitch
	bool 		s_tr_mode;
	int			s_tr_counter;
	bool 		sco_start_flag;			//刺激開始フラグ(true=トレーニング開始,false=停止)
	bool 		sco_rev_flag;

	int16_t    dynamic_operation_time; //ダイナミックモードトレーニング時間（基準との差：秒）
	int16_t    pitch_operation_time;//ピッチモードトレーニング時間（基準との差：秒）

	uint16_t	dynamic_mode5_impulse_change_counter;//ダイナミックモード強時のchange_counter
	uint16_t	dynamic_mode6_impulse_change_counter;//ダイナミックモード弱時のchange_counter
	uint16_t	dynamic_mode5_burst_time;//ダイナミックモード強時のburst_time
	uint16_t	dynamic_mode6_burst_time;//ダイナミックモード弱時のburst_time
	uint16_t	dynamic_mode5_selectems_change_counter;//ダイナミックモード強時のselectems_change_counter
	uint16_t	dynamic_mode6_selectems_change_counter;//ダイナミックモード弱時のselectems_change_counter
	uint16_t	static_mode7_impulse_change_counter;//スタティックモード強時のchange_counter
	uint16_t	static_mode8_impulse_change_counter;//スタティックモード弱時のchange_counter
	uint16_t	static_mode7_burst_time;//スタティックモード強時のburst_time
	uint16_t	static_mode8_burst_time;//スタティックモード弱時のburst_time
	uint16_t	static_mode7_selectems_change_counter;//スタティックモード強時のselectems_change_counter
	uint16_t	static_mode8_selectems_change_counter;//スタティックモード弱時のselectems_change_counter

	uint32_t	mode_0_sec;//刺激スタート時の時間
	bool		selectems_on_flag;//刺激場所強制設定フラグ（ピッチモードでidacがONになった時にリセットするため）
}T_SCO;
static T_SCO	tSco;

typedef struct{
	uint16_t	timer0_buzzer_counter;
	bool 		buzzer_on_flag;
	uint8_t		buzzer_status;
	int			buzzer_count;
	int			buzzer_ON_Counter;
	bool		buzzer_det_off;
	bool		buzzer_det_after_change;
}T_BUZZER;
static T_BUZZER	tBuzzer;

typedef struct{
	int8_t 		start_up_stat;
	int16_t		start_up_counter;
	int16_t		start_down_counter;
	int16_t		start_mode_counter;
}T_START_UP;
static T_START_UP	tStart_up;

typedef struct{
	uint16_t	pause_timer1_sco_counter;
	uint16_t 	pause_stepcount;
}T_PAUSE;
static T_PAUSE tPause;

typedef struct{
	int		dynamic_s_time;
	int 	dynamic_w_time;
	int 	dynamic_tr_time;
	int 	dynamic_ret_time;
	int		pitch_idac_on_time;
	int 	pitch_idac_off_time;
	int 	pitch_idac_ret_time;
}T_DYNAMIC_TIME;
static T_DYNAMIC_TIME tDynamicTime;

typedef struct{
	uint16_t s_time;	//強時間
	uint16_t w_time;	//弱時間
	uint8_t tr_time;	//トレーニング時間
}T_DYNAMIC_TIME_REAL;
static T_DYNAMIC_TIME_REAL tDynamicTimeReal;

typedef struct{
	uint16_t idac_on_time;	//ON時間
	uint16_t idac_off_time;	//OFF時間
	uint8_t tr_time;	//トレーニング時間
}T_PITCH_TIME_REAL;
static T_PITCH_TIME_REAL tPitchTimeReal;

const int8_t hvcont[] =
{
	1,1,1,1,1,1,1,1,1,3,
	3,3,3,3,3,3,3,4,4,4,
	4,4,4,4,4,6,6,6,6
};

const int8_t idac_step[] =
{
	  2, 6, 7, 8, 9,10,11,12,13,14,
	 15,16,17,18,19,20,21,22,23,24,
	 25,26,27,28,29,30,31
};

const int16_t dynamic_session_sec_default[] =
{
		15,30,40,50,60,0,1860,1870,1880,1890,1905,1920
};

const int16_t pitch_session_sec_default = 3600;

struct MODE_ITEM
{
	int16_t session_sec;//セッション時間
	int16_t inpulse_hz;	//インパルス周波数
	int16_t burst_usec;	//バースト時間
	int16_t burst_hz;	//バースト周波数
	int8_t burst_num;	//バースト回数
};

const struct MODE_ITEM mode_items_static[] =
{
		{  15, 10, 200, 5000, 1},
		{  30, 15, 200, 5000, 1},
		{  40, 15, 400, 2500, 1},
		{  50, 20, 400, 2500, 1},
		{  60, 20, 500, 2000, 1},
		{ 360, 20, 600, 1666, 2},
		{ 660, 25, 600, 1666, 2},
		{   0, 25, 600, 1666, 2},
		{ 960, 10, 600, 1666, 1},
		{ 970, 20, 500, 2000, 1},
		{ 980, 20, 400, 2500, 1},
		{ 990, 15, 400, 2500, 1},
		{1005, 15, 200, 5000, 1},
		{1020, 10, 200, 5000, 1},
};

struct MODE_ITEM mode_items_dynamic[] =
{
		{   15, 10, 200, 5000,  1},
		{   30, 15, 200, 5000,  1},
		{   40, 15, 400, 2500,  1},
		{   50, 20, 400, 2500,  1},
		{   60, 20, 500, 2000,  1},
		{    0, 25, 600, 1666,  2},
		{ 1860, 10, 600, 1666,  1},
		{ 1870, 20, 500, 2000,  1},
		{ 1880, 20, 400, 2500,  1},
		{ 1890, 15, 400, 2500,  1},
		{ 1905, 15, 200, 5000,  1},
		{ 1920, 10, 200, 5000,  1},
};

struct MODE_ITEM mode_items_pitch[] =
{
		{ 3600, 25, 600, 1666, 2},
};

struct LED_RGB_KEY{
	int8_t red;		//赤
	int8_t green;	//緑
	int8_t blue;	//青
};
const struct LED_RGB_KEY led_rgb[] =
{
		{0x00, 0x00, 0xEE},
		{0x00, 0x22, 0xCC},
		{0x00, 0x44, 0xAA},
		{0x00, 0x66, 0x88},
		{0x00, 0x88, 0x66},
		{0x00, 0xAA, 0x44},
		{0x00, 0xCC, 0x22},
		{0x00, 0xEE, 0x00},
		{0x22, 0xCC, 0x00},
		{0x44, 0xAA, 0x00},
		{0x66, 0x88, 0x00},
		{0x88, 0x66, 0x00},
		{0xAA, 0x44, 0x00},
		{0xCC, 0x22, 0x00},
		{0xEE, 0x00, 0x00},
		{0xCC, 0x00, 0x22},
		{0xAA, 0x00, 0x44},
		{0x88, 0x00, 0x66},
		{0x66, 0x00, 0x88},
		{0x44, 0x00, 0xAA},
		{0x22, 0x00, 0xCC},
};

uint32_t set_time;

static void ems_timer_init(void);
static void ems_statuschange(E_STAT e);


static void ems_timer_start_up(void);
static void ems_timer_normal(void);
static void ems_timer_standby(void);
static void ems_timer_pause(void);
static void ems_pairing(void);
void (*ems_timerfunc[ ])(void)={ems_timer_start_up,ems_timer_normal,ems_timer_standby,ems_timer_pause,ems_pairing};

void ems_init()
{
	//装置状態設定
	//tEMSStat.stat = EMS_NORMAL;
	//tEMSStat.standby_counter=0;
	tEMSStat.stat = EMS_START_UP;

	//タイマー初期処理
	ems_timer_init();

	//sco1,sco2 out初期処理
	ems_sco_init(0);

	//hvcont初期化
	ems_hvcont_init();
	ems_hvcont_start();

	//Key初期化
	ems_key_init();

	//ブザー初期処理
	ems_buzzer_init();

	//スタンバイ2分タイマー設定
	gecko_cmd_hardware_set_soft_timer(TIMER_PERIOD*120, TIMER_HANDLE_STANBY, NO_REPEATED_TIMER);
	//バッテリータイマー設定
	gecko_cmd_hardware_set_soft_timer(TIMER_PERIOD*1, TIMER_HANDLE_BATTERY, REPEATED_TIMER);
	//idacを最小値にする
	idacOff();
}

//状態変更処理
static void ems_statuschange(E_STAT e)
{
	//HV_CONTスタート
	ems_hvcont_start();

	//休止,ペアリングからの復帰
	if(e==EMS_NORMAL && (tEMSStat.stat==EMS_STANBY || tEMSStat.stat==EMS_PAIRING))
	{
		if(tEMSStat.stat==EMS_STANBY)
		{
			//バッテリー残量低下チェックフラグをリセット
			tCharge.battery_error_flag=OFF;
			//idacを最小値にする
			idacOff();
		}
		//スタンバイ2分タイマー設定
		gecko_cmd_hardware_set_soft_timer(TIMER_PERIOD*120, TIMER_HANDLE_STANBY, NO_REPEATED_TIMER);

		if (tSco.mode_status == STATIC)
		{
			//LED:緑点滅（1:2秒）スタティックモードスタンバイ
			led_status_change(10);
		}
		else if(tSco.mode_status == DYNAMIC)
		{
			//LED:橙色点滅（1:2秒）ダイナミックモードスタンバイ
			led_status_change(9);
		}else{
			//LED:黄色点滅（1:2秒）ピッチモードスタンバイ
			led_status_change(16);
		}
	}
	//pauseからの復帰
	else if(e==EMS_NORMAL && tEMSStat.stat==EMS_PAUSE)
	{
		//一時停止2分タイマー解除
		pause_timer_reset();
		if (tSco.sco_start_flag == ON)
		{
			//idacレベル調整タイマー設定
			gecko_cmd_hardware_set_soft_timer(TIMER_PERIOD*5, TIMER_HANDLE_IDAC, REPEATED_TIMER);
			idacSetStepNum(1);
			if (tSco.mode_status == STATIC)
			{
				//LED:緑色点灯 スタティックモード刺激動作中
				led_status_change(2);
			}
			else if(tSco.mode_status == DYNAMIC)
			{
				//LED:橙色点灯　ダイナミックモード動作中
				led_status_change(8);
			}
			else{
				//LED:黄色点灯　ピッチモード動作中
				led_status_change(15);
			}
		}
		else
		{
			//スタンバイ2分タイマー設定
			gecko_cmd_hardware_set_soft_timer(TIMER_PERIOD*120, TIMER_HANDLE_STANBY, NO_REPEATED_TIMER);
			if (tSco.mode_status == STATIC)
			{
				//LED:緑色点滅（1:2秒）スタティックモードスタンバイ
				led_status_change(10);
			}
			else if(tSco.mode_status == DYNAMIC)
			{
				//LED:橙色点滅（1:2秒）ダイナミックモードスタンバイ
				led_status_change(9);
			}
			else
			{
				//LED:黄色点滅（1:2秒）ピッチモードスタンバイ
				led_status_change(16);
			}
		}
		tEMSStat.pause_counter=0;
	}
	//pauseへの遷移
	else if(e==EMS_PAUSE)
	{
		//一時停止2分タイマー設定
		gecko_cmd_hardware_set_soft_timer(TIMER_PERIOD*120, TIMER_HANDLE_PAUSE, NO_REPEATED_TIMER);

		tPause.pause_stepcount=tIdac.stepcount;
		idacSetStepNum(0);
		tEMSStat.pause_counter=0;

		if(tBuzzer.buzzer_det_off==OFF)
		{
			ems_buzzer_set(3, 1);//ステータス:1, 回数:1(ピー)
		}
		if (tSco.mode_status == STATIC)
		{
			//LED:緑色点滅（1Hz） 一時停止スタティックモード
			led_status_change(1);
		}
		else if(tSco.mode_status == DYNAMIC)
		{
			//LED:橙色点滅（1Hz）一時停止ダイナミックモード
			led_status_change(6);
		}
		else
		{
			//LED:黄色点滅（1Hz）一時停止ピッチモード
			led_status_change(18);
		}
	}
	//休止への遷移
	else if(e==EMS_STANBY)
	{
		//HV_CONTストップ
		ems_hvcont_stop();

		//一時停止2分タイマー解除
		pause_timer_reset();
		//delayタイマー解除
		delay_timer_reset();
		//スタンバイ2分タイマー解除
		stanby_timer_reset();
		//DACをZEROにする。
		idacZero();
		//剥がれ検知をリセット(ONのままだとスタンバイに戻った時にブザーがならない)
		if(tBuzzer.buzzer_det_off==ON)
		{
			tBuzzer.buzzer_det_off=OFF;
			if(tBuzzer.buzzer_status==6)
			{
				//剥がれブザー消音
				ems_buzzer_set(99, 0);
			}
		}

		if(tCharge.charge_status==2)
		{
			//LED:青色点灯 充電中
			led_status_change(4);
		}
		else
		{
			if (tSco.mode_status == STATIC)
			{
				//LED:緑点滅（1:5秒）休止 スタティックモード
				led_status_change(11);
			}
			else if(tSco.mode_status == DYNAMIC)
			{
				//LED:橙色点滅（1:5秒）休止 ダイナミックモード
				led_status_change(12);
			}
			else
			{
				//LED:黄色点滅（1:5秒）休止 ピッチモード
				led_status_change(17);
			}
		}
	}
	else if(e==EMS_PAIRING)
	{
		//HV_CONTストップ
		ems_hvcont_stop();
		//剥がれ検知をリセット(ONのままだとスタンバイに戻った時にブザーがならない)
		if(tBuzzer.buzzer_det_off==ON)
		{
			tBuzzer.buzzer_det_off=OFF;
			if(tBuzzer.buzzer_status==6)
			{
				//剥がれブザー消音
				ems_buzzer_set(99, 0);
			}
		}
	}
	tEMSStat.stat=e;
	tEMSStat.standby_counter=0;
}

//タイマー初期処理
static void ems_timer_init(void)
{
	tTimer.timer1_5us_counter=0;
	tTimer.timer1_1ms_counter=0;
	tTimer.timer1_1s_counter=0;
	tTimer.timer1_33ms3_counter=0;
	tTimerPause.pause_timer1_5us_counter=0;
	tTimerPause.pause_timer1_1ms_counter=0;
	tTimerPause.pause_timer1_1s_counter=0;
}
//timer1タイムアウト処理
void ems_timer(void)
{
	ems_timerfunc[tEMSStat.stat]();
}

//タイムアウト処理(起動時)
void ems_timer_start_up(void)
{
	tTimer.timer1_5us_counter++;

	if(tTimer.timer1_5us_counter>=200)
	{
		tTimer.timer1_5us_counter=0;
		tTimer.timer1_1ms_counter++;
	}

	if(tTimer.timer1_1ms_counter>=1000)
	{
		tTimer.timer1_1s_counter++;
		tTimer.timer1_1ms_counter=0;
		ems_startup_key_check();

		if(tStart_up.start_up_stat==1)
		{
			//装置状態設定
			tEMSStat.stat = EMS_NORMAL;
			tEMSStat.standby_counter=0;
		}
		else if (tStart_up.start_up_stat==2)
		{
	        //フラッシュデータリセット（デフォルト設定）
			flash_data_reset();
	        //リスタート
	        gecko_cmd_system_reset(0);
		}
		else if (tStart_up.start_up_stat==3)
		{
	        //bondingデータ削除
	        gecko_cmd_sm_delete_bondings();
	        //リスタート
	        gecko_cmd_system_reset(0);
		}
	}
}
//タイムアウト処理(通常時)
void ems_timer_normal(void)
{
	tTimer.timer1_5us_counter++;
	tTimer.timer1_33ms3_counter++;

	//hvcont出力
	if (tTimer.timer1_5us_counter%2 == 1)
	{
		ems_hvcont_out();
	}

	//刺激回路選択
	ems_selectems();

	//パルス設定
	mode_set();

	if(tTimer.timer1_5us_counter>=200)
	{
		tTimer.timer1_5us_counter=0;
		tTimer.timer1_1ms_counter++;
		//1ms

		//KeyCheck!!
		ems_key_check();

		led_check();

		//充電チェック
		charge_check();


	}

	if(tTimer.timer1_1ms_counter>=1000)
	{
		tTimer.timer1_1ms_counter=0;
		//1S
		tTimer.timer1_1s_counter++;
		tCharge.battery_1s_counter++;
	}
}
//タイムアウト処理(休止時)
void ems_timer_standby(void)
{
	tTimer.timer1_5us_counter++;
	tTimer.timer1_33ms3_counter++;

	if(tTimer.timer1_5us_counter>=200)
	{
		tTimer.timer1_5us_counter=0;
		tTimer.timer1_1ms_counter++;
		//1ms

		//KeyCheck!!
		ems_key_check();

		led_check();

		//充電チェック
		charge_check();

	}

	if(tTimer.timer1_1ms_counter>=1000)
	{
		tTimer.timer1_1ms_counter=0;
		//1S
		tTimer.timer1_1s_counter++;
		tCharge.battery_1s_counter++;
	}
}
//タイムアウト処理(一時停止時)
void ems_timer_pause(void)
{
	tTimerPause.pause_timer1_5us_counter++;

	//hvcont出力
	if (tTimerPause.pause_timer1_5us_counter%2 == 1)
	{
		ems_hvcont_out();
	}
	//刺激回路選択
	ems_selectems();

	//パルス設定(一時停止用)
	mode_set_pause();

	if(tTimerPause.pause_timer1_5us_counter>=200)
	{
		tTimerPause.pause_timer1_5us_counter=0;
		tTimerPause.pause_timer1_1ms_counter++;
		//1ms

		//KeyCheck!!
		ems_key_check();

		led_check();

		//充電チェック
		charge_check();

	}

	if(tTimerPause.pause_timer1_1ms_counter>=1000)
	{
		tTimerPause.pause_timer1_1ms_counter=0;
		//1S
		tTimerPause.pause_timer1_1s_counter++;
		tCharge.battery_1s_counter++;
	}
}
//ペアリング
void ems_pairing(void)
{
	tTimerPairing.pairing_timer1_5us_counter++;

	if(tTimerPairing.pairing_timer1_5us_counter>=200)
	{
		tTimerPairing.pairing_timer1_5us_counter=0;
		tTimerPairing.pairing_timer1_1ms_counter++;

		//LEDチェック
		led_check();

	}

}
//HVCONT初期設定
void ems_hvcont_init(void)
{
	tHvCont.stat = OFF;
	GPIO_PinModeSet(HVCONT_PORT,HVCONT_PIN,gpioModePushPull,0);
}
//刺激回路選択
void ems_selectems()
{
	uint8_t addr;/*WRITE*/;
	uint8_t command;
	uint8_t val;
	uint8_t len;

	tSco.timer1_selectems_counter++;

	//if (tSco.sco_start_flag == ON) //剥がれ検知のため刺激開始していなくても行う
	{

		if ((tSco.selectems_on_flag==ON) || (tSco.timer1_selectems_counter >= tSco.timer1_selectems_change_counter))
		{
			if(tSco.selectems_on_flag==ON)
			{
				tSco.selectems_on_flag=OFF;
			}
			tSco.timer1_selectems_counter = 0;

			//data
			addr = 0x20<<1 | 0;/*WRITE*/;
			command = 0x01;
			val = 0x11;;
			len = 2;

			switch(tSco.selectems_num)
			{
			case	0:
				val = 0x11;
				break;
			case	1:
				val = 0x18;
				break;
			case	2:
				val = 0x12;
				break;
			case	3:
				val = 0x14;
				break;
			}

			I2C_write(addr, command, val, len);

			//SCO1とSCO2の出力を反対にする
			if (tSco.selectems_num == 0)
			{
				if (tSco.sco_rev_flag == ON)
				{
					tSco.sco_rev_flag = OFF;
				}
				else
				{
					tSco.sco_rev_flag = ON;
				}
			}

			tSco.selectems_num++;
			if (tSco.selectems_num > 3)
			{
				tSco.selectems_num = 0;
			}

			//config
			command = 0x03; // Command:Configuration register
			val = 0x00;
			I2C_write(addr, command, val, len);

			//SCO1 SCO2出力
			tSco.timer1_sco_flag=ON;

		}

	}

}

//hvcont(10us毎呼び出し)
void ems_hvcont_out(void)
{
	if(tHvCont.stat==ON){
//変動
		if (tHvCont.count == 0)
		{
			GPIO_PinOutSet(HVCONT_PORT, HVCONT_PIN);
		}
		else if  (tHvCont.count == hvcont[tIdac.idacStep])
		{
			GPIO_PinOutClear(HVCONT_PORT, HVCONT_PIN);
		}

		tHvCont.count++;
		if(tHvCont.count>=10){
			tHvCont.count=0;
		}
	}
}
void ems_hvcont_start(void)
{
	tHvCont.stat=ON;
	tHvCont.count=0;
	GPIO_PinOutClear(HVCONT_PORT, HVCONT_PIN);
}
void ems_hvcont_stop(void)
{
	tHvCont.stat=OFF;
	GPIO_PinOutClear(HVCONT_PORT, HVCONT_PIN);
}


//SCO1,SCO2出力初期処理
void ems_sco_init(int16_t type)
{
	GPIO_PinModeSet(SCO1_PORT,SCO1_PIN,gpioModePushPull,0);
	GPIO_PinModeSet(SCO2_PORT,SCO2_PIN,gpioModePushPull,0);
}

//SCO1,SCO2出力モード初期処理
void ems_sco_mode_init()
{
	tSco.mode_num=0;
	tSco.s_tr_mode = OFF;
	tIdac.idac_flag = OFF;
	tSco.sco_start_flag=OFF;
	tSco.timer1_sco_flag=OFF;
	tSco.timer1_impulse_counter=0;
	tSco.mode_1s_counter=0;
	tSco.s_tr_counter=0;
	tIdac.stepcount=0;

	if (tSco.mode_status == STATIC)
	{
		tIdac.idac_flag = OFF;
		tSco.timer1_impulse_change_counter = 100000/mode_items_static[tSco.mode_num].inpulse_hz*2;
		tSco.timer1_burst_time = mode_items_static[tSco.mode_num].burst_usec/20;
		tSco.timer1_selectems_change_counter = 50000/mode_items_static[tSco.mode_num].inpulse_hz;
		//強弱に使用する値設定
		tSco.static_mode7_impulse_change_counter = 200000/mode_items_static[7].inpulse_hz;
		tSco.static_mode7_burst_time = mode_items_static[7].burst_usec/20;
		tSco.static_mode7_selectems_change_counter = 50000/mode_items_static[7].inpulse_hz;
		tSco.static_mode8_impulse_change_counter = 200000/mode_items_static[8].inpulse_hz;
		tSco.static_mode8_burst_time = mode_items_static[8].burst_usec/20;
		tSco.static_mode8_selectems_change_counter = 50000/mode_items_static[8].inpulse_hz;
	}
	else if(tSco.mode_status == DYNAMIC)
	{
		tIdac.idac_flag = OFF;
		tSco.timer1_impulse_change_counter = 100000/mode_items_dynamic[tSco.mode_num].inpulse_hz*2;
		tSco.timer1_burst_time = mode_items_dynamic[tSco.mode_num].burst_usec/20;
		tSco.timer1_selectems_change_counter = 50000/mode_items_dynamic[tSco.mode_num].inpulse_hz;
		//強弱に使用する値設定
		tSco.dynamic_mode5_impulse_change_counter = 200000/mode_items_dynamic[5].inpulse_hz;
		tSco.dynamic_mode5_burst_time = mode_items_dynamic[5].burst_usec/20;
		tSco.dynamic_mode5_selectems_change_counter = 50000/mode_items_dynamic[5].inpulse_hz;
		tSco.dynamic_mode6_impulse_change_counter = 200000/mode_items_dynamic[6].inpulse_hz;
		tSco.dynamic_mode6_burst_time = mode_items_dynamic[6].burst_usec/20;
		tSco.dynamic_mode6_selectems_change_counter = 50000/mode_items_dynamic[6].inpulse_hz;
	}
	else
	{
		tIdac.idac_flag = ON;
		tSco.timer1_impulse_change_counter = 100000/mode_items_pitch[tSco.mode_num].inpulse_hz*2;
		tSco.timer1_burst_time = mode_items_pitch[tSco.mode_num].burst_usec/20;
		tSco.timer1_selectems_change_counter = 50000/mode_items_pitch[tSco.mode_num].inpulse_hz;
	}
	//ダイナミック強弱時間設定（フラッシュに記録されているものに戻す）
	set_dynamic_time(ems_flash_dynamic_time_data.s_time, ems_flash_dynamic_time_data.w_time);
	//ピッチモードidacON/OFF時間設定（フラッシュに記録されているものに戻す）
	set_pitch_time(ems_flash_dynamic_time_data.pitch_idac_on_time, ems_flash_dynamic_time_data.pitch_idac_off_time);
}

//SCO1,SCO2出力処理(150us毎呼び出し)
void ems_sco_out(int16_t count)
{
	switch(count){
		case	0:
		case	4:
			GPIO_PinOutSet(SCO1_PORT, SCO1_PIN);
			GPIO_PinOutClear(SCO2_PORT, SCO2_PIN);
			break;
		case	1:
		case	3:
		case	5:
		case	7:
			electrode_det();
			GPIO_PinOutClear(SCO1_PORT, SCO1_PIN);
			GPIO_PinOutClear(SCO2_PORT, SCO2_PIN);
			break;
		case	2:
		case	6:
			GPIO_PinOutClear(SCO1_PORT, SCO1_PIN);
			GPIO_PinOutSet(SCO2_PORT, SCO2_PIN);
			break;
		default:
			break;

	}
}

//SCO1,SCO2出力処理逆順(150us毎呼び出し)
void ems_sco_out_rev(int16_t count)
{
	switch(count){
		case	0:
		case	4:
			GPIO_PinOutClear(SCO1_PORT, SCO1_PIN);
			GPIO_PinOutSet(SCO2_PORT, SCO2_PIN);
			break;
		case	1:
		case	3:
		case	5:
		case	7:
			electrode_det();
			GPIO_PinOutClear(SCO1_PORT, SCO1_PIN);
			GPIO_PinOutClear(SCO2_PORT, SCO2_PIN);
			break;
		case	2:
		case	6:
			GPIO_PinOutSet(SCO1_PORT, SCO1_PIN);
			GPIO_PinOutClear(SCO2_PORT, SCO2_PIN);
			break;
		default:
			break;

	}
}

//key 初期処理
void ems_key_init(void)
{
	//KeyGPIO定義
	GPIO_PinModeSet(KEY_DOWN_PORT, KEY_DOWN_PIN, gpioModeInputPull, 1);
	GPIO_PinModeSet(KEY_UP_PORT, KEY_UP_PIN, gpioModeInputPull, 1);
	GPIO_PinModeSet(KEY_MODE_PORT, KEY_MODE_PIN, gpioModeInputPull, 1);

	GPIO_PinModeSet(ELECTRODEDET_PORT, ELECTRODEDET_PIN, gpioModeInputPull, 1);

	tKey.count_down = 0;
	tKey.count_up   = 0;
	tKey.count_mode = 0;
	tKey.count_det_0  = 0;
	tKey.count_det_1  = 0;
	tKey.count_det_2  = 0;
	tKey.count_det_3  = 0;
	tKey.count_no_det_0  = 0;
	tKey.count_no_det_1  = 0;
	tKey.count_no_det_2  = 0;
	tKey.count_no_det_3  = 0;
	tKey.count_charge        = 0;
	tKey.count_same_charge   = 0;
	tKey.count_change_charge = 0;
	tKey.count_mode_long = 0;
	tKey.count_down_long = 0;
	tKey.stat_up_flag = OFF;

	tKey.stat_down	= GPIO_PinInGet(KEY_DOWN_PORT, KEY_DOWN_PIN);
	tKey.stat_up	= GPIO_PinInGet(KEY_UP_PORT, KEY_UP_PIN);
	tKey.stat_mode	= GPIO_PinInGet(KEY_MODE_PORT, KEY_MODE_PIN);
	tKey.stat_det	= 0;//電極剥がれ検出：正常
	tKey.stat_charge = GPIO_PinInGet(CHARGE_PORT,CHARGE_PIN);

	tLed.led_status = 10;//0:消灯1:緑点灯2:緑点滅3:赤点滅（2kHz）4:橙色点滅5:赤点滅（0.5Hz）6:青点灯7:デモ8:青点滅9:青(1:2秒)10:緑(1:2秒)11:緑（1:5秒）
	tLed.lednum = 0;
	tLed.led_table_num = 0;//0:25% 1:50% 2:100%
	tLed.led_1ms_counter=0;
	tLed.led_flag = false;
	tLed.led_ON_flag = ON;

	tIdac.set_step_flag = false;
	tIdac.idacStep = 3;
	tIdac.stepcount = 0;
	tIdac.idac_stop_count = 0;
	tIdac.idac_start_flag = false;
	tIdac.idac_stop_flag = false;
	tIdac.idac_flag = OFF;//活動・休止あり

	tCharge.charge_count = 0;
	tCharge.charge_error_check_count = 0;
	tCharge.charge_status=0;//0:未充電　1:充電完了 2:充電中 3:充電エラー
	tCharge.charge_start_flag = false;
	tCharge.battery_1s_counter=0;
	tCharge.battery_error_count=0;
	tCharge.battery_error_flag=OFF;

	tSco.timer1_sco_flag=OFF;
	tSco.timer1_sco_counter=0;
	tSco.timer1_impulse_change_counter=20000;
	tSco.timer1_impulse_counter=0;
	tSco.timer1_burst_time=10;
	tSco.timer1_selectems_change_counter=5000;
	tSco.timer1_selectems_counter=0;
	tSco.selectems_num=0;
	tSco.mode_num=0;
	tSco.mode_status=STATIC;//0:static 1:dynamic 2:pitch
	tSco.s_tr_mode = OFF;//特殊トレーニングモード
	tSco.s_tr_counter=0;//特殊トレーニングモードカウンタ
	tSco.sco_start_flag=OFF;
	tSco.sco_rev_flag=OFF;//SCO逆順
	tSco.mode_1s_counter=0;
	tSco.dynamic_operation_time=0;//ダイナミックモードのトレーニング時間の差
	tSco.pitch_operation_time=0;//ピッチモードのトレーニング時間の差

	tBuzzer.timer0_buzzer_counter=0;
	tBuzzer.buzzer_on_flag=ON;
	tBuzzer.buzzer_status=3;
	tBuzzer.buzzer_count=1;
	tBuzzer.buzzer_ON_Counter=0;
	tBuzzer.buzzer_det_off=OFF;
	tBuzzer.buzzer_det_after_change=OFF;

	tStart_up.start_up_stat=0;
	tStart_up.start_up_counter=0;
	tStart_up.start_down_counter=0;

	tEMSStat.error_code=0;

	tPause.pause_timer1_sco_counter=0;
}
//start_up key 判定処理(ms毎)
void ems_startup_key_check(void)
{
	int stat;
	bool up_on_flag=OFF;
	bool down_on_flag=OFF;
	bool mode_on_flag=OFF;

	//---------------------------------------------------------
	// Start up Down長押し
	//---------------------------------------------------------
	stat = GPIO_PinInGet(KEY_DOWN_PORT,KEY_DOWN_PIN);
	if(stat != 0){
		up_on_flag = ON;
	}
	else{
		tStart_up.start_down_counter++;
	}
	//---------------------------------------------------------
	// Start up Up長押し
	//---------------------------------------------------------
	stat = GPIO_PinInGet(KEY_UP_PORT,KEY_UP_PIN);
	if(stat != 0){
		down_on_flag = ON;
	}
	else{
		tStart_up.start_up_counter++;
	}

	//---------------------------------------------------------
	// Start up 電源ボタン（mode）長押し
	//---------------------------------------------------------
	stat = GPIO_PinInGet(KEY_MODE_PORT,KEY_MODE_PIN);
	if(stat != 0){
		mode_on_flag = ON;
	}
	else{
		tStart_up.start_mode_counter++;
	}

	if(mode_on_flag==ON && (up_on_flag==ON || down_on_flag==ON))
	{
		tStart_up.start_up_stat=1;
	}
	else if(tStart_up.start_up_counter > 9 || tStart_up.start_down_counter > 9)
	{
		tStart_up.start_up_stat=2;
	}
	else if(tStart_up.start_mode_counter > 9)
	{
		tStart_up.start_up_stat=3;
	}
}

//key 判定処理(ms毎)
void ems_key_check(void)
{

	int stat;

	//---------------------------------------------------------
	// Down長押し
	//---------------------------------------------------------
	stat = GPIO_PinInGet(KEY_DOWN_PORT,KEY_DOWN_PIN);
	if(tKey.stat_down_long != stat){
		tKey.count_down_long++;
	}else{
		tKey.count_down_long=0;
	}
	if(tKey.count_down_long > KEY_THRESHOLD_2000)
	{
		//down変化
		tKey.stat_down_long = stat;
		if(tKey.stat_down_long == 0) //押された時
		{
			if(tEMSStat.stat==EMS_NORMAL)
			{
				//スタンバイ状態
				if (tSco.sco_start_flag != ON)
				{
					//ペアリングモードに遷移
					ems_statuschange(EMS_PAIRING);
					//ペアリングタイマ設定
					gecko_cmd_hardware_set_soft_timer(TIMER_PERIOD*60, TIMER_HANDLE_PAIRING, NO_REPEATED_TIMER);
					//LED:水色点滅（1:1秒）ペアリングモード
					led_status_change(14);
					//スタンバイ2分タイマー停止
					stanby_timer_reset();
				}
			}
		}
	}
	//---------------------------------------------------------
	// Down
	//---------------------------------------------------------
	stat = GPIO_PinInGet(KEY_DOWN_PORT,KEY_DOWN_PIN);
	if(tKey.stat_down != stat){
		tKey.count_down++;
	}else{
		tKey.count_down=0;
	}
	if(tKey.count_down > KEY_THRESHOLD)
	{
		//delayタイマー解除
		delay_timer_reset();

		//Down変化
		tKey.stat_down = stat;
		if(tKey.stat_down == 0) //押された時
		{
			if(tEMSStat.stat==EMS_NORMAL && tSco.sco_start_flag == ON)
			{
				//IDAC出力マイナス
				idacSetStep(-1);
			}
		}
	}

	//---------------------------------------------------------
	// Up
	//---------------------------------------------------------
	stat = GPIO_PinInGet(KEY_UP_PORT,KEY_UP_PIN);
	if(tKey.stat_up != stat){
		tKey.count_up++;
	}else{
		tKey.count_up=0;
	}
	if(tKey.count_up > KEY_THRESHOLD)
	{	//Up変化
		tKey.stat_up = stat;
		if(tKey.stat_up == 0) //押された時
		{
			//delayタイマー解除
			delay_timer_reset();

			if(tEMSStat.stat==EMS_NORMAL)
			{
				//idacスタート（30分で切るタイマスタート）
				tIdac.idac_start_flag = true;
				//scoスタート
				if (tSco.sco_start_flag != ON){
					if(tBuzzer.buzzer_det_off==OFF)
					{
						//スタンバイ2分タイマー停止
						stanby_timer_reset();
						//剥がれがない場合スタートする
						ems_sco_mode_init();
						//ダイナミックモードトレーニング差分時間設定（フラッシュに記録されているものから設定）
						dynamic_operation_time_set(ems_flash_dynamic_time_data.tr_time);
						//ピッチモードトレーニング差分時間設定（フラッシュに記録されているものから設定）
						pitch_operation_time_set(ems_flash_dynamic_time_data.pitch_tr_time);

						sco_start();
					}
				}
				else
				{
					//IDAC出力プラス
					idacSetStep(1);
				}
			}
			else if(tEMSStat.stat==EMS_PAUSE)
			{
				if(tBuzzer.buzzer_det_off==OFF)
				{
					//一時停止2分タイマー停止
					pause_timer_reset();
					//剥がれがない場合刺激再スタート
					sco_start();
				}
			}
		}
	}

	//---------------------------------------------------------
	// Mode
	//---------------------------------------------------------
	stat = GPIO_PinInGet(KEY_MODE_PORT,KEY_MODE_PIN);
	if(tKey.stat_mode != stat){
		tKey.count_mode++;
	}else{
		tKey.count_mode=0;
	}
	if(tKey.count_mode > KEY_THRESHOLD)
	{
		//Mode変化
		tKey.stat_mode = stat;
		if(tKey.stat_mode == 0) //押された時
		{
			//delayタイマー解除
			delay_timer_reset();

			if(tEMSStat.stat==EMS_NORMAL)
			{
				//モード切替
				if (tSco.mode_status == PITCH)
				{
					//ブザー設定
					if (tSco.sco_start_flag == ON)
					{
						//刺激中
						ems_statuschange(EMS_PAUSE);
					}
					else
					{
						/*スタンバイ中*/
						//スタティックモードに変更
						button_mode_change(STATIC);
						//スタンバイ2分タイマー設定
						gecko_cmd_hardware_set_soft_timer(TIMER_PERIOD*120, TIMER_HANDLE_STANBY, NO_REPEATED_TIMER);
					}
				}
				else if (tSco.mode_status == STATIC)
				{
					//ブザー設定
					if (tSco.sco_start_flag == ON)
					{
						//刺激中
						ems_statuschange(EMS_PAUSE);
					}
					else
					{
						/*スタンバイ中*/
						//ダインミックモードに変更
						button_mode_change(DYNAMIC);
						//スタンバイ2分タイマー設定
						gecko_cmd_hardware_set_soft_timer(TIMER_PERIOD*120, TIMER_HANDLE_STANBY, NO_REPEATED_TIMER);
					}
				}
				else
				{
					//ブザー設定
					if (tSco.sco_start_flag == ON)
					{
						//刺激中
						ems_statuschange(EMS_PAUSE);
					}
					else
					{
						/*スタンバイ中*/
						//ピッチモードに変更　ー＞　スタンドアロンではピッチモードを稼働しないためコメントアウト
						//button_mode_change(PITCH);
						//スタンドアロンではピッチモードを稼働しないためスタティックモードに変更
						button_mode_change(STATIC);
						//スタンバイ2分タイマー設定
						gecko_cmd_hardware_set_soft_timer(TIMER_PERIOD*120, TIMER_HANDLE_STANBY, NO_REPEATED_TIMER);
					}
				}
			}
			else if(tEMSStat.stat==EMS_PAUSE)
			{
				//通常処理遷移
				ems_sco_mode_init();
				ems_statuschange(EMS_NORMAL);
				//モード切替
				if (tSco.mode_status == PITCH)
				{
					//スタティックモードに変更
					button_mode_change(STATIC);
				}
				else if (tSco.mode_status == STATIC)
				{
					//ダイナミックモードに変更
					button_mode_change(DYNAMIC);
				}
				else
				{
					//ピッチモードに変更　ー＞　スタンドアロンではピッチモードを稼働しないためコメントアウト
					//button_mode_change(PITCH);
					//スタンドアロンではピッチモードを稼働しないためスタティックモードに変更
					button_mode_change(STATIC);
				}
			}
			else
			{
				//通常処理遷移
				ems_statuschange(EMS_NORMAL);
			}
		}
	}
}
//buzzer初期処理
void ems_buzzer_init(void)
{
	GPIO_PinModeSet(BUZZER_PORT,BUZZER_PIN,gpioModePushPull,0);
	GPIO_PinOutClear(BUZZER_PORT, BUZZER_PIN);
}
//buzzerRAW出力
void ems_buzzer_rawout(uint16_t onoff)
{
	if(onoff){
		GPIO_PinOutSet(BUZZER_PORT, BUZZER_PIN);
	}else{
		GPIO_PinOutClear(BUZZER_PORT, BUZZER_PIN);
	}
}
//buzzer出力
void ems_buzzer_out(void)
{
	tBuzzer.timer0_buzzer_counter++;
	if (tBuzzer.buzzer_on_flag == ON)
	{
		if (tBuzzer.buzzer_ON_Counter < tBuzzer.buzzer_count)
		{
			switch (tBuzzer.buzzer_status)
			{
			case	0://ピッ
				if (tBuzzer.timer0_buzzer_counter <= 70)
				{
					GPIO_PinOutToggle(BUZZER_PORT, BUZZER_PIN);
				}
				if(tBuzzer.timer0_buzzer_counter > 2800)
				{
					tBuzzer.timer0_buzzer_counter = 0;
					tBuzzer.buzzer_ON_Counter++;
				}
				break;
			case	1://ピピッ
				if (tBuzzer.timer0_buzzer_counter <= 70)
				{
					GPIO_PinOutToggle(BUZZER_PORT, BUZZER_PIN);
				}
				else if (tBuzzer.timer0_buzzer_counter > 140 && tBuzzer.timer0_buzzer_counter <= 210)
				{
					GPIO_PinOutToggle(BUZZER_PORT, BUZZER_PIN);
				}
				if(tBuzzer.timer0_buzzer_counter > 2800)
				{
					tBuzzer.timer0_buzzer_counter = 0;
					tBuzzer.buzzer_ON_Counter++;
				}
				break;
			case	2://0.1秒間隔
				if (tBuzzer.timer0_buzzer_counter < 70)
				{
					GPIO_PinOutToggle(BUZZER_PORT, BUZZER_PIN);
				}
				if(tBuzzer.timer0_buzzer_counter > 140)
				{
					tBuzzer.timer0_buzzer_counter = 0;
					tBuzzer.buzzer_ON_Counter++;
				}
				break;
			case	3://1秒間隔
				if (tBuzzer.timer0_buzzer_counter < 1400)
				{
					GPIO_PinOutToggle(BUZZER_PORT, BUZZER_PIN);
				}
				if(tBuzzer.timer0_buzzer_counter > 2800)
				{
					tBuzzer.timer0_buzzer_counter = 0;
					tBuzzer.buzzer_ON_Counter++;
				}
				break;
			case	4://ピピッ(5秒間隔）
				if (tBuzzer.timer0_buzzer_counter <= 70)
				{
					GPIO_PinOutToggle(BUZZER_PORT, BUZZER_PIN);
				}
				else if (tBuzzer.timer0_buzzer_counter > 140 && tBuzzer.timer0_buzzer_counter <= 210)
				{
					GPIO_PinOutToggle(BUZZER_PORT, BUZZER_PIN);
				}
				if(tBuzzer.timer0_buzzer_counter > 7000)
				{
					tBuzzer.timer0_buzzer_counter = 0;
					tBuzzer.buzzer_ON_Counter++;
				}
				break;
			case	5://0.5秒間隔（電源OFFのみ）
				if (tBuzzer.timer0_buzzer_counter < 350)
				{
					GPIO_PinOutToggle(BUZZER_PORT, BUZZER_PIN);
				}
				if(tBuzzer.timer0_buzzer_counter > 700)
				{
					tBuzzer.timer0_buzzer_counter = 0;
					tBuzzer.buzzer_ON_Counter++;
				}
				break;
			case	6://ピピッ(3秒間隔）剥がれ検出時
				if (tBuzzer.timer0_buzzer_counter <= 70)
				{
					GPIO_PinOutToggle(BUZZER_PORT, BUZZER_PIN);
				}
				else if (tBuzzer.timer0_buzzer_counter > 140 && tBuzzer.timer0_buzzer_counter <= 210)
				{
					GPIO_PinOutToggle(BUZZER_PORT, BUZZER_PIN);
				}
				if(tBuzzer.timer0_buzzer_counter > 4200)
				{
					tBuzzer.timer0_buzzer_counter = 0;
					tBuzzer.buzzer_ON_Counter++;
				}
				break;
			case	7://ピピピッ(3秒間隔）バッテリー残量低下検出時
				if (tBuzzer.timer0_buzzer_counter <= 70)
				{
					GPIO_PinOutToggle(BUZZER_PORT, BUZZER_PIN);
				}
				else if (tBuzzer.timer0_buzzer_counter > 140 && tBuzzer.timer0_buzzer_counter <= 210)
				{
					GPIO_PinOutToggle(BUZZER_PORT, BUZZER_PIN);
				}
				else if (tBuzzer.timer0_buzzer_counter > 280 && tBuzzer.timer0_buzzer_counter <= 350)
				{
					GPIO_PinOutToggle(BUZZER_PORT, BUZZER_PIN);
				}
				if(tBuzzer.timer0_buzzer_counter > 2800)
				{
					tBuzzer.timer0_buzzer_counter = 0;
					tBuzzer.buzzer_ON_Counter++;
				}
				break;
			case 99://ブザー消去
				break;
			default:
				break;
			}
		}
		else
		{
			//ブザー停止処理
			GPIO_PinOutClear(BUZZER_PORT, BUZZER_PIN);
			tBuzzer.buzzer_on_flag = OFF;

			//gpio_driverではブザーがならなくなるためここで対応
			if (tBuzzer.buzzer_status == 5)
			{
				//電源OFF
				set_kill();
			}
			else if (tBuzzer.buzzer_status == 7)
			{
				if(tBuzzer.buzzer_det_off == ON)
				{
					tBuzzer.buzzer_det_after_change=ON;
				}
			}

		}
	}
}

//ブザー設定
void ems_buzzer_set(int8_t set_buzzer_status, int set_buzzer_count)
{
	tBuzzer.buzzer_status = set_buzzer_status;
	tBuzzer.buzzer_count = set_buzzer_count;
	tBuzzer.timer0_buzzer_counter = 0;
	tBuzzer.buzzer_ON_Counter = 0;
	tBuzzer.buzzer_on_flag = ON;
}

//LED出力
void led_check()
{
	if(tLed.led_ON_flag == ON)
	{
	int8_t i;
	//LED
	switch(tLed.led_status)
	{
		case	0://0:消灯
			if (tLed.led_flag == false)
			{
				tLed.lednum = 3;
				disp_led_simple(tLed.lednum, tLed.led_table_num);
				tLed.led_flag = true;
			}
			break;
		case	1://1:緑色点滅（1Hz） 一時停止スタティックモード
			if (tLed.led_1ms_counter%1000 == 0)
			{
				if ((tLed.led_1ms_counter/1000)%2 == 0)
				{
					tLed.lednum = 1;
				}
				else
				{
					tLed.lednum = 3;
				}
				disp_led_simple(tLed.lednum, tLed.led_table_num);
			}
			break;
		case	2://2:緑色点灯 スタティックモード刺激動作中
			if (tLed.led_flag == false)
			{
				tLed.lednum = 1;
				disp_led_simple(tLed.lednum, tLed.led_table_num);
				tLed.led_flag = true;
			}
			break;
		case	3://3:赤色点滅（2Hz）充電エラー
			if (tLed.led_1ms_counter%500 == 0)
			{
				if ((tLed.led_1ms_counter/500)%2 == 0)
				{
					tLed.lednum = 2;
				}
				else
				{
					tLed.lednum = 3;
				}
				disp_led_simple(tLed.lednum, tLed.led_table_num);
			}
			break;
		case	4://4:青色点灯 充電中
			if (tLed.led_flag == false)
			{
				tLed.lednum = 0;
				disp_led_simple(tLed.lednum, tLed.led_table_num);
				tLed.led_flag = true;
			}
			break;
		case	5://5:赤色点滅(0.5Hz)
			if (tLed.led_1ms_counter%2000 == 0)
			{
				if ((tLed.led_1ms_counter/2000)%2 == 0)
				{
					tLed.lednum = 2;
				}
				else
				{
					tLed.lednum = 3;
				}
				disp_led_simple(tLed.lednum, tLed.led_table_num);
			}
			break;
		case	6://6:橙色点滅（1Hz）一時停止ダイナミックモード
			if (tLed.led_1ms_counter%1000 == 0)
			{
				if ((tLed.led_1ms_counter/1000)%2 == 0)
				{
					tLed.lednum = 4;
				}
				else
				{
					tLed.lednum = 3;
				}
				disp_led_simple(tLed.lednum, tLed.led_table_num);
			}
			break;
		case	7://7:デモ
			if (tLed.led_1ms_counter%1000 == 0)
			{
				//
				i=(tLed.led_1ms_counter/1000)%21;
				set_led_rgb(led_rgb[i].red,led_rgb[i].green,led_rgb[i].blue);
				disp_led_rgb();
				//
				/*
				if ((tLed.led_1ms_counter/1000)%3 == 0)
				{
					tLed.lednum = 0;
				}
				else if ((tLed.led_1ms_counter/1000)%3 == 1)
				{
					tLed.lednum = 2;
				}
				else
				{
					tLed.lednum = 1;
				}
				disp_led_simple(tLed.lednum, tLed.led_table_num);
				 */
			}
			break;
		case	8://8:橙色点灯　ダイナミックモード刺激動作中
			if (tLed.led_flag == false)
			{
				tLed.lednum = 4;
				disp_led_simple(tLed.lednum, tLed.led_table_num);
				tLed.led_flag = true;
			}
			break;
		case	9://9:橙色点滅（1:2秒）ダイナミックモードスタンバイ
			if (tLed.led_1ms_counter%1000 == 0)
			{
				if ((tLed.led_1ms_counter/1000)%3 == 0)
				{
					tLed.lednum = 4;
				}
				else if ((tLed.led_1ms_counter/1000)%3 == 1)
				{
					tLed.lednum = 3;
				}
				disp_led_simple(tLed.lednum, tLed.led_table_num);
			}
			break;
		case	10://10:緑色点滅（1:2秒）スタティックモードスタンバイ
			if (tLed.led_1ms_counter%1000 == 0)
			{
				if ((tLed.led_1ms_counter/1000)%3 == 0)
				{
					tLed.lednum = 1;
				}
				else if ((tLed.led_1ms_counter/1000)%3 == 1)
				{
					tLed.lednum = 3;
				}
				disp_led_simple(tLed.lednum, tLed.led_table_num);
			}
			break;
		case	11://11:緑色点滅（1:5秒）電源ON_休止 スタティックモード
			if (tLed.led_1ms_counter%1000 == 0)
			{
				if ((tLed.led_1ms_counter/1000)%6 == 0)
				{
					tLed.lednum = 1;
				}
				else if((tLed.led_1ms_counter/1000)%6 == 1)
				{
					tLed.lednum = 3;
				}
				disp_led_simple(tLed.lednum, tLed.led_table_num);
			}
			break;
		case	12://12:橙色点滅（1:5秒）電源ON_休止 ダイナミックモード
			if (tLed.led_1ms_counter%1000 == 0)
			{
				if ((tLed.led_1ms_counter/1000)%6 == 0)
				{
					tLed.lednum = 4;
				}
				else if((tLed.led_1ms_counter/1000)%6 == 1)
				{
					tLed.lednum = 3;
				}
				disp_led_simple(tLed.lednum, tLed.led_table_num);
			}
			break;
		case	13://13:赤色点灯 スタートアップリセット
			if (tLed.led_flag == false)
			{
				tLed.lednum = 2;
				disp_led_simple(tLed.lednum, tLed.led_table_num);
				tLed.led_flag = true;
			}
			break;
		case	14://14:水色点滅（1:1秒）ペアリング状態
			if (tLed.led_flag == false)
			{
				if ((tLed.led_1ms_counter/1000)%2 == 0)
				{
					tLed.lednum = 5;
				}
				else
				{
					tLed.lednum = 3;
				}
				disp_led_simple(tLed.lednum, tLed.led_table_num);
			}
			break;
		case	15://15:黄色点灯　ピッチモード刺激動作中
			if (tLed.led_flag == false)
			{
				tLed.lednum = 6;
				disp_led_simple(tLed.lednum, tLed.led_table_num);
				tLed.led_flag = true;
			}
			break;
		case	16://16:黄色点滅（1:2秒）ピッチモードスタンバイ
			if (tLed.led_1ms_counter%1000 == 0)
			{
				if ((tLed.led_1ms_counter/1000)%3 == 0)
				{
					tLed.lednum = 6;
				}
				else if ((tLed.led_1ms_counter/1000)%3 == 1)
				{
					tLed.lednum = 3;
				}
				disp_led_simple(tLed.lednum, tLed.led_table_num);
			}
			break;
		case	17://17:黄色点滅（1:5秒）電源ON_休止 ピッチモード
			if (tLed.led_1ms_counter%1000 == 0)
			{
				if ((tLed.led_1ms_counter/1000)%6 == 0)
				{
					tLed.lednum = 6;
				}
				else if((tLed.led_1ms_counter/1000)%6 == 1)
				{
					tLed.lednum = 3;
				}
				disp_led_simple(tLed.lednum, tLed.led_table_num);
			}
			break;
		case	18://18:黄色点滅（1Hz）一時停止ピッチモード
			if (tLed.led_1ms_counter%1000 == 0)
			{
				if ((tLed.led_1ms_counter/1000)%2 == 0)
				{
					tLed.lednum = 6;
				}
				else
				{
					tLed.lednum = 3;
				}
				disp_led_simple(tLed.lednum, tLed.led_table_num);
			}
			break;

		default:
			break;
	}
	tLed.led_1ms_counter++;
	}
}

//LED_status変更
void led_status_change(int16_t status)
{
	tLed.led_1ms_counter = 0;
	tLed.led_flag = false;
	tLed.led_status = status;
}

//idac出力
void idacRangeStep(uint32_t count)
{
	uint32_t change_count;//（ON:3.25秒の場合：0s:dac設定　3.25s:dacを0）
	if(tSco.mode_status == PITCH)
	{
		change_count = tDynamicTime.pitch_idac_on_time;//0s:dacON　pitch_idac_on_time:dacをOFF
	}
	else
	{
		change_count = 3250;//0s:dac設定　3.25s:dacを0 (3250 * 1000 / 5)
	}
	if (tIdac.idac_stop_flag == false)
	{
		if (count == 0)
		{
			tIdac.idacStep = idac_step[tIdac.stepcount];
			idacSet(idacCurrentRange3, tIdac.idacStep);
			//SCO1,SCO2と同期するためSCOカウンタクリア
			tSco.timer1_sco_flag = OFF;
			tSco.timer1_sco_counter=0;
			tSco.selectems_on_flag = ON;
		}
		else if (count == change_count)
		{
			tIdac.idacStep = idac_step[0];
			idacSet(idacCurrentRange3, tIdac.idacStep);
		}
		else if (count > 0 && count < change_count && tIdac.set_step_flag == true)
		{
			tIdac.idacStep = idac_step[tIdac.stepcount];
			idacSet(idacCurrentRange3, tIdac.idacStep);
			tIdac.set_step_flag = false;
		}
	}
}
// idacON
void idacOn()
{
	if (tIdac.idac_stop_flag == false && tIdac.set_step_flag == true)
	{
		tIdac.idacStep = idac_step[tIdac.stepcount];
		idacSet(idacCurrentRange3, tIdac.idacStep);
		tIdac.set_step_flag = false;
	}
}

// idacを最小値にする
void idacOff()
{
	idacSetStepNum(0);
}

// idacををZeroにする
void idacZero()
{
	tIdac.idacStep = 0;
	idacSet(idacCurrentRange3, tIdac.idacStep);
}

//step +-設定
void idacSetStep(int16_t updown)
{
	int16_t val = tIdac.stepcount + updown;
	if( 1 <= val &&  val <= 22 )
	{
		tIdac.idacStep = idac_step[val];
		tIdac.stepcount = val;
		tIdac.set_step_flag = true;
	}
	//ブザー設定
	if(updown == 0)
	{
		//同じに設定する場合ブザーを鳴らさない（スタティックモードTr3の前でidacが下がったままの場合戻すのみ）
	}
	else if(tIdac.stepcount == 1 || tIdac.stepcount == 22)
	{
		ems_buzzer_set(2, 4);//ステータス:2, 回数:4(ピピピピッ)
	}
	else if(tIdac.stepcount == 5 || tIdac.stepcount == 10 || tIdac.stepcount == 15 || tIdac.stepcount == 20)
	{
		ems_buzzer_set(1, 1);//ステータス:1, 回数:1(ピピッ)
	}
	else
	{
		ems_buzzer_set(0, 1);//ステータス:0, 回数:1(ピッ)
	}
	if(tBuzzer.buzzer_det_off == ON)
	{
		tBuzzer.buzzer_det_after_change=ON;
	}
}
//step設定
void idacSetStepNum(int16_t val)
{
	if( 0<= val &&  val <= 22 )
	{
		tIdac.idacStep = idac_step[val];
		idacSet(idacCurrentRange3, tIdac.idacStep);
		tIdac.stepcount = val;
	}
}

//充電チェック
void charge_check()
{
	tCharge.charge_count++;
	if ((tCharge.charge_count%300) == 0)
	{
		int16_t stat_charge;
		stat_charge = GPIO_PinInGet(CHARGE_PORT,CHARGE_PIN);
		tCharge.charge_error_check_count++;
		if (tKey.stat_charge != stat_charge){
			tKey.stat_charge = stat_charge;
			tKey.count_change_charge++;
		}
		else {
			tKey.count_same_charge++;
		}
		if (tCharge.charge_error_check_count > 3){
			if (tKey.count_change_charge > 2 && tCharge.charge_status != 3){
				//充電エラー
				tCharge.charge_status = 3;
				//LED:赤点滅（2Hz）充電エラー
				led_status_change(3);
			}
			else if (tKey.count_same_charge > 2) {
				if(tKey.stat_charge == 0 && tCharge.charge_status != 2) {
					//充電中
					tCharge.charge_status = 2;
					tCharge.charge_start_flag = true;
					//ブザー設定
					ems_buzzer_set(1, 1);//ステータス:1, 回数:1(ピピッ)
					//トレーニングスタートしていなかった場合
					if(tSco.sco_start_flag != ON)
					{
						//休止状態へ遷移
						ems_statuschange(EMS_STANBY);
						ems_sco_mode_init();
						//LED:青色点灯 充電中
						led_status_change(4);
					}
				}
				else if ((tKey.stat_charge == 1)  && tCharge.charge_status != 1) {
					if (tCharge.charge_start_flag == true){
						//充電完了
						tCharge.charge_status = 1;
						tCharge.charge_start_flag = false;
						//トレーニングスタートしていなかった場合
						if(tSco.sco_start_flag != ON)
						{
							//電源OFFに変更
							set_kill();
						}
					}
					else {
						//未充電
					}
				}
			}
			tCharge.charge_error_check_count = 0;
			tKey.count_change_charge = 0;
			tKey.count_same_charge = 0;
		}
	}

}

// バッテリー残量低下チェック
void battery_voltage_check()
{
	volatile float voltage = 0;
	volatile uint32_t ad_value;
	if(tCharge.battery_error_flag==OFF)
	{
		ad_value = adc_driver_read(BATTERY_VOLTAGE_CH);
		voltage = ((float)ad_value / (float)4096 * (float)3 * 2);
//		voltage -= 0.4;
		if (voltage < 3.4)
		{
			tCharge.battery_error_count++;
		}
		else
		{
			tCharge.battery_error_count=0;
		}

		if (tCharge.battery_error_count > 3)
		{
			tCharge.battery_error_count=0;
			if(tCharge.charge_status != 2)
			{
				ems_buzzer_set(7, 3);//ステータス:7(ピピピッ), 回数:3
				tCharge.battery_error_flag=ON;
			}
		}
	}
}

//パルス設定
void mode_set()
{
	if (tSco.sco_start_flag == ON){
		tSco.timer1_impulse_counter++;
		if(tSco.s_tr_mode == ON)
		{
			if (tSco.mode_status == DYNAMIC)
			{
				//dynamicモード（強弱時間変動あり）
				if (tSco.s_tr_counter >= tDynamicTime.dynamic_ret_time) //強に戻す
				{
					tSco.s_tr_counter = 0;
				}
				if(tSco.s_tr_counter == 0)
				{
					tSco.mode_num=5;
					tSco.timer1_impulse_change_counter = tSco.dynamic_mode5_impulse_change_counter;
					tSco.timer1_burst_time = tSco.dynamic_mode5_burst_time;
					tSco.timer1_selectems_change_counter = tSco.dynamic_mode5_selectems_change_counter;
				}
				else if (tSco.s_tr_counter == tDynamicTime.dynamic_s_time) //弱に変更
				{
					tSco.mode_num=6;
					tSco.timer1_impulse_change_counter = tSco.dynamic_mode6_impulse_change_counter;
					tSco.timer1_burst_time = tSco.dynamic_mode6_burst_time;
					tSco.timer1_selectems_change_counter = tSco.dynamic_mode6_selectems_change_counter;
				}

			}
			else if(tSco.mode_status == STATIC)
			{
				//staticモード（固定）
				if (tSco.s_tr_counter >= 1000000) //5秒
				{
					tSco.s_tr_counter = 0;
				}
				if(tSco.s_tr_counter == 0)
				{
					tSco.mode_num=7;
					tSco.timer1_impulse_change_counter = tSco.static_mode7_impulse_change_counter;
					tSco.timer1_burst_time = tSco.static_mode7_burst_time;
					tSco.timer1_selectems_change_counter = tSco.static_mode7_selectems_change_counter;
				}
				else if (tSco.s_tr_counter == 650000) //3.25秒後
				{
					tSco.mode_num=8;
					tSco.timer1_impulse_change_counter = tSco.static_mode8_impulse_change_counter;
					tSco.timer1_burst_time = tSco.static_mode8_burst_time;
					tSco.timer1_selectems_change_counter = tSco.static_mode8_selectems_change_counter;
				}
			}
			tSco.s_tr_counter++;
		}
		if(tSco.timer1_impulse_counter > 200){//1msec毎
			tSco.timer1_impulse_counter=0;
			if (tIdac.idac_flag == ON)
			{
				//dac出力(スタティック/ピッチモード用)
				idacRangeStep(tIdac.timer1_idac_counter);
				tIdac.timer1_idac_counter++;
				int32_t change_count;
				if (tSco.mode_status == PITCH)
				{
					change_count = (int) tDynamicTime.pitch_idac_ret_time;//ret時間（ON+OFF）(1000 / 5)
				}
				else
				{
					change_count = (int) 5000;//5s（3.25s：1.75s）5*1000
				}
				if(tIdac.timer1_idac_counter>change_count){
					tIdac.timer1_idac_counter=0;
				}
			}
			else
			{
				idacOn();
			}

		}
		//SCO出力ON
		if(tSco.timer1_sco_flag==ON)
		{
			if((tSco.timer1_sco_counter%tSco.timer1_burst_time)==0)
			{	//SC01,SCO2出力処理
				if (tSco.sco_rev_flag == ON)
				{
					ems_sco_out_rev(tSco.timer1_sco_counter/tSco.timer1_burst_time);
				}
				else
				{
					ems_sco_out(tSco.timer1_sco_counter/tSco.timer1_burst_time);
				}
			}
			tSco.timer1_sco_counter++;
			int16_t burst_num = 0;
			if (tSco.mode_status == DYNAMIC)
			{
				burst_num = mode_items_dynamic[tSco.mode_num].burst_num * 4;
			}
			else if (tSco.mode_status == STATIC)
			{
				burst_num = mode_items_static[tSco.mode_num].burst_num * 4;
			}
			else
			{
				burst_num = mode_items_pitch[tSco.mode_num].burst_num * 4;
			}
			if(tSco.timer1_sco_counter/tSco.timer1_burst_time >= burst_num)
			{
				tSco.timer1_sco_flag = OFF;
				tSco.timer1_sco_counter=0;
			}
		}

	}
	else
	{
		//電源ONスタンバイモードの場合（剥がれ検知のためSCO出力する）
		//SCO出力ON
		if(tSco.timer1_sco_flag==ON)
		{
			if((tSco.timer1_sco_counter%tSco.timer1_burst_time)==0)
			{	//SC01,SCO2出力処理
				ems_sco_out(tSco.timer1_sco_counter/tSco.timer1_burst_time);
			}
			tSco.timer1_sco_counter++;
			int16_t burst_num = 0;
			if (tSco.mode_status == DYNAMIC)
			{
				burst_num = mode_items_dynamic[tSco.mode_num].burst_num * 4;
			}
			else if(tSco.mode_status == STATIC)
			{
				burst_num = mode_items_static[tSco.mode_num].burst_num * 4;
			}
			else
			{
				burst_num = mode_items_pitch[tSco.mode_num].burst_num * 4;
			}
			if(tSco.timer1_sco_counter/tSco.timer1_burst_time >= burst_num)
			{
				tSco.timer1_sco_flag = OFF;
				tSco.timer1_sco_counter=0;
			}
		}
	}
}

//パルス設定
void mode_set_pause()
{
	if (tSco.sco_start_flag == ON){
		//電源ONスタンバイモードの場合（剥がれ検知のためSCO出力する）
		//SCO出力ON
		if(tSco.timer1_sco_flag==ON)
		{
			if((tPause.pause_timer1_sco_counter%10)==0)
			{	//SC01,SCO2出力処理
				ems_sco_out(tPause.pause_timer1_sco_counter/10);
			}
			tPause.pause_timer1_sco_counter++;
			if(tPause.pause_timer1_sco_counter/10 >= 8)
			{
				tSco.timer1_sco_flag = OFF;
				tPause.pause_timer1_sco_counter=0;
			}
		}
	}
}

//モード変更
void mode_change()
{
	if (tEMSStat.stat==EMS_NORMAL && tSco.sco_start_flag == ON)
	{
		int16_t change_flag=OFF;
    	struct gecko_msg_hardware_get_time_rsp_t *time = gecko_cmd_hardware_get_time();
		tSco.mode_1s_counter=(uint16_t)(time->seconds - tSco.mode_0_sec);
		if (tSco.mode_status == DYNAMIC)
		{
			if (tSco.mode_num == 0 && tSco.mode_1s_counter >= mode_items_dynamic[0].session_sec){
				tSco.mode_num = 1;
				change_flag = ON;
			}
			else if (tSco.mode_num == 1 && tSco.mode_1s_counter >= mode_items_dynamic[1].session_sec){
				tSco.mode_num = 2;
				change_flag = ON;
			}
			else if (tSco.mode_num == 2 && tSco.mode_1s_counter >= mode_items_dynamic[2].session_sec){
				tSco.mode_num = 3;
				change_flag = ON;
			}
			else if (tSco.mode_num == 3 && tSco.mode_1s_counter >= mode_items_dynamic[3].session_sec){
				tSco.mode_num = 4;
				change_flag = ON;
			}
			else if (tSco.mode_num == 4 && tSco.mode_1s_counter >= mode_items_dynamic[4].session_sec){
				tSco.mode_num = 5;
				change_flag = ON;
				tSco.s_tr_mode = ON;
				tSco.s_tr_counter=0;
			}
			else if ((tSco.mode_num == 5 || tSco.mode_num == 6) && tSco.mode_1s_counter >= mode_items_dynamic[6].session_sec){
				tSco.mode_num = 7;
				change_flag = ON;
				tSco.s_tr_mode = OFF;
				tSco.s_tr_counter=0;
			}
			else if (tSco.mode_num == 7 && tSco.mode_1s_counter >= mode_items_dynamic[7].session_sec){
				tSco.mode_num = 8;
				change_flag = ON;
			}
			else if (tSco.mode_num == 8 && tSco.mode_1s_counter >= mode_items_dynamic[8].session_sec){
				tSco.mode_num = 9;
				change_flag = ON;
			}
			else if (tSco.mode_num == 9 && tSco.mode_1s_counter >= mode_items_dynamic[9].session_sec){
				tSco.mode_num = 10;
				change_flag = ON;
			}
			else if (tSco.mode_num == 10 && tSco.mode_1s_counter >= mode_items_dynamic[10].session_sec){
				tSco.mode_num = 11;
				change_flag = ON;
			}
			else if (tSco.mode_num == 11 && tSco.mode_1s_counter >= mode_items_dynamic[11].session_sec){
				//終了
				ems_sco_mode_init();
				//ブザー設定
				ems_buzzer_set(3, 1);//ステータス:3, 回数:1(ピー)
				//スタンバイ（休止）
				ems_statuschange(EMS_STANBY);
			}
		}
		else if(tSco.mode_status == STATIC)
		{
			if (tSco.mode_num == 0 && tSco.mode_1s_counter >= mode_items_static[0].session_sec){
				tSco.mode_num = 1;
				change_flag = ON;
			}
			else if (tSco.mode_num == 1 && tSco.mode_1s_counter >= mode_items_static[1].session_sec){
				tSco.mode_num = 2;
				change_flag = ON;
			}
			else if (tSco.mode_num == 2 && tSco.mode_1s_counter >= mode_items_static[2].session_sec){
				tSco.mode_num = 3;
				change_flag = ON;
			}
			else if (tSco.mode_num == 3 && tSco.mode_1s_counter >= mode_items_static[3].session_sec){
				tSco.mode_num = 4;
				change_flag = ON;
			}
			else if (tSco.mode_num == 4 && tSco.mode_1s_counter >= mode_items_static[4].session_sec){
				tSco.mode_num = 5;
				change_flag = ON;
				tIdac.idac_flag = ON;
			}
			else if (tSco.mode_num == 5 && tSco.mode_1s_counter >= mode_items_static[5].session_sec){
				tSco.mode_num = 6;
				change_flag = ON;
				tIdac.idac_flag = ON;
			}
			else if (tSco.mode_num == 6 && tSco.mode_1s_counter >= mode_items_static[6].session_sec){
				tSco.mode_num = 7;
				change_flag = ON;
				tSco.s_tr_mode = ON;
				tSco.s_tr_counter=0;
				tIdac.idac_flag = OFF;
				idacSetStep(0);//idacが前トレーニングで下がったままの場合設定する
			}
			else if ((tSco.mode_num == 7 || tSco.mode_num == 8) && tSco.mode_1s_counter >= mode_items_static[8].session_sec){
				tSco.mode_num = 9;
				change_flag = ON;
				tSco.s_tr_mode = OFF;
				tSco.s_tr_counter=0;
			}
			else if (tSco.mode_num == 9 && tSco.mode_1s_counter >= mode_items_static[9].session_sec){
				tSco.mode_num = 10;
				change_flag = ON;
			}
			else if (tSco.mode_num == 10 && tSco.mode_1s_counter >= mode_items_static[10].session_sec){
				tSco.mode_num = 11;
				change_flag = ON;
			}
			else if (tSco.mode_num == 11 && tSco.mode_1s_counter >= mode_items_static[11].session_sec){
				tSco.mode_num = 12;
				change_flag = ON;
			}
			else if (tSco.mode_num == 12 && tSco.mode_1s_counter >= mode_items_static[12].session_sec){
				tSco.mode_num = 13;
				change_flag = ON;
			}
			else if (tSco.mode_num == 13 && tSco.mode_1s_counter >= mode_items_static[13].session_sec){
				//終了
				ems_sco_mode_init();
				//ブザー設定
				ems_buzzer_set(3, 1);//ステータス:3, 回数:1(ピー)
				//スタンバイ（休止）
				ems_statuschange(EMS_STANBY);
			}
		}
		else
		{
			if (tSco.mode_1s_counter >= mode_items_pitch[0].session_sec){
				idacSetStep(0);//idacが前トレーニングで下がったままの場合設定する
				//終了
				ems_sco_mode_init();
				//ブザー設定
				ems_buzzer_set(3, 1);//ステータス:3, 回数:1(ピー)
				//スタンバイ（休止）
				ems_statuschange(EMS_STANBY);
			}
		}

		if (change_flag == ON)
		{
			if (tSco.mode_status == DYNAMIC)
			{
				tSco.timer1_impulse_change_counter = 200000/mode_items_dynamic[tSco.mode_num].inpulse_hz;
				tSco.timer1_burst_time = mode_items_dynamic[tSco.mode_num].burst_usec/20;
				tSco.timer1_selectems_change_counter = 50000/mode_items_dynamic[tSco.mode_num].inpulse_hz;
			}
			else if(tSco.mode_status == STATIC)
			{
				tSco.timer1_impulse_change_counter = 200000/mode_items_static[tSco.mode_num].inpulse_hz;
				tSco.timer1_burst_time = mode_items_static[tSco.mode_num].burst_usec/20;
				tSco.timer1_selectems_change_counter = 50000/mode_items_static[tSco.mode_num].inpulse_hz;
			}
		}
	}
}

//---------------------------------------------------------
// Electrode Det.
//---------------------------------------------------------
void electrode_det()
{
	uint16_t count_limit;
	uint8_t stat = GPIO_PinInGet(ELECTRODEDET_PORT,ELECTRODEDET_PIN);
	if(tKey.stat_det != stat){
		switch(tSco.selectems_num)
		{
		case	0:
			tKey.count_det_0++;
			tKey.count_no_det_0=0;
			break;
		case	1:
			tKey.count_det_1++;
			tKey.count_no_det_1=0;
			break;
		case	2:
			tKey.count_det_2++;
			tKey.count_no_det_2=0;
			break;
		case	3:
			tKey.count_det_3++;
			tKey.count_no_det_3=0;
			break;
		}
	}else{
		switch(tSco.selectems_num)
		{
		case	0:
			tKey.count_det_0=0;
			tKey.count_no_det_0++;
			break;
		case	1:
			tKey.count_det_1=0;
			tKey.count_no_det_1++;
			break;
		case	2:
			tKey.count_det_2=0;
			tKey.count_no_det_2++;
			break;
		case	3:
			tKey.count_det_3=0;
			tKey.count_no_det_3++;
			break;
		}
	}
	//インパルス周波数及びバースト回数による剥がれとみなすカウント数決定
	{
	    if (tSco.mode_status == DYNAMIC)
		{
	        switch(tSco.mode_num){
	        case	0:
	            count_limit = 60;
				break;
	        case	1:
	        case	2:
	            count_limit = 90;
				break;
	        case	3:
	        case	4:
	            count_limit = 120;
				break;
	        case	5:
	        case	6:
	            count_limit = 300;
				break;
	        case	7:
	        case	8:
	            count_limit = 120;
				break;
	        case	9:
	        case   10:
	            count_limit = 90;
				break;
	        case   11:
	            count_limit = 60;
				break;
			default:
	            count_limit = 300;
				break;
	        }
	    }
		else if(tSco.mode_status == STATIC)
		{
	        switch(tSco.mode_num){
	        case	0:
	            count_limit = 60;
				break;
	        case	1:
	        case	2:
	            count_limit = 90;
				break;
	        case	3:
	        case	4:
	            count_limit = 120;
				break;
	        case	5:
	            count_limit = 240;
				break;
	        case	6:
	        case	7:
	        case	8:
	            count_limit = 300;
				break;
	        case	9:
	        case   10:
	            count_limit = 120;
				break;
	        case   11:
	        case   12:
	            count_limit = 90;
				break;
	        case   13:
	            count_limit = 60;
				break;
			default:
	            count_limit = 300;
				break;
	        }
	    }
		else
		{
	        switch(tSco.mode_num){
	        case	0:
	            count_limit = 300;
				break;
			default:
	            count_limit = 300;
				break;
	        }
		}
	}
	if(tKey.count_det_0 > count_limit || tKey.count_det_1 > count_limit || tKey.count_det_2 > count_limit || tKey.count_det_3 > count_limit)
	{	//電極剥がれ(SCOをOFFにする前にチェック)
		tKey.count_det_0=0;
		tKey.count_det_1=0;
		tKey.count_det_2=0;
		tKey.count_det_3=0;
		tKey.count_no_det_0=0;
		tKey.count_no_det_1=0;
		tKey.count_no_det_2=0;
		tKey.count_no_det_3=0;
		if(tBuzzer.buzzer_det_off==OFF)
		{
			if(tEMSStat.stat==EMS_NORMAL)
			{
				//ブザー設定
				ems_buzzer_set(6, 40);//ステータス:6(ピピッ 3秒間隔), 回数:40(約2分)
				tBuzzer.buzzer_det_off=ON;
				//刺激中の場合一時停止
				if (tSco.sco_start_flag == ON)
				{
					ems_statuschange(EMS_PAUSE);
				}
			}
			else if(tEMSStat.stat==EMS_PAUSE)
			{
				//ブザー設定
				ems_buzzer_set(6, 40);//ステータス:6(ピピッ 3秒間隔), 回数:40(約2分)
				tBuzzer.buzzer_det_off=ON;
			}
		}
		else if(tBuzzer.buzzer_det_after_change == ON)//剥がれブザー中に他のブザーを鳴らした場合ブザーを戻す
		{
			//ブザー設定
			ems_buzzer_set(6, 40);//ステータス:6(ピピッ 3秒間隔), 回数:40(約2分)
			tBuzzer.buzzer_det_after_change=OFF;
		}
	}
	if(tBuzzer.buzzer_det_off==ON && tKey.count_no_det_0 > count_limit && tKey.count_no_det_1 > count_limit && tKey.count_no_det_2 > count_limit && tKey.count_no_det_3 > count_limit)
	{	//電極剥がれから復帰(SCOをOFFにする前にチェック)
		tKey.count_det_0=0;
		tKey.count_det_1=0;
		tKey.count_det_2=0;
		tKey.count_det_3=0;
		tKey.count_no_det_0=0;
		tKey.count_no_det_1=0;
		tKey.count_no_det_2=0;
		tKey.count_no_det_3=0;
		//ブザー設定
		ems_buzzer_set(99, 0);//ステータス:99ブザー消音
		tBuzzer.buzzer_det_off=OFF;
	}
}

void sco_start()
{
	if(tEMSStat.stat!=EMS_NORMAL)
	{
		//通常処理遷移
		ems_statuschange(EMS_NORMAL);
	}
	//刺激開始時間取得
    struct gecko_msg_hardware_get_time_rsp_t *time = gecko_cmd_hardware_get_time();
    tSco.mode_0_sec=time->seconds;

	tSco.sco_start_flag=ON;
	if(tIdac.stepcount==0)
	{
		idacSetStepNum(1);
	}
	if (tSco.mode_status == DYNAMIC)
	{
		//ブザー設定
		ems_buzzer_set(0, 1);//ステータス:0, 回数:1(ピッ)
		//LED:橙色点灯　ダイナミックモード刺激動作中
		led_status_change(8);
	}
	else if(tSco.mode_status == STATIC)
	{
		//ブザー設定
		ems_buzzer_set(0, 1);//ステータス:0, 回数:1(ピッ)
		//LED:緑色点灯 スタティックモード刺激動作中
		led_status_change(2);
	}
	else
	{
		//ブザー設定
		ems_buzzer_set(0, 1);//ステータス:0, 回数:1(ピッ)
		//LED:黄色点灯 ピッチモード刺激動作中
		led_status_change(15);
	}
}

void set_mode_status(uint8_t mode)
{
	tSco.mode_status=mode;
}

void sco_stop()
{
	//ブザー
	ems_buzzer_set(3, 1);//ステータス:3, 回数:1(ピー)
	//スタンバイ（休止）
	if(tEMSStat.stat!=EMS_STANBY)
	{
		ems_statuschange(EMS_STANBY);
	}
	ems_sco_mode_init();
}

void button_mode_change(uint8_t mode)
{
	//モード変更
	set_mode_status(mode);
	if(tBuzzer.buzzer_det_off!=ON)
	{
		ems_buzzer_set(1, 1);//ステータス:1, 回数:1(ピピッ)
	}
	if(mode == DYNAMIC)
	{
		//LED:橙色点滅（1:2秒）ダイナミックモードスタンバイ
		led_status_change(9);
	}
	else if(mode == STATIC)
	{
		//LED:緑色点滅（1:2秒）スタティックモードスタンバイ
		led_status_change(10);
	}
	else
	{
		//LED:黄色点滅（1:2秒）ピッチモードスタンバイ
		led_status_change(16);
	}
	idacOff();
}

uint16_t get_idac_stepcount()
{
	return tIdac.stepcount;
}

bool get_sco_start_flag()
{
	return tSco.sco_start_flag;
}

uint16_t get_mode_time()
{
	int16_t mode_s = 0;
	if(tSco.sco_start_flag==ON)
	{
		mode_s = tSco.mode_1s_counter;
	}
	return mode_s;
}

uint8_t get_mode()
{
	return tSco.mode_status;
}

uint8_t get_ems_stat()
{
	uint8_t ems_stat;
	if(tEMSStat.stat==EMS_PAUSE)
	{
		ems_stat=3;//一時停止
	}
	else if(tEMSStat.stat==EMS_STANBY)
	{
		ems_stat=0;//休止
	}
	else if(tEMSStat.stat==EMS_NORMAL)
	{
		if(tSco.sco_start_flag==ON)
		{
			ems_stat=2;//刺激中
		}
		else
		{
			ems_stat=1;//スタンバイ
		}
	}
	else if(tEMSStat.stat==EMS_PAIRING)
	{
		ems_stat=4;//ペアリング
	}
	else
	{
		ems_stat=5;//起動時リセット

	}
	return ems_stat;
}

uint8_t get_e_det()
{
	uint8_t det;
	if(tBuzzer.buzzer_det_off==ON)
	{
		det=1;
	}
	else
	{
		det=0;
	}
	return det;
}

uint8_t get_error_code()
{
	return tEMSStat.error_code;
}


void ems_pause()
{
	if (tEMSStat.stat==EMS_NORMAL)
	{
		if (tSco.sco_start_flag == ON)
		{
			ems_statuschange(EMS_PAUSE);
		}
	}
	else if (tEMSStat.stat==EMS_PAUSE)
	{
		if(tBuzzer.buzzer_det_off==OFF)
		{
			//一時停止2分タイマー停止
			pause_timer_reset();
			//剥がれがない場合刺激再スタート
			sco_start();
		}
	}
}

void ems_statuschange_nomal()
{
	if (tEMSStat.stat!=EMS_NORMAL)
	{
		ems_statuschange(EMS_NORMAL);
		ems_sco_mode_init();
	}
}

void set_kill()
{
	GPIO_PinModeSet(KILL_PORT,KILL_PIN,gpioModePushPull,0);
}

void mode_1s_counter_up()
{
	if (tEMSStat.stat==EMS_NORMAL && tSco.sco_start_flag == ON)
	{
		tSco.mode_1s_counter++;
	}
}

void dynamic_operation_time_set(uint8_t operation_time_m)
{
	if(operation_time_m == 0)
	{
		operation_time_m = 30;
	}
	tDynamicTimeReal.tr_time = operation_time_m;
	tSco.dynamic_operation_time = ((int16_t)operation_time_m - 30) * 60;
	//ダイナミックモードのsession_sec変更
	mode_items_dynamic[6].session_sec = dynamic_session_sec_default[6] + tSco.dynamic_operation_time;
	mode_items_dynamic[7].session_sec = dynamic_session_sec_default[7] + tSco.dynamic_operation_time;
	mode_items_dynamic[8].session_sec = dynamic_session_sec_default[8] + tSco.dynamic_operation_time;
	mode_items_dynamic[9].session_sec = dynamic_session_sec_default[9] + tSco.dynamic_operation_time;
	mode_items_dynamic[10].session_sec = dynamic_session_sec_default[10] + tSco.dynamic_operation_time;
	mode_items_dynamic[11].session_sec = dynamic_session_sec_default[11] + tSco.dynamic_operation_time;
}

void ems_stanby()
{
	ems_statuschange(EMS_STANBY);
}

uint16_t ems_pause_stepcount()
{
	return tPause.pause_stepcount;
}

void set_dynamic_time(uint16_t s_time, uint16_t w_time)
{
	tDynamicTimeReal.s_time = s_time;//強時間：単位:msec
	tDynamicTimeReal.w_time = w_time;//弱時間：単位:msec
	tDynamicTime.dynamic_s_time = s_time * EMS_DYNAMIC_S_TIME_PERCENTAGE * 2;//強時間 単位：5μs ( % / 100 * 1000 / 5 )
	tDynamicTime.dynamic_w_time = w_time * EMS_DYNAMIC_W_TIME_PERCENTAGE * 2;//強時間 単位：5μs ( % / 100 * 1000 / 5 )
	tDynamicTime.dynamic_ret_time = tDynamicTime.dynamic_s_time + tDynamicTime.dynamic_w_time;//強時間＋弱時間 単位：5μs
}

void get_dynamic_time(uint8_t *s_time_u, uint8_t *s_time_d, uint8_t *w_time_u, uint8_t *w_time_d, uint8_t *tr_time)
{
	if(tSco.mode_status == DYNAMIC && tSco.sco_start_flag == ON)
	{
		//ダイナミックモード刺激中
		*s_time_u = tDynamicTimeReal.s_time >> 8;
		*s_time_d = tDynamicTimeReal.s_time;
		*w_time_u = tDynamicTimeReal.w_time >> 8;
		*w_time_d = tDynamicTimeReal.w_time;
		*tr_time = tDynamicTimeReal.tr_time;
	}
	else
	{
		*s_time_u = ems_flash_dynamic_time_data.s_time >> 8;
		*s_time_d = ems_flash_dynamic_time_data.s_time;
		*w_time_u = ems_flash_dynamic_time_data.w_time >> 8;
		*w_time_d = ems_flash_dynamic_time_data.w_time;
		*tr_time = ems_flash_dynamic_time_data.tr_time;
	}
}

void led_off()
{
	tLed.led_ON_flag = OFF;
}

void pitch_operation_time_set(uint8_t pitch_operation_time_m)
{
	if(pitch_operation_time_m == 0)
	{
		pitch_operation_time_m = 60;
	}
	tPitchTimeReal.tr_time = pitch_operation_time_m;
	tSco.pitch_operation_time = (pitch_operation_time_m - 60) * 60;
	//ピッチモードのsession_sec変更
	mode_items_pitch[0].session_sec = pitch_session_sec_default + tSco.pitch_operation_time;
}

void set_pitch_time(uint16_t on_time, uint16_t off_time)
{
	tPitchTimeReal.idac_on_time = on_time;//idac ON時間：単位:msec
	tPitchTimeReal.idac_off_time = off_time;//idac OFF時間：単位:msec
	tDynamicTime.pitch_idac_on_time = on_time * EMS_PITCH_ON_TIME_PERCENTAGE / 100;//idac ON時間：単位:msec
	tDynamicTime.pitch_idac_off_time = off_time * EMS_PITCH_OFF_TIME_PERCENTAGE /100;//idac OFF時間：単位:msec
	tDynamicTime.pitch_idac_ret_time = tDynamicTime.pitch_idac_on_time + tDynamicTime.pitch_idac_off_time;//ON時間＋OFF時間
}

void get_pitch_time(uint8_t *on_time_u, uint8_t *on_time_d, uint8_t *off_time_u, uint8_t *off_time_d, uint8_t *p_tr_time)
{
	if(tSco.mode_status == PITCH && tSco.sco_start_flag == ON)
	{
		//ピッチモード刺激中
		*on_time_u = tPitchTimeReal.idac_on_time >> 8;
		*on_time_d = tPitchTimeReal.idac_on_time;
		*off_time_u = tPitchTimeReal.idac_off_time >> 8;
		*off_time_d = tPitchTimeReal.idac_off_time;
		*p_tr_time = tPitchTimeReal.tr_time;
	}
	else
	{
		*on_time_u = ems_flash_dynamic_time_data.pitch_idac_on_time >> 8;
		*on_time_d = ems_flash_dynamic_time_data.pitch_idac_on_time;
		*off_time_u = ems_flash_dynamic_time_data.pitch_idac_off_time >> 8;
		*off_time_d = ems_flash_dynamic_time_data.pitch_idac_off_time;
		*p_tr_time = ems_flash_dynamic_time_data.pitch_tr_time;
	}
}
