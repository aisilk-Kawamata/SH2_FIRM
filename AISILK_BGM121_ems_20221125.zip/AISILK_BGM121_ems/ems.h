/*
 * ems.h
 *
 *  Created on: 2018/04/09
 *      Author: scrum
 */
#include <stdbool.h>
#include "i2cspm.h"

#ifndef EMS_H_
#define EMS_H_

#define EMS_DYNAMIC_S_TIME_PERCENTAGE			88 /* ダイナミックモード強時間調整(%) */
#define EMS_DYNAMIC_W_TIME_PERCENTAGE			95 /* ダイナミックモード弱時間調整(%) */
#define EMS_PITCH_ON_TIME_PERCENTAGE			87 /* ピッチモードON時間調整(%) */
#define EMS_PITCH_OFF_TIME_PERCENTAGE			87 /* ピッチモードOFF時間調整(%) */


void ems_init(void);
void ems_timer(void);

void ems_hvcont_init(void);
void ems_hvcont_out(void);
void ems_hvcont_start(void);
void ems_hvcont_stop(void);
void ems_selectems();

void ems_sco_init(int16_t type);
void ems_sco_mode_init();
void ems_sco_out(int16_t count);
void ems_sco_out_rev(int16_t count);

void ems_key_init(void);
void ems_startup_key_check(void);
void ems_key_check(void);

void ems_buzzer_init(void);
void ems_buzzer_rawout(uint16_t onoff);
void ems_buzzer_out(void);
void ems_buzzer_set(int8_t set_buzzer_status, int set_buzzer_count);
void led_check();
void led_status_change(int16_t status);
void idacRangeStep(uint32_t count);
void idacSetStepNum(int16_t val);
void idacSetStep(int16_t updown);
void idacOn();
void idacOff();
void idacZero();
void charge_check();
void battery_voltage_check();
void mode_set();
void mode_set_pause();
void mode_change();
void electrode_det();
void sco_start();
void set_mode_status(uint8_t mode);
void sco_stop();
void button_mode_change(uint8_t mode);
uint16_t get_idac_stepcount();
bool get_sco_start_flag();
uint16_t get_mode_time();
uint8_t get_mode();
uint8_t get_ems_stat();
uint8_t get_e_det();
uint8_t get_error_code();
void ems_pause();
void ems_statuschange_nomal();
void set_kill();
void mode_1s_counter_up();
void dynamic_operation_time_set(uint8_t operation_time_m);
void ems_stanby();
uint16_t ems_pause_stepcount();
void set_dynamic_time(uint16_t s_time, uint16_t w_time);
void get_dynamic_time(uint8_t *s_time_u, uint8_t *s_time_d, uint8_t *w_time_u, uint8_t *w_time_d, uint8_t *tr_time);
void led_off();
void pitch_operation_time_set(uint8_t pitch_operation_time_m);
void set_pitch_time(uint16_t on_time, uint16_t off_time);
void get_pitch_time(uint8_t *on_time_u, uint8_t *on_time_d, uint8_t *off_time_u, uint8_t *off_time_d, uint8_t *p_tr_time);


//HVCONT
#define	HVCONT_PORT	gpioPortD
#define	HVCONT_PIN	14

//SCO1,SCO2
#define	SCO1_PORT	gpioPortD
#define	SCO1_PIN	10

#define	SCO2_PORT	gpioPortD
#define	SCO2_PIN	11


//Key down,up,mode
#define	KEY_DOWN_PORT	gpioPortD
#define	KEY_DOWN_PIN	9
#define	KEY_UP_PORT		gpioPortB
#define	KEY_UP_PIN		13
#define	KEY_MODE_PORT	gpioPortC
#define	KEY_MODE_PIN	10
#define	ELECTRODEDET_PORT	gpioPortB
#define	ELECTRODEDET_PIN	11
#define	CHARGE_PORT	gpioPortF
#define	CHARGE_PIN	7

#define	KEY_THRESHOLD		20
#define	KEY_THRESHOLD_2000	2000

#define		ON	1
#define		OFF	0


#define		STATIC	0
#define		DYNAMIC	1
#define		PITCH	2

//buzzer
#define	BUZZER_PORT		gpioPortB
#define	BUZZER_PIN		12

//kill
#define	KILL_PORT		gpioPortF
#define	KILL_PIN		4

#endif /* EMS_H_ */
