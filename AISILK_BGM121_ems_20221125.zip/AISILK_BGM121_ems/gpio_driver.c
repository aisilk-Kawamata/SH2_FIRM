/*
 * gpio_driver.c
 *
 *  Created on: 2017/08/07
 *      Author: D-CLUE
 */
#include "em_cmu.h"
#include "em_gpio.h"

#include "gpio_driver.h"

#include "idac_driver.h"
#include "timer_driver.h"
#include "ems.h"

/*
const unsigned int GPIO_PIN_UPBTN = 9;
const unsigned int GPIO_PIN_DWBTN = 13;
const unsigned int GPIO_PIN_MDBTN = 10;
const unsigned int GPIO_PIN_EDET = 11;
*/
const uint8_t GPIO_PIN_MODE_LONG = 4;

bool down_flag = false;

void gpio_driver_init(void)
{
	CMU_ClockEnable(cmuClock_HFPER, true);

	CMU_ClockEnable(cmuClock_GPIO, true);
	GPIO_PinModeSet(CHARGING_PORT, CHARGING_PIN, gpioModeInput, 0);

	// Configure PB11(e_det) as an input for button with filter enable (out = 1)
	GPIO_PinModeSet(gpioPortA, GPIO_PIN_MODE_LONG, gpioModeInputPull, 1);// e_det

	// ボタンの割り込み設定
	GPIO_ExtIntConfig(gpioPortA, GPIO_PIN_MODE_LONG, GPIO_PIN_MODE_LONG, false, true, true); //falling edge割り込み発生
	//GPIO_ExtIntConfig(gpioPortD, GPIO_PIN_UPBTN, GPIO_PIN_UPBTN, false, true, true); //rising edge割り込み発生
/*
	 //up down:
	 	 //up key = PD9, // pin:7
		 //down key = PB13  // pin:22

	// Configure PB13(down) and PD9(up) as an input for button with filter enable (out = 1)
	GPIO_PinModeSet(gpioPortD, GPIO_PIN_UPBTN, gpioModeInputPull, 1);// up key
	GPIO_PinModeSet(gpioPortB, GPIO_PIN_DWBTN, gpioModeInputPull, 1);// down key
	// Configure PC10(mode) as an input for button with filter enable (out = 1)
	GPIO_PinModeSet(gpioPortC, GPIO_PIN_MDBTN, gpioModeInputPull, 1);// mode key
	// Configure PB11(e_det) as an input for button with filter enable (out = 1)
	GPIO_PinModeSet(gpioPortB, GPIO_PIN_EDET, gpioModeInputPull, 1);// e_det

	// Configure PD9(up) interrupt on falling edge
	// ボタンの割り込み設定
	//GPIO_ExtIntConfig(gpioPortD, GPIO_PIN_UPBTN, GPIO_PIN_UPBTN, false, true, true); //rising edge割り込み発生
	GPIO_ExtIntConfig(gpioPortD, GPIO_PIN_UPBTN, GPIO_PIN_UPBTN, false, true, true); //falling edge割り込み発生

	// Configure PB13(down) interrupt on falling edge
	//GPIO_ExtIntConfig(gpioPortB, GPIO_PIN_DWBTN, GPIO_PIN_DWBTN, false, true, true); //rising edge割り込み発生
	GPIO_ExtIntConfig(gpioPortB, GPIO_PIN_DWBTN, GPIO_PIN_DWBTN, false, true, true); //falling edge割り込み発生

	// Configure PC10(mode) interrupt on falling edge
	//GPIO_ExtIntConfig(gpioPortC, GPIO_PIN_MDBTN, GPIO_PIN_MDBTN, true, true, true); //押したとき、離したときの両方で割り込み発生
	GPIO_ExtIntConfig(gpioPortC, GPIO_PIN_MDBTN, GPIO_PIN_MDBTN, false, true, true); //押したときに割り込み発生

	// Configure PB11(e_det) interrupt on falling edge
	GPIO_ExtIntConfig(gpioPortB, GPIO_PIN_EDET, GPIO_PIN_EDET, false, true, true); //falling edge割り込み発生
*/
	// Enable GPIO_EVEN interrupt vector in NVIC
	NVIC_ClearPendingIRQ(GPIO_EVEN_IRQn); //残っている割り込みクリア
	NVIC_EnableIRQ(GPIO_EVEN_IRQn);

	// Enable GPIO_ODD interrupt vector in NVIC
	NVIC_ClearPendingIRQ(GPIO_ODD_IRQn); //残っている割り込みクリア
	NVIC_EnableIRQ(GPIO_ODD_IRQn);

}

uint32_t gpio_driver_read(uint32_t no)
{
	uint32_t value;

	switch(no) {
	case CHARGING_NO:
		value = GPIO_PinInGet(CHARGING_PORT, CHARGING_PIN);
		break;

	default:
		value = 0;
	}
	return value;
}

void GPIO_EVEN_IRQHandler(void)
{
	uni_gpio_setStep();
}

void GPIO_ODD_IRQHandler(void)
{
	uni_gpio_setStep();
}

void uni_gpio_setStep(void)
{

	//clear flag for interrupt
	//GPIO->IFC = GPIO->IF;
	uint32_t interruptMask = GPIO_IntGet();
	GPIO_IntClear(interruptMask);

	// 割り込み要因がPush Button Controller(モード長押し)ボタンであれば、ブザー音開始　電源OFF
	if (interruptMask & (1 << GPIO_PIN_MODE_LONG)) {
		//ブザー設定
		ems_buzzer_set(5, 2);//ステータス:5, 回数:2(ピーピー)
		//set_kill();//ここでkill入れると音がなる前に切れてしまう
	}
/*
	// 割り込み要因がupボタンであれば、idacのstep変更up / LEDテスト　輝度変更up
	if (interruptMask & (1 << GPIO_PIN_UPBTN)) {
		idacSetStep(1);
		//test_led_table_num_set(1);//輝度変更
	}
	// 割り込み要因がdownボタンであれば、idacのstep変更down / LEDテスト　輝度変更down
	if (interruptMask & (1 << GPIO_PIN_DWBTN)) {
		idacSetStep(-1);
		//test_led_table_num_set(-1);//輝度変更
	}
	// 割り込み要因がmodeボタンであれば、緑点滅LED　ON/OFF
	if (interruptMask & (1 << GPIO_PIN_MDBTN)) {
		//test_led_g_flag_change();
	}
	// 剥がれ検知
	if (interruptMask & (1 << GPIO_PIN_EDET)) {
		// 剥がれた時の処理

	}
*/
}

