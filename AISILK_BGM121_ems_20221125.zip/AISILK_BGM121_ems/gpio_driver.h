/*
 * gpio_driver.h
 *
 *  Created on: 2017/08/07
 *      Author: D-CLUE
 */

#ifndef GPIO_DRIVER_H_
#define GPIO_DRIVER_H_

#define CHARGING_NO		1
#define CHARGING_PORT	gpioPortF
#define CHARGING_PIN		7

extern void gpio_driver_init(void);
extern uint32_t gpio_driver_read(uint32_t no);
extern void uni_gpio_setStep(void);


#endif /* GPIO_DRIVER_H_ */
