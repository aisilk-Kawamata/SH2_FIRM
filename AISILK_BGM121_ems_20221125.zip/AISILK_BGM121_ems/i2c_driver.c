/*
 * i2c_driver.c
 *
 *  Created on: 2018/04/04
 *      Author: ScrumSoftware
 */

/* i2c */
#include "i2c_driver.h"
#include "i2cspm.h"

//テスト用
/*
int i2c_error_Nack=0;
int i2c_error_BusErr=0;
int i2c_error_ArbLost=0;
int i2c_error_UsageFault=0;
int i2c_error_SwFault=0;
int i2c_error_InProgress=0;
int i2c_ok_count=0;
int i2c_error_count=0;
*/

I2CSPM_Init_TypeDef   i2cInit = I2CSPM_INIT_DEFAULT;
void ems_I2C_init()
{
	I2CSPM_Init(&i2cInit);

	//config
	uint8_t addr = 0x20<<1 | 0;/*WRITE*/;
	uint8_t command;
	uint8_t val;
	uint8_t len = 2;

	command = 0x03; // Command:Configuration register
	val = 0x00;
	I2C_write(addr, command, val, len);
}

/***************************************************************************//**
 * @brief
 *   Write to sensor register.
 *
 * @param[in] i2c
 *   Pointer to I2C peripheral register block.
 *
 * @param[in] addr
 *   I2C address
 *   for W bit.
 *
 * @param[in] command
 *   Value used when writing.
 *
 * @param[in] val
 *   Value used when writing.
 *
 * @return
 *   Returns 0 if register written, <0 if unable to write.
 ******************************************************************************/
I2C_TransferReturn_TypeDef I2C_write(uint8_t addr, uint8_t command, uint8_t val, uint16_t len)
{
	// テスト用コード
	  I2C_TransferSeq_TypeDef    seq;
	  I2C_TransferReturn_TypeDef ret;
	  uint8_t                    data[2];

	  seq.addr  = addr;
	  seq.flags = I2C_FLAG_WRITE;

	  data[0]         = command;
	  data[1]         = val;
	  seq.buf[0].data = data;
	  seq.buf[0].len = len;
	  seq.buf[1].data = 0;
	  seq.buf[1].len = 0;

	  ret = I2CSPM_Transfer(i2cInit.port, &seq);
//テスト用
/*
	  switch(ret)
	  {
		case	i2cTransferDone:
			i2c_ok_count++;
			break;
		case	i2cTransferNack:
			i2c_error_Nack++;
			break;
		case	i2cTransferBusErr:
			i2c_error_BusErr++;
			break;
		case	i2cTransferArbLost:
			i2c_error_ArbLost++;
			break;
		case	i2cTransferUsageFault:
			i2c_error_UsageFault++;
			break;
		case	i2cTransferSwFault:
			i2c_error_SwFault++;
			break;
		case	i2cTransferInProgress:
			i2c_error_InProgress++;
			break;
		default:
			i2c_error_count++;
			break;
	  }
*/
	  return ret;

}
