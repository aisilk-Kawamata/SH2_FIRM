/*
 * i2c_driver.c
 *
 *  Created on: 2018/04/04
 *      Author: ScrumSoftware
 */
#include "i2cspm.h"

void ems_I2C_init(void);
I2C_TransferReturn_TypeDef I2C_write(uint8_t addr, uint8_t command, uint8_t val, uint16_t len);

