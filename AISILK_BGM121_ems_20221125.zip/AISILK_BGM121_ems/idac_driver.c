/*
 * idac_driver.c
 *
 *  Created on: 2018/04/06
 *      Author: ScrumSoftware
 */

#include "em_cmu.h"
#include "em_idac.h"
#include "em_gpio.h"

#include "idac_driver.h"

/* IDAC current range base current in nA */
//uint32_t idacRangeStart[4] = {50, 1600, 500, 2000};

/* IDAC current step size in nA */
//uint32_t idacStepSize[4] = {50, 100, 500, 2000};


/* These values are used to program IDAC current output.
 * They are changed by the GPIO interrupt handlers.
 */
static volatile IDAC_Range_TypeDef idacRange = idacCurrentRange3;

void idacInit()
{
	/* Enable IDAC clock */
	  CMU_ClockEnable(cmuClock_IDAC0, true);

	  IDAC_Init_TypeDef idacInit =
	  {
	    .enable 		= true,
	    .outMode 		= idacOutputAPORT1YCH7,
	    .prsEnable 		= false,
	    .prsSel 		= idacPRSSELCh0,
	    .sinkEnable 	= false,
	  };

	  IDAC_Init(IDAC0, &idacInit);

	  /* Enable Vdd range */
	  //IDAC0->CTRL |= (1<<12);

	  IDAC_RangeSet(IDAC0, idacRange);
	  IDAC_StepSet(IDAC0, 0);

	  /* Enable IDAC Current out */
	  IDAC_OutEnable(IDAC0, true);

}
void idacSet(int16_t range, int16_t step)
{
	IDAC_RangeSet(IDAC0, range);
	IDAC_StepSet(IDAC0, step);
}



