/*
 * idac_driver.h
 *
 *  Created on: 2018/04/06
 *      Author: ScrumSoftware
 */


void idacInit();
void idacSet(int16_t range, int16_t step);

