/***********************************************************************************************//**
 * \file	 main.c
 * \brief	Silicon Labs Empty Example Project
 *
 * This example demonstrates the bare minimum needed for a Blue Gecko C application
 * that allows Over-the-Air Device Firmware Upgrading (OTA DFU). The application
 * starts advertising after boot and restarts advertising after a connection is closed.
 ***************************************************************************************************
 * <b> (C) Copyright 2016 Silicon Labs, http://www.silabs.com</b>
 ***************************************************************************************************
 * This file is licensed under the Silabs License Agreement. See the file
 * "Silabs_License_Agreement.txt" for details. Before using this software for
 * any purpose, you must agree to the terms of that agreement.
 **************************************************************************************************/
#include <ctype.h>	//for HARDWARE_ASICS
#include "stdio.h"
#include "string.h"

/* Board headers */
#include "boards.h"
#include "ble-configuration.h"
#include "board_features.h"

/* Bluetooth stack headers */
#include "bg_types.h"
#include "native_gecko.h"
#include "gatt_db.h"
#include "aat.h"

/* Libraries containing default Gecko configuration values */
#include "em_emu.h"
#include "em_cmu.h"
#ifdef FEATURE_BOARD_DETECTED
#include "bspconfig.h"
#include "pti.h"
#endif

/* Device initialization header */
#include "InitDevice.h"

/* i2c */
#include "i2cspm.h"		//for HARDWARE_ASICS
#include "i2c_driver.h"	//for HARDWARE_ASICS

/* idac */
#include "idac_driver.h" //for HARDWARE_ASICS

#ifdef FEATURE_SPI_FLASH
#include "em_usart.h"
#include "mx25flash_spi.h"
#endif /* FEATURE_SPI_FLASH */

#include "main.h"
#include "adc_driver.h"
#include "gpio_driver.h"
#include "timer_driver.h"
#include "uart_driver.h"
#include "spi_driver.h"
#include "emg.h"

#if defined (HARDWARE_ASICS)
#include "ems.h"
#endif
/***********************************************************************************************//**
 * @addtogroup Application
 * @{
 **************************************************************************************************/

uint8_t		Connection_Id = 0;
uint8_t		Send_Data[ATT_DEFAULT_PAYLOAD_LEN];

uint64_t		Sync_Time;
bool			Measure_Flag;
bool			Calib_Flag;
bool			Connection_Flag;

struct		_ConfigData_t confData[NUM_SAMPLES];
char			device_name[16];
struct		gecko_msg_flash_ps_load_rsp_t *psResp;
uint8_t		Flash_Data[4];
uint8_t		Flash_Data_DeviceName[1];
#if defined (HARDWARE_ASICS)
struct		_EMS_Flash_Data_t ems_flash_data;
struct		_EMS_Flash_Dynamic_Time_Data_t ems_flash_dynamic_time_data;
#endif

uint32_t		EMG_Tint = (CONF_EMG_TINT_200 * 100);
uint32_t		ECG_Tav = (CONF_ECG_TAV_20 * 20);
uint8_t		Wear_ID;

uint32_t		Analysis_Data_Write_Cnt;
bool			Analysis_Data_OverFlow;
uint64_t		Analysis_Time;
uint32_t		Analysis_Data_Write_Address;
uint32_t		Analysis_Data_Read_Address;
bool			Analysis_Flag;
bool			Analysis_Data_Send_Comp_Flag;

struct		_LedStrong_t ledStrong;
#if !defined (HARDWARE_ASICS)
void Conf_Data_Init(void);
#endif
void data_analysis(uint8array *writeValue);

#if defined (HARDWARE_ASICS)
void EMS_PS_Data_Init(void);
#endif

bool        CLed_Req_Flag;
#if defined (HARDWARE_ASICS)
uint8_t     mode;
uint8_t		test_led_status;
uint8_t		test_led_color;
uint32_t	test_led_start_time;
#endif

/***********************************************************************************************//**
 * @addtogroup app
 * @{
 **************************************************************************************************/

#ifndef MAX_CONNECTIONS
#define MAX_CONNECTIONS 4
#endif
uint8_t bluetooth_stack_heap[DEFAULT_BLUETOOTH_HEAP(MAX_CONNECTIONS)];

#ifdef FEATURE_PTI_SUPPORT
static const RADIO_PTIInit_t ptiInit = RADIO_PTI_INIT;
#endif

/* Gecko configuration parameters (see gecko_configuration.h) */
static const gecko_configuration_t config = {
	.config_flags = 0,
	//.sleep.flags = SLEEP_FLAGS_DEEP_SLEEP_ENABLE,
	.sleep.flags = 0,
	 .bluetooth.max_connections = MAX_CONNECTIONS,
	.bluetooth.heap = bluetooth_stack_heap,
	.bluetooth.heap_size = sizeof(bluetooth_stack_heap),
	.bluetooth.sleep_clock_accuracy = 100, // ppm
	.gattdb = &bg_gattdb_data,
	.ota.flags = 0,
	.ota.device_name_len = 3,
	.ota.device_name_ptr = "OTA",
	#ifdef FEATURE_PTI_SUPPORT
	.pti = &ptiInit,
	#endif
};

/* Flag for indicating DFU Reset must be performed */
uint8_t boot_to_dfu = 0;

bool test_flag_main = false;
void gpio_test_main(void)
{
	if (test_flag_main == false) {
		test_flag_main = true;
		GPIO_PinModeSet(gpioPortC, 10, gpioModePushPull, 0);
	}
	else {
		test_flag_main = false;
		GPIO_PinModeSet(gpioPortC, 10, gpioModePushPull, 1);
	}
}

/**
 * @brief	Main function
 */
int main(void)
{
	uint32_t i;
#if !defined (HARDWARE_ASICS)
	char temp[2];
	int wear_id;
#endif
//	int16_t wdata;
//	int16_t rdata;
//	bool flag;
#if defined (HARDWARE_ASICS)
	uint8_t bondCntSum=0;
	uint8_t bondCnt=0;
	uint8_t bondCntPlus=0;
	int8_t ems_stat;
	int8_t ems_det;
	uint8_t idac_timer_count=0;
#endif

#ifdef FEATURE_SPI_FLASH
	/* Put the SPI flash into Deep Power Down mode for those radio boards where it is available */
	MX25_init();
	MX25_DP();
	/* We must disable SPI communication */
	USART_Reset(USART1);

#endif /* FEATURE_SPI_FLASH */

	/* Initialize peripherals */
	enter_DefaultMode_from_RESET();

	/* Initialize stack */
	gecko_init(&config);

	gpio_driver_init();
	//uart0_driver_init();
#if !defined (HARDWARE_ASICS)
	uart1_driver_init();
	timer0_driver_init();
	timer0_driver_start();
	timer1_driver_init();
	timer1_driver_start();
	adc_driver_init();
	emg_data_init();
	spi0_driver_init();
#else
	//I2C
	ems_I2C_init();

	//IDAC
	idacInit();

	//ems初期化
	ems_init();

	uart1_driver_init();
	timer1_driver_init();
	timer1_driver_start();
	timer_driver_init_pwm();
	timer0_driver_init();
	timer0_driver_start();
	adc_driver_init();
	spi0_driver_init();


#endif

	Measure_Flag = false;
	Calib_Flag = false;
	Connection_Flag = false;
	CLed_Req_Flag = false;

	while (1) {
		/* Event pointer for handling events */
		struct gecko_cmd_packet* evt;

		/* Check for stack event. */
		evt = gecko_wait_event();

		/* Handle events */
		switch (BGLIB_MSG_ID(evt->header)) {
			/* This boot event is generated when the system boots up after reset.
			 * Here the system is set to start advertising immediately after boot procedure. */
			case gecko_evt_system_boot_id:
#if !defined (HARDWARE_ASICS)
				/* Config Data */
				Conf_Data_Init();
#endif
#if defined (HARDWARE_ASICS)
				//EMS
				EMS_PS_Data_Init();
#endif
				/* BLE Packet Size : 55[Byte] */
				gecko_cmd_gatt_set_max_mtu(ATT_DEFAULT_PAYLOAD_LEN + 3);

				/* Advertising Local Name */
					for (i=0; i<16; i++) { device_name[i] = 0x00; }
#if !defined (HARDWARE_ASICS)
					psResp = gecko_cmd_flash_ps_load(FLASH_PS_KEY_OFFSET);
					wear_id = psResp->value.data[3];
#if defined (HARDWARE_EMG)
					strncpy(device_name, "AISILK-01-01W", 13);
#elif defined (HARDWARE_ECG)
					strncpy(device_name, "AISILK-02-01W", 13);
#elif defined (HARDWARE_ASICS)
					strncpy(device_name, "AISILK-03-01W", 13);
#endif
					sprintf(temp, "%02d", wear_id);
					strcat(device_name, temp);
#endif

#if defined (HARDWARE_ASICS)
					strncpy(device_name, ems_flash_data.udid, strlen(ems_flash_data.udid));
#endif
					gecko_cmd_gatt_server_write_attribute_value(
							gattdb_device_name,
							0,
							strlen(device_name),
							(uint8_t *)device_name);

#if defined (HARDWARE_ASICS)
				//EMS
				//gecko_cmd_sm_configure(0x0F, sm_io_capability_displayonly); /* Numeric comparison */ //pincode認証しない
				/* enable bondable to accommodate certain mobile OS */
				gecko_cmd_sm_set_bondable_mode(1);//Bondings allowed
				//gecko_cmd_sm_set_passkey(123456);
				//gecko_cmd_sm_set_passkey(ems_flash_data.pincode);//pincode認証しない
				//Max bondig
				gecko_cmd_sm_store_bonding_configuration(5, 2);
#endif

				/* Set advertising parameters. 100ms advertisement interval. All channels used.
				 * The first two parameters are minimum and maximum advertising interval, both in
				 * units of (milliseconds * 1.6). The third parameter '7' sets advertising on all channels. */
				gecko_cmd_le_gap_set_adv_parameters(160, 160, 7);

				/* Start general advertising and enable connections. */
				gecko_cmd_le_gap_set_mode(le_gap_general_discoverable, le_gap_undirected_connectable);
				//gecko_cmd_le_gap_set_mode(le_gap_non_discoverable, le_gap_undirected_connectable);

#if defined (HARDWARE_ASICS)
			    /* Start timer */
			    gecko_cmd_hardware_set_soft_timer(TIMER_PERIOD, TIMER_HANDLE, REPEATED_TIMER);

				/* bondingデータ */
				gecko_cmd_sm_list_all_bondings();
#endif
				Connection_Id = 0;
				Connection_Flag = false;
				break;

#if defined (HARDWARE_ASICS)
			case gecko_evt_sm_list_bonding_entry_id:
				bondCnt++;
				break;
#endif
			case gecko_evt_le_connection_opened_id:
#if defined (HARDWARE_ASICS)
				if(evt->data.evt_le_connection_opened.bonding == 0xFF) //ペアリングされていない場合
				{
					//状態取得
					ems_stat = get_ems_stat();
					if(ems_stat == 4) //ペアリングモード
					{
						bondCntSum = bondCnt + bondCntPlus;
						if(bondCntSum > 4)
						{
							Connection_Id = 0;
							Connection_Flag = false;
							gecko_cmd_endpoint_close(evt->data.evt_le_connection_opened.connection);
						}
						else
						{
							Connection_Id = evt->data.evt_le_connection_opened.connection;
							Connection_Flag = true;
					        /* The HTM service typically indicates and indications cannot be given an encrypted property so
					         * force encryption immediately after connecting */
							gecko_cmd_sm_increase_security(Connection_Id);
						}
					}
					else
					{
						Connection_Id = 0;
						Connection_Flag = false;
						gecko_cmd_endpoint_close(evt->data.evt_le_connection_opened.connection);
					}
				}
				else
				{
					Connection_Id = evt->data.evt_le_connection_opened.connection;
					Connection_Flag = true;

					//EMS
			        /* The HTM service typically indicates and indications cannot be given an encrypted property so
			         * force encryption immediately after connecting */
					gecko_cmd_sm_increase_security(Connection_Id);
				}
#else
				Connection_Id = evt->data.evt_le_connection_opened.connection;
				Connection_Flag = true;
#endif

				break;

#if defined (HARDWARE_ASICS)
			//EMS ペアリングOKの場合
			case gecko_evt_sm_bonded_id:
				//ペアリングタイマーリセット
				pairing_timer_reset();
				//スタンバイモードに変更
				ems_statuschange_nomal();
				//ブザー設定
				ems_buzzer_set(1, 1);//ステータス:1, 回数:1(ピピッ)
				bondCntPlus++;
				break;

			//EMS ペアリングエラーの場合
		    case gecko_evt_sm_bonding_failed_id:
				Connection_Id = 0;
				Connection_Flag = false;
				gecko_cmd_endpoint_close(evt->data.evt_le_connection_opened.connection);
				//gecko_cmd_sm_delete_bondings();
				break;
#endif

			case gecko_evt_le_connection_closed_id:

				Connection_Id = 0;
				Connection_Flag = false;

				/* Check if need to boot to dfu mode */
				if (boot_to_dfu) {
					/* Enter to DFU OTA mode */
					gecko_cmd_system_reset(2);
				} else {
#if !defined (HARDWARE_ASICS)
					/* Restart advertising after client has disconnected */
					//gecko_cmd_le_gap_set_mode(le_gap_general_discoverable, le_gap_undirected_connectable);
					gecko_cmd_system_reset(0);
#else
					/* Restart advertising after client has disconnected */
					gecko_cmd_le_gap_set_mode(le_gap_general_discoverable, le_gap_undirected_connectable);
#endif
				}
				break;


			case gecko_evt_gatt_server_user_read_request_id:
				if (evt->data.evt_gatt_server_user_read_request.characteristic == gattdb_battery_level) {
					//battery_read(connection);
				}
				else if (evt->data.evt_gatt_server_user_read_request.characteristic == gattdb_ems_measurement) {
				}
				break;

			case gecko_evt_gatt_server_characteristic_status_id:
				/* Check that the characteristic in question is temperature - its ID is defined
				 * in gatt.xml as "temp_measurement". Also check that status_flags = 1, meaning that
				 * the characteristic client configuration was changed (notifications or indications
				 * enabled or disabled). */
				if ((evt->data.evt_gatt_server_characteristic_status.characteristic == gattdb_ems_measurement)
				 && (evt->data.evt_gatt_server_characteristic_status.status_flags == 0x01)) {
					//if (evt->data.evt_gatt_server_characteristic_status.characteristic == gattdb_heart_rate_measurement) {
					if (evt->data.evt_gatt_server_characteristic_status.client_config_flags == 0x01) {
						/* Indications have been turned ON - start the repeating timer. The 1st parameter '32768'
						 * tells the timer to run for 1 second (32.768 kHz oscillator), the 2nd parameter is
						 * the timer handle and the 3rd parameter '0' tells the timer to repeat continuously until
						 * stopped manually.*/
					}
					else if (evt->data.evt_gatt_server_characteristic_status.client_config_flags == 0x00) {
						/* Indications have been turned OFF - stop the timer. */
					}
				}
				break;

			/* Events related to OTA upgrading
			 * ----------------------------------------------------------------------------- */

			/* Check if the user-type OTA Control Characteristic was written.
			 * If ota_control was written, boot the device into Device Firmware Upgrade (DFU) mode. */
			case gecko_evt_gatt_server_user_write_request_id:

				if (evt->data.evt_gatt_server_user_write_request.characteristic == gattdb_ota_control) {
					/* Set flag to enter to OTA mode */
					boot_to_dfu = 1;
					/* Send response to Write Request */
					gecko_cmd_gatt_server_send_user_write_response(
						evt->data.evt_gatt_server_user_write_request.connection,
						gattdb_ota_control,
						bg_err_success);

					/* Close connection to enter to DFU OTA mode */
					gecko_cmd_endpoint_close(evt->data.evt_gatt_server_user_write_request.connection);
				}
				else if (evt->data.evt_gatt_server_user_write_request.characteristic == gattdb_ems_control_point) {

					data_analysis(&evt->data.evt_gatt_server_user_write_request.value);

				}
				break;

#if defined (HARDWARE_ASICS)
			/* Events related to one of enabled software timers --------------------*/
			case gecko_evt_hardware_soft_timer_id:
		    	  if(evt->data.evt_hardware_soft_timer.handle == TIMER_HANDLE)
		    	  {
		    		    // 刺激用
						mode_change();//モード変更
		    	  }
		    	  else if(evt->data.evt_hardware_soft_timer.handle == TIMER_HANDLE_DELAY)
		    	  {
		    		  ems_det = get_e_det();
		    		  if(ems_det != 1)
		    		  {
							//遅延スタート
							ems_statuschange_nomal();
							set_mode_status(mode);
							ems_sco_mode_init();
							sco_start();
		    		  }
		    	  }
		    	  else if(evt->data.evt_hardware_soft_timer.handle == TIMER_HANDLE_PAUSE)
		    	  {
						//Pause2分タイマー満了：休止モードへ
		    		  	ems_buzzer_set(3, 1);//ステータス:3, 回数:1(ピー)
		    		  	//休止に状態遷移
		    		  	ems_stanby();
		    		  	ems_sco_mode_init();
		    	  }
		    	  else if(evt->data.evt_hardware_soft_timer.handle == TIMER_HANDLE_PAIRING)
		    	  {
		    		  	//状態取得
		    		  	ems_stat = get_ems_stat();
		    		  	if(ems_stat == 4) //ペアリングモード
		    		  	{
			    		  	//スタンバイに状態遷移
		    		  		ems_statuschange_nomal();
		    		  	}
		    	  }
		    	  else if(evt->data.evt_hardware_soft_timer.handle == TIMER_HANDLE_STANBY)
		    	  {
						//スタンバイ2分タイマー満了：休止モードへ
		    		  	ems_buzzer_set(3, 1);//ステータス:3, 回数:1(ピー)
		    		  	//休止に状態遷移
		    		  	ems_stanby();
		    		  	ems_sco_mode_init();
		    	  }
		    	  else if(evt->data.evt_hardware_soft_timer.handle == TIMER_HANDLE_IDAC)
		    	  {
		    		    //一時停止から復帰した場合のidac設定
		    			uint16_t idac_timer_step = ems_pause_stepcount();
		    			uint16_t idac_timer_middle = idac_timer_step / 2;
		    			if(idac_timer_middle < 1)
		    			{
		    				idac_timer_middle = 1;
		    			}
						switch(idac_timer_count)
						{
							case 0:
								//5秒後（停止前レベルの半分設定）
								idacSetStepNum(idac_timer_middle);
				    			idac_timer_count++;
								break;
							case 1:
								//10秒後（停止前レベル設定）
								idacSetStepNum(idac_timer_step);
								//idacタイマー停止
								idac_timer_reset();
				    			idac_timer_count = 0;
								break;
							default:
								break;
						}
		    	  }
		    	  else if(evt->data.evt_hardware_soft_timer.handle == TIMER_HANDLE_BATTERY)
		    	  {

		    		  	//状態取得
		    		  	ems_stat = get_ems_stat();
		    		  	if(ems_stat == 1 || ems_stat == 2 || ems_stat == 3) //0:休止 1:スタンバイ 2:刺激中 3:一時停止
		    		  	{
			    			//バッテリーチェック
			    			battery_voltage_check();
		    		  	}
		    	  }
		    	  else if(evt->data.evt_hardware_soft_timer.handle == TIMER_HANDLE_TEST_DELAY)
		    	  {
						//テスト遅延実行
						led_off();//通常のLEDをOFF(ONに戻すことはできない)
						if(test_led_status == 0)
						{
							//LED点灯
							ledStrong.no[0] = test_led_color;
							disp_led_strong();
						}
						else if(test_led_status == 1)
						{
							//消灯
							disp_led_simple(3, 0);
						}
						else
						{
							//電源OFF
							//set_kill();//直接電源OFF
							ems_buzzer_set(5, 2);//ステータス:5, 回数:2(ピーピー)ブザーを鳴らした後電源OFF
						}
		    	  }
				break;
#endif

			default:
				break;
		}
#if !defined (HARDWARE_ASICS)
		gpio_test_main();
#endif
	}
	return 0;
}


void data_analysis(uint8array *writeValue)
{
	uint8_t i;
	bool send_enable = false;
#if !defined (HARDWARE_ASICS)
	uint32_t time_h;
	uint32_t time_l;
	uint8_t ad_ch;
#endif
	uint32_t ad_value;
	float voltage;
	uint32_t charging_state;

#if defined (HARDWARE_ASICS)
	uint16_t voltage_16;
	uint16_t mode_time;
	bool error_flash_write_flag;
	uint32_t tmp_pincode;
	uint8_t start_time_m;
	uint8_t operation_time_m;
	uint8_t ems_stat;
	uint8_t ems_mode;
	uint8_t ems_det;
	uint16_t tmp_dynamic_s_time;
	uint16_t tmp_dynamic_w_time;
	uint32_t tmp_test_led_start_time;
	uint16_t tmp_pitch_on_time;
	uint16_t tmp_pitch_off_time;

#endif

	/* Send response to Write Request */
	gecko_cmd_gatt_server_send_user_write_response(
		Connection_Id,
		gattdb_ems_control_point,
		bg_err_success);

	if (writeValue->data[0] == ATT_DEFAULT_PAYLOAD_LEN)
	{
		for (i=1; i<ATT_DEFAULT_PAYLOAD_LEN; i++){ Send_Data[i] = 0x00; }
		Send_Data[0] = ATT_DEFAULT_PAYLOAD_LEN;
		switch(writeValue->data[1])
		{
			/* Get_Status_Req */
			case GET_STATUS_REQ:
				send_enable = true;
				Send_Data[1] = GET_STATUS_RES;
				Send_Data[2] = Measure_Flag;
				//Initial_Flag = true;
				break;

			/* Get_Version_Req */
			case GET_VERSION_REQ:
				send_enable = true;
				Send_Data[1] = GET_VERSION_RES;
				Send_Data[2] = VERSION_MAJOR;
				Send_Data[3] = VERSION_MINOR;
				Send_Data[4] = VERSION_REVISION;
				break;
#if !defined (HARDWARE_ASICS)
			/* Set_Time_Req */
			case SET_TIME_REQ:
				send_enable = true;
				time_h = (writeValue->data[2] << 8)
					   | (writeValue->data[3] << 0);
				time_l = (writeValue->data[4] << 24)
					   | (writeValue->data[5] << 16)
					   | (writeValue->data[6] <<	8)
					   | (writeValue->data[7] <<	0);
				Sync_Time = (uint64_t)(((uint64_t)time_h << 32) | time_l);
				Send_Data[1] = SET_TIME_RES;
				break;


			/* REC_Start_Req */
			case REC_START_REQ:
				send_enable = true;
				lfilter_init();
				Send_Data[1] = REC_START_RES;
				Measure_Flag = true;
				Analysis_Data_Write_Cnt = 0;
				Analysis_Data_OverFlow = false;
				Analysis_Flag = false;
				Analysis_Data_Send_Comp_Flag = false;
				Analysis_Data_Write_Address = 0x00000000;
				Analysis_Data_Read_Address = 0x00000000;
				break;

			/* REC_Stop_Req */
			case REC_STOP_REQ:
				send_enable = true;
				Send_Data[1] = REC_STOP_RES;
				Measure_Flag = false;
				if (writeValue->data[2] == 0x01)
				{
					//Read_Analysis_Data_init_From_SRAM();
				}
				break;

			/* Calib_Start_Req */
			case CALIB_START_REQ:
				send_enable = true;
				Send_Data[1] = CALIB_START_RES;
				Calib_Flag = true;
				break;

			/* Calib_Stop_Req */
			case CALIB_STOP_REQ:
				send_enable = true;
				Send_Data[1] = CALIB_STOP_RES;
				Calib_Flag = false;
				break;


			case SET_CONFIG_REQ:
				send_enable = true;
				ad_ch = writeValue->data[2] - 1;
				if ((0 <= ad_ch) && (ad_ch <= 3)) {
					//confData[ad_ch].Kind_ECG_EMG = writeValue->data[3];
					if ((CONF_NOTCH_ON <= writeValue->data[4]) && (writeValue->data[4] <= CONF_NOTCH_OFF)) {
						confData[ad_ch].Notch_ON_OFF = writeValue->data[4];
					}
					if ((CONF_NOTCH_FC_50 <= writeValue->data[5]) && (writeValue->data[5] <= CONF_NOTCH_FC_60)) {
						confData[ad_ch].Notch_Fc = writeValue->data[5];
					}
					if ((CONF_EMG_TINT_100 <= writeValue->data[6]) && (writeValue->data[6] <= CONF_EMG_TINT_300)) {
						confData[ad_ch].EMG_Tint = writeValue->data[6];
					}
					if ((CONF_ECG_TAV_20 <= writeValue->data[7]) && (writeValue->data[7] <= CONF_ECG_TAV_40)) {
						confData[ad_ch].ECG_Tav = writeValue->data[7];
					}
					confData[ad_ch].Digital_Gain = ((writeValue->data[8] << 8) | (writeValue->data[9]));
					//if ((CONF_SEND_DATA_20 <=writeValue->data[10]) && (writeValue->data[10] <= CONF_SEND_DATA_40)) {
					//	confData[ad_ch].SendData_Tt = writeValue->data[10];
					//}
					//confData[ad_ch].Max_Power = ((writeValue->data[17] << 8) | (writeValue->data[18]));
					confData[ad_ch].Wear_ID = writeValue->data[20];
					if (ad_ch == 0) {
						EMG_Tint = (confData[ad_ch].EMG_Tint * 100);
						ECG_Tav = (confData[ad_ch].ECG_Tav * 20);
						Wear_ID = confData[ad_ch].Wear_ID;
						//SendData_Tt = (confData[ad_ch].SendData_Tt * HR_SEND_TIMEOUT);
					}
					Flash_Data[0] = (uint8_t)((confData[ad_ch].Notch_ON_OFF << 6) | (confData[ad_ch].Notch_Fc << 4) | (confData[ad_ch].EMG_Tint << 2) | (confData[ad_ch].ECG_Tav));
					Flash_Data[1] = (uint8_t)(confData[ad_ch].Digital_Gain >> 8);
					Flash_Data[2] = (uint8_t)(confData[ad_ch].Digital_Gain >> 0);
					//Flash_Data[3] = (uint8_t)(confData[ad_ch].Max_Power >> 8);
					//Flash_Data[4] = (uint8_t)(confData[ad_ch].Max_Power >> 0);
					Flash_Data[3] = (uint8_t)Wear_ID;
					gecko_cmd_flash_ps_save((uint16)(FLASH_PS_KEY_OFFSET + ad_ch), (uint8)sizeof(Flash_Data), (const uint8*)&Flash_Data);
				}
				Send_Data[1] = SET_CONFIG_RES;
				break;
#endif
				case GET_CONFIG_REQ:
					send_enable = true;
/* EMSでは使用しないコマンドだがアプリがエラーになるためレスポンスのみ返す　-> アプリ変更後　!defined (HARDWARE_ASICS)に変更すること
					ad_ch = writeValue->data[2] - 1;
					Send_Data[2] = confData[ad_ch].No;
					Send_Data[3] = confData[ad_ch].Kind_ECG_EMG;
					Send_Data[4] = confData[ad_ch].Notch_ON_OFF;
					Send_Data[5] = confData[ad_ch].Notch_Fc;
					Send_Data[6] = confData[ad_ch].EMG_Tint;
					Send_Data[7] = confData[ad_ch].ECG_Tav;
					Send_Data[8] = (confData[ad_ch].Digital_Gain >> 8);
					Send_Data[9] = (confData[ad_ch].Digital_Gain >> 0);
					Send_Data[10] = confData[ad_ch].SendData_Tt;
					Send_Data[11] = (confData[ad_ch].AFE_Gain >> 8);
					Send_Data[12] = (confData[ad_ch].AFE_Gain >> 0);
					Send_Data[13] = (confData[ad_ch].LPF_F >> 8);
					Send_Data[14] = (confData[ad_ch].LPF_F >> 0);
					Send_Data[15] = (confData[ad_ch].HPF_F >> 8);
					Send_Data[16] = (confData[ad_ch].HPF_F >> 0);
					Send_Data[17] = (confData[ad_ch].Max_Power >> 8);
					Send_Data[18] = (confData[ad_ch].Max_Power >> 0);
					Send_Data[19] = confData[ad_ch].Output_Sampling;
					Send_Data[20] = confData[ad_ch].Wear_ID;
*/
					Send_Data[1] = GET_CONFIG_RES;
					break;

#if !defined (HARDWARE_ASICS)
                case GET_BATTERY_VOLTAGE_REQ:
                        voltage = 0;
                        for (i=0; i<4; i++) {
                                ad_value = adc_driver_read(BATTERY_VOLTAGE_CH);
                                voltage += ((float)ad_value / (float)4096 * (float)3.3);
                        }
                        voltage = (voltage / 4);
                        voltage = ((voltage * 2) * 10);
                        send_enable = true;
                        Send_Data[1] = GET_BATTERY_VOLTAGE_RES;
                        Send_Data[2] = (uint8_t)voltage;
                        break;
#else
				case GET_TRANSMITTER_STATUS_REQ://EMS 項目名変更して使用
					voltage = 0;
					for (i=0; i<4; i++) {
						ad_value = adc_driver_read(BATTERY_VOLTAGE_CH);
						voltage += ((float)ad_value / (float)4096 * (float)3);
					}
					voltage = (voltage / 4);
					voltage = ((voltage * 2) * 100);
//					voltage -= 40;
					voltage_16 = (uint16_t)voltage;
					send_enable = true;
					Send_Data[1] = GET_TRANSMITTER_STATUS_RES;
					Send_Data[2] = (uint8_t)(voltage_16 >> 8);
					Send_Data[3] = (uint8_t)(voltage_16 >> 0);
					//EMS追加
					Send_Data[4] = (uint8_t)get_mode();
					Send_Data[5] = (uint8_t)get_idac_stepcount();
					mode_time = get_mode_time();
					Send_Data[6] = (uint8_t)(mode_time >> 8);
					Send_Data[7] = (uint8_t)(mode_time >> 0);
					Send_Data[8] = (uint8_t)get_ems_stat();
					Send_Data[9] = (uint8_t)get_error_code();//エラーコード
					Send_Data[10] = (uint8_t)get_e_det();
					charging_state = gpio_driver_read(CHARGING_NO);
					Send_Data[11] = (uint8_t)charging_state;
					get_dynamic_time( &Send_Data[12]
									, &Send_Data[13]
									, &Send_Data[14]
									, &Send_Data[15]
									, &Send_Data[16]
									);
					get_pitch_time(   &Send_Data[17]
									, &Send_Data[18]
									, &Send_Data[19]
									, &Send_Data[20]
									, &Send_Data[21]
									);
					break;
#endif
				case GET_CHARGING_INFO_REQ:
					charging_state = gpio_driver_read(CHARGING_NO);
					send_enable = true;
					Send_Data[1] = GET_CHARGING_INFO_RES;
					Send_Data[2] = (uint8_t)charging_state;
					break;

#if !defined (HARDWARE_ASICS)
				case SET_LED_STRONG_REQ:
					for(i=0; i<12; i++) {
						ledStrong.no[i] = writeValue->data[(i+2)] - 1;
					}
					CLed_Req_Flag = true;
					disp_led_strong();
					send_enable = true;
					Send_Data[1] = SET_LED_STRONG_RES;
					break;
#endif

#if defined (HARDWARE_ASICS)
				//EMS追加
				case EMS_START_REQ:
					send_enable = true;
					Send_Data[1] = EMS_START_RES;
					mode=(uint8_t)writeValue->data[2];//モード
					start_time_m=(uint8_t)writeValue->data[3];//開始時間
					operation_time_m=(uint8_t)writeValue->data[4];//ダイナミックモード稼働時間
					if(mode == DYNAMIC)
					{
						//ダイナミックモード
						if(operation_time_m > 0)
						{
							dynamic_operation_time_set(operation_time_m);
						}
						else
						{
							Send_Data[2] = -1;//異常
						}
					}
					else if(mode == PITCH)
					{
						//ピッチモードモード
						if(operation_time_m > 0)
						{
							pitch_operation_time_set(operation_time_m);
						}
						else
						{
							Send_Data[2] = -1;//異常
						}
					}
					else if (mode == STATIC)
					{

					}
					else
					{
						Send_Data[2] = -1;//異常
					}

					if(Send_Data[2] == 0x00)
					{
						delay_timer_reset();//遅延タイマーリセット
						if(start_time_m > 0)
						{
							ems_buzzer_set(0, 1);//ブザー設定 ステータス:1, 回数:1(ピッ)
						    // Start timer //
						    gecko_cmd_hardware_set_soft_timer(TIMER_PERIOD*60*start_time_m, TIMER_HANDLE_DELAY, NO_REPEATED_TIMER);
						}
						else
						{
							//状態取得
				    		ems_det = get_e_det();//1:剥がれあり
							ems_stat = get_ems_stat();//4:ペアリングモード
				    		if(ems_det != 1 && ems_stat != 4)
				    		{
				    			//通常処理遷移
								ems_statuschange_nomal();
								set_mode_status(mode);
								ems_sco_mode_init();

								//スタンバイ2分タイマー停止
								stanby_timer_reset();
								//一時停止2分タイマー解除
								pause_timer_reset();

								sco_start();
				    		}
				    		else
				    		{
								Send_Data[2] = -1;//異常
				    		}
						}
						Send_Data[2] = 1;//正常
					}
					break;

				case EMS_STOP_REQ:
					send_enable = true;
					Send_Data[1] = EMS_STOP_RES;
					sco_stop();
					Send_Data[2] = 1;//正常
					break;

				case SET_STIMULATION_POWER_REQ:
					ems_stat = get_ems_stat();//2:刺激中
					send_enable = true;
					Send_Data[1] = SET_STIMULATION_POWER_RES;
					if(ems_stat == 2)
					{
						if(writeValue->data[2] == 1)
						{
							//プラス1
							idacSetStep(1);
							Send_Data[2] = 1;//正常
						}
						else if(writeValue->data[2] == 0)
						{
							//マイナス1
							idacSetStep(-1);
							Send_Data[2] = 1;//正常
						}
						else
						{
							Send_Data[2] = -1;//異常
						}
					}
					else
					{
						Send_Data[2] = -1;//異常
					}
					break;

				case EMS_SHUTDOWN_REQ:
					ems_buzzer_set(5, 2);//ステータス:5, 回数:2(ピーピー) ブザーが終わったらkill
					break;

				case EMS_PAUSE_REQ:
					send_enable = true;
					Send_Data[1] = EMS_PAUSE_RES;
					ems_pause();
					break;

				case SET_UDID_REQ:
					send_enable = true;
					Send_Data[1] = SET_UDID_RES;

					//UDID　writeValue->data[2]からwriteValue->data[16]まで
					error_flash_write_flag=false;
					do{
						if(strlen((const char*)&writeValue->data[2])==0){
							error_flash_write_flag=true;
							break;
						}
						for (i=0; i<15; i++)
						{
							if(!(writeValue->data[i+2] >= 0x20 && writeValue->data[i+2] <= 0x7e))
							{
								error_flash_write_flag = true;
								break;
							}
						}

					}while(0);

					if(error_flash_write_flag != true)
					{
						for (i=0; i<15; i++)
						{
							ems_flash_data.udid[i] = writeValue->data[i+2];
						}
						ems_flash_data.udid[15]=0x00;
						gecko_cmd_flash_ps_save((uint16)(FLASH_PS_KEY), (uint8)sizeof(ems_flash_data), (const uint8*)&ems_flash_data);
						Send_Data[2] = 1;//正常
					}
					else
					{
						Send_Data[2] = -1;//異常
					}
					break;

				case GET_PINCODE_REQ:
					send_enable = true;
					Send_Data[1] = GET_PINCODE_RES;
					Send_Data[2] = (uint8_t)(ems_flash_data.pincode >> 16);
					Send_Data[3] = (uint8_t)(ems_flash_data.pincode >> 8);
					Send_Data[4] = (uint8_t)(ems_flash_data.pincode >> 0);
					break;

				case SET_PINCODE_REQ:
					send_enable = true;
					Send_Data[1] = SET_PINCODE_RES;
					//PID
					tmp_pincode = ((writeValue->data[2]  << 16) | (writeValue->data[3] << 8) | writeValue->data[4]);
					if(tmp_pincode < 0 || tmp_pincode > 999999)
					{
						Send_Data[2] = -1;//異常
					}
					else
					{
						ems_flash_data.pincode = tmp_pincode;
						gecko_cmd_flash_ps_save((uint16)(FLASH_PS_KEY), (uint8)sizeof(ems_flash_data), (const uint8*)&ems_flash_data);
						Send_Data[2] = 1;//正常
					}
					break;

				case GET_UDID_REQ:
					send_enable = true;
					Send_Data[1] = GET_UDID_RES;
					memcpy(&Send_Data[2], ems_flash_data.udid, 15);
					break;

				case SET_DYNAMIC_TIME_CHANGE_REQ:
					send_enable = true;
					Send_Data[1] = SET_DYNAMIC_TIME_CHANGE_RES;
	    		  	//状態取得
	    		  	ems_mode = get_mode();		//1:ダイナミックモード
	    		  	ems_stat = get_ems_stat();	//2:刺激中
					tmp_dynamic_s_time = ((writeValue->data[2]  << 8) | (writeValue->data[3]));
					tmp_dynamic_w_time = ((writeValue->data[4]  << 8) | (writeValue->data[5]));
	    		  	if ((tmp_dynamic_s_time == 0) ||
						(tmp_dynamic_w_time == 0) )
	    		  	{
		    		  	Send_Data[2] = 2;//パラメータエラー
						break;
	    		  	}
	    		  	else if (ems_mode != 1 || ems_stat != 2)
	    		  	{
	    		  		Send_Data[2] = 3;//状態エラー
						break;
	    		  	}
	    		  	else
	    		  	{
	    		  		//ダイナミック強弱時間変更
	    		  		set_dynamic_time(tmp_dynamic_s_time, tmp_dynamic_w_time);
	    		  		Send_Data[2] = 1;//正常
	    		  	}
					break;

				case SET_DYNAMIC_TIME_SAVE_REQ:
					send_enable = true;
					Send_Data[1] = SET_DYNAMIC_TIME_SAVE_RES;
					tmp_dynamic_s_time = ((writeValue->data[2]  << 8) | (writeValue->data[3]));
					tmp_dynamic_w_time = ((writeValue->data[4]  << 8) | (writeValue->data[5]));
					if ((tmp_dynamic_s_time == 0) ||
	    		  		(tmp_dynamic_w_time == 0) ||
						(writeValue->data[6] == 0) )
	    		  	{
		    		  	Send_Data[2] = 2;//パラメータエラー
						break;
	    		  	}
	    		  	else
	    		  	{
	    		  		//ダイナミック強弱時間、トレーニング時間保存
						ems_flash_dynamic_time_data.s_time = tmp_dynamic_s_time;
						ems_flash_dynamic_time_data.w_time = tmp_dynamic_w_time;
						ems_flash_dynamic_time_data.tr_time = writeValue->data[6];
						gecko_cmd_flash_ps_save((uint16)(FLASH_PS_KEY + 1), (uint8)sizeof(ems_flash_dynamic_time_data), (const uint8*)&ems_flash_dynamic_time_data);
	    		  		Send_Data[2] = 1;//正常
	    		  	}
					break;

				case SET_TEST_REQ:
					send_enable = true;
					Send_Data[1] = SET_TEST_RES;
					//これは工場出荷時のLEDチェックする場合のみ使用する
					test_led_status = writeValue->data[2];//0:点灯 1:消灯 2:電源OFF
					test_led_color = writeValue->data[3] - 1;//LEDの色(1-16)
					test_led_start_time = (writeValue->data[4] << 8) | writeValue->data[5];//遅延時間（msec）

					if (
						(test_led_status != 0 && test_led_status != 1 && test_led_status != 2) ||
						(test_led_color < 0 || test_led_color > 15) ||
						(test_led_start_time < 0 || test_led_start_time > 65535)
					   )
					{
						Send_Data[2] = 2;//パラメータエラー
					}
					if(Send_Data[2] == 0x00)
					{
						if (test_led_start_time == 0)
						{
							//遅延なし
							led_off();//通常のLEDをOFF(ONに戻すことはできない)
							if(test_led_status == 0)
							{
								//LED点灯
								ledStrong.no[0] = test_led_color;
								disp_led_strong();
							}
							else if(test_led_status == 1)
							{
								//消灯
								disp_led_simple(3, 0);
							}
							else
							{
								//電源OFF
								//set_kill();//直接電源 OFF
								ems_buzzer_set(5, 2);//ステータス:5, 回数:2(ピーピー)ブザーを鳴らした後電源 OFF
							}

						}
						else
						{
							//遅延タイマ設定
							tmp_test_led_start_time = (uint32_t)TIMER_PERIOD*test_led_start_time/1000;
						    gecko_cmd_hardware_set_soft_timer(tmp_test_led_start_time, TIMER_HANDLE_TEST_DELAY, NO_REPEATED_TIMER);
						}
	    		  		Send_Data[2] = 1;//正常
					}
					break;

				case SET_PITCH_TIME_CHANGE_REQ:
					send_enable = true;
					Send_Data[1] = SET_PITCH_TIME_CHANGE_RES;
	    		  	//状態取得
	    		  	ems_mode = get_mode();		//2:ピッチモード
	    		  	ems_stat = get_ems_stat();	//2:刺激中
					tmp_pitch_on_time = ((writeValue->data[2]  << 8) | (writeValue->data[3]));
					tmp_pitch_off_time = ((writeValue->data[4]  << 8) | (writeValue->data[5]));
	    		  	if ((tmp_pitch_on_time == 0) ||
						(tmp_pitch_off_time == 0) )
	    		  	{
		    		  	Send_Data[2] = 2;//パラメータエラー
						break;
	    		  	}
	    		  	else if (ems_mode != 2 || ems_stat != 2)
	    		  	{
	    		  		Send_Data[2] = 3;//状態エラー
						break;
	    		  	}
	    		  	else
	    		  	{
	    		  		//ピッチモードON/OFF時間変更
	    		  		set_pitch_time(tmp_pitch_on_time, tmp_pitch_off_time);
	    		  		Send_Data[2] = 1;//正常
	    		  	}
					break;

				case SET_PITCH_TIME_SAVE_REQ:
					send_enable = true;
					Send_Data[1] = SET_PITCH_TIME_SAVE_RES;
					tmp_pitch_on_time = ((writeValue->data[2]  << 8) | (writeValue->data[3]));
					tmp_pitch_off_time = ((writeValue->data[4]  << 8) | (writeValue->data[5]));
					if ((tmp_pitch_on_time == 0) ||
	    		  		(tmp_pitch_off_time == 0) ||
						(writeValue->data[6] == 0) )
	    		  	{
		    		  	Send_Data[2] = 2;//パラメータエラー
						break;
	    		  	}
	    		  	else
	    		  	{
	    		  		//ピッチモードidacON/OFF時間、トレーニング時間保存
						ems_flash_dynamic_time_data.pitch_idac_on_time = tmp_pitch_on_time;
						ems_flash_dynamic_time_data.pitch_idac_off_time = tmp_pitch_off_time;
						ems_flash_dynamic_time_data.pitch_tr_time = writeValue->data[6];
						gecko_cmd_flash_ps_save((uint16)(FLASH_PS_KEY + 1), (uint8)sizeof(ems_flash_dynamic_time_data), (const uint8*)&ems_flash_dynamic_time_data);
	    		  		Send_Data[2] = 1;//正常
	    		  	}
					break;


#endif

				default:
					break;

		}
	}

	if (send_enable == true) {
		gecko_cmd_gatt_server_send_characteristic_notification(
			Connection_Id, gattdb_ems_measurement, ATT_DEFAULT_PAYLOAD_LEN, Send_Data);
	}

}

#if !defined (HARDWARE_ASICS)
void Conf_Data_Init(void)
{

	int i;
	uint32_t data;
	uint8_t data0;
	uint8_t data1;
	uint8_t data2;
	uint8_t data3;
	//uint8_t data4;
	for (i=0; i<4; i++)
	{
		confData[i].No = i + 1;
#ifdef HARDWARE_EMG
		confData[i].Kind_ECG_EMG = CONF_KIND_EMG;
#endif
#ifdef HARDWARE_ECG
		confData[i].Kind_ECG_EMG = CONF_KIND_ECG;
#endif
		psResp = gecko_cmd_flash_ps_load(FLASH_PS_KEY_OFFSET + i);
		data0 = psResp->value.data[0];
		data1 = psResp->value.data[1];
		data2 = psResp->value.data[2];
		data3 = psResp->value.data[3];
		//data4 = psResp->value.data[4];

		data = ((data0 >> 6) & 0x03);
		if ((CONF_NOTCH_ON <= data) && (data <= CONF_NOTCH_OFF)) {
				confData[i].Notch_ON_OFF = data;
		}
		else {
				confData[i].Notch_ON_OFF = CONF_NOTCH_ON;
		}

		data = ((data0 >> 4) & 0x03);
		if ((CONF_NOTCH_FC_50 <= data) && (data <= CONF_NOTCH_FC_60)) {
				confData[i].Notch_Fc = data;
		}
		else {
			confData[i].Notch_Fc = CONF_NOTCH_FC_50;
		}

		data = ((data0 >> 2) & 0x03);
		if ((CONF_EMG_TINT_100 <= data) && (data <= CONF_EMG_TINT_300)) {
			confData[i].EMG_Tint = data;
		}
		else {
			confData[i].EMG_Tint = CONF_EMG_TINT_200;
		}

		data = ((data0 >> 0) & 0x03);
		if ((CONF_ECG_TAV_20 <= data) && (data <= CONF_ECG_TAV_40)) {
			confData[i].ECG_Tav = data;
		}
		else {
			confData[i].ECG_Tav = CONF_ECG_TAV_20;
		}

		data = (((data1 << 8)&0xFF00) | data2);
		if ((0 < data) && (data <= 32767)) {
			confData[i].Digital_Gain = data;
		}
		else {
			confData[i].Digital_Gain = 1;
		}

		confData[i].SendData_Tt = CONF_SEND_DATA_20;
		confData[i].AFE_Gain = CONF_AFE_GAIN;
		confData[i].LPF_F = CONF_LPF_HZ;
		confData[i].HPF_F = CONF_HPF_HZ;
		confData[i].Max_Power = 32767;
		confData[i].Output_Sampling = OUTPUT_SAMPLING;
		confData[i].Wear_ID = data3;
	}
}
#endif

#if defined (HARDWARE_ASICS)
void EMS_PS_Data_Init(void)
{
	bool error_uuid_flag;
	uint8_t i;

	//PSデータ取得
	psResp = gecko_cmd_flash_ps_load(FLASH_PS_KEY);

	memcpy(&ems_flash_data,psResp->value.data,sizeof(ems_flash_data));

	//PID
	if(ems_flash_data.pincode < 0 || ems_flash_data.pincode > 999999)
	{
		ems_flash_data.pincode = 0;
	}

	//UDID
	error_uuid_flag=false;
	do{
		if(strlen(ems_flash_data.udid)==0)
		{
			error_uuid_flag=true;
			break;
		}
		for (i=0; i<15; i++)
		{
			if(ems_flash_data.udid[i] == 0x00)
			{
				break;
			}
			if(!(ems_flash_data.udid[i] >= 0x20 && ems_flash_data.udid[i] <= 0x7e))
			{
				error_uuid_flag = true;
				break;
			}
		}

	}while(0);

	if(error_uuid_flag == true)
	{
		memcpy(ems_flash_data.udid, "AISILK-03-01W00", 15);
	}

	//ダイナミック時間データ取得設定
	psResp = gecko_cmd_flash_ps_load(FLASH_PS_KEY + 1);
	memcpy(&ems_flash_dynamic_time_data,psResp->value.data,sizeof(ems_flash_dynamic_time_data));
	//初期値設定（強弱時間）
	if(ems_flash_dynamic_time_data.s_time == 0 || ems_flash_dynamic_time_data.w_time == 0)
	{
		ems_flash_dynamic_time_data.s_time = 1800;//ダイナミックモード強時間デフォルト設定
		ems_flash_dynamic_time_data.w_time = 1800;//ダイナミックモード弱時間デフォルト設定
	}
	if(ems_flash_dynamic_time_data.tr_time == 0)
	{
		ems_flash_dynamic_time_data.tr_time = 30;//ダイナミックモードトレーニング基準時間設定
	}
	set_dynamic_time(ems_flash_dynamic_time_data.s_time, ems_flash_dynamic_time_data.w_time);
	dynamic_operation_time_set(ems_flash_dynamic_time_data.tr_time);

	//初期値設定（ピッチモード　idac ON/OFF時間）
	if(ems_flash_dynamic_time_data.pitch_idac_on_time == 0 || ems_flash_dynamic_time_data.pitch_idac_off_time == 0)
	{
		ems_flash_dynamic_time_data.pitch_idac_on_time = 80;//ON時間デフォルト設定
		ems_flash_dynamic_time_data.pitch_idac_off_time = 253;//OFF時間デフォルト設定
	}
	if(ems_flash_dynamic_time_data.pitch_tr_time == 0)
	{
		ems_flash_dynamic_time_data.pitch_tr_time = 60;//ピッチモードトレーニング基準時間設定
	}
	set_pitch_time(ems_flash_dynamic_time_data.pitch_idac_on_time, ems_flash_dynamic_time_data.pitch_idac_off_time);
	pitch_operation_time_set(ems_flash_dynamic_time_data.pitch_tr_time);
}

void delay_timer_reset()
{
	/* 遅延タイマー reset*/
	gecko_cmd_hardware_set_soft_timer(0, TIMER_HANDLE_DELAY, NO_REPEATED_TIMER);
}
void pause_timer_reset()
{
	/* 一時停止2分タイマー reset*/
	gecko_cmd_hardware_set_soft_timer(0, TIMER_HANDLE_PAUSE, NO_REPEATED_TIMER);
}
void pairing_timer_reset()
{
	/* ペアリング30秒タイマー reset*/
	gecko_cmd_hardware_set_soft_timer(0, TIMER_HANDLE_PAIRING, NO_REPEATED_TIMER);
}
void stanby_timer_reset()
{
	/* スタンバイ2分タイマー reset*/
	gecko_cmd_hardware_set_soft_timer(0, TIMER_HANDLE_STANBY, NO_REPEATED_TIMER);
}
void idac_timer_reset()
{
	/* //idacレベル調整タイマー reset*/
	gecko_cmd_hardware_set_soft_timer(0, TIMER_HANDLE_IDAC, NO_REPEATED_TIMER);
}

void flash_data_reset()
{
	//フラッシュデータをデフォルト値に戻す
	memcpy(ems_flash_data.udid, "AISILK-03-01W00", 15);//UDID
	ems_flash_data.pincode = 0;//pincode
	gecko_cmd_flash_ps_save((uint16)(FLASH_PS_KEY), (uint8)sizeof(ems_flash_data), (const uint8*)&ems_flash_data);

	ems_flash_dynamic_time_data.s_time = 1800;//ダイナミックモード強時間デフォルト設定
	ems_flash_dynamic_time_data.w_time = 1800;//ダイナミックモード弱時間デフォルト設定
	ems_flash_dynamic_time_data.tr_time = 30;//ダイナミックモードトレーニング基準時間設定
	ems_flash_dynamic_time_data.pitch_idac_on_time = 80;//ピッチモードidacON時間デフォルト設定
	ems_flash_dynamic_time_data.pitch_idac_off_time = 253;//ピッチモードidacOFF時間デフォルト設定
	ems_flash_dynamic_time_data.pitch_tr_time = 60;//ピッチモードトレーニング基準時間設定
	gecko_cmd_flash_ps_save((uint16)(FLASH_PS_KEY + 1), (uint8)sizeof(ems_flash_dynamic_time_data), (const uint8*)&ems_flash_dynamic_time_data);
}
#endif

/** @} (end addtogroup app) */
/** @} (end addtogroup Application) */
