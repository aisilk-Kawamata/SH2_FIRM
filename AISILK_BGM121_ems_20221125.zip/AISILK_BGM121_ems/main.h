/*
 * main.h
 *
 *  Created on: 2017/07/28
 *      Author: D-CLUE
 */

#ifndef MAIN_H_
#define MAIN_H_

//#define HARDWARE_ECG
//#define HARDWARE_EMG
#define HARDWARE_ASICS

#define NUM_SAMPLES                            4       /* CH数 */
#define NUM_ANALYSIS_DATA                      10240   /* 10秒 */
#define ANALYSIS_MAX_ADDRESS                   0x14000 /* 10240 x 4ch x 2byte */

#define FLASH_PS_KEY						0x4000
#define FLASH_PS_KEY_OFFSET					0x4040
#define ATT_DEFAULT_PAYLOAD_LEN				55

#define GET_STATUS_REQ        (0x01)
#define GET_STATUS_RES        (0x81)
#define GET_VERSION_REQ       (0x02)
#define GET_VERSION_RES       (0x82)
#define SET_TIME_REQ          (0x03)
#define SET_TIME_RES          (0x83)
#define SET_CONFIG_REQ        (0x04)
#define SET_CONFIG_RES        (0x84)
#define GET_CONFIG_REQ        (0x05)
#define GET_CONFIG_RES        (0x85)
#define GET_ANALYSIS_REQ      (0x06)
#define GET_ANALYSIS_RES      (0x86)
#define SET_LED_REQ           (0x07)
#define SET_LED_RES           (0x87)

#if defined (HARDWARE_ASICS)
#define GET_TRANSMITTER_STATUS_REQ (0x08)
#define GET_TRANSMITTER_STATUS_RES (0x88)
#else
#define GET_BATTERY_VOLTAGE_REQ (0x08)
#define GET_BATTERY_VOLTAGE_RES (0x88)
#endif

#define GET_CHARGING_INFO_REQ (0x09)
#define GET_CHARGING_INFO_RES (0x89)
#define SET_LED_STRONG_REQ    (0x0A)
#define SET_LED_STRONG_RES    (0x8A)
#define REC_START_REQ         (0x11)
#define REC_START_RES         (0x91)
#define REC_STOP_REQ          (0x12)
#define REC_STOP_RES          (0x92)
#define CALIB_START_REQ       (0x13)
#define CALIB_START_RES       (0x93)
#define CALIB_STOP_REQ        (0x14)
#define CALIB_STOP_RES        (0x94)

#define REPORT_DATA           (0xA1)
#define REPORT_DATA_ANALYSIS  (0xA2)
#define REPORT_DATA_END       (0xA3)

#if defined (HARDWARE_ASICS)
#define VERSION_MAJOR         (3)
#define VERSION_MINOR         (0)
#define VERSION_REVISION      (22)
#else
#define VERSION_MAJOR         (0x02)
#define VERSION_MINOR         (0x00)
#define VERSION_REVISION      (0x02)
#endif

//ems追加
#define EMS_START_REQ        		(0x41)
#define EMS_START_RES        		(0xC1)
#define EMS_STOP_REQ         		(0x42)
#define EMS_STOP_RES         		(0xC2)
#define SET_STIMULATION_POWER_REQ 	(0x43)
#define SET_STIMULATION_POWER_RES 	(0xC3)
#define EMS_SHUTDOWN_REQ 			(0x44)
#define EMS_SHUTDOWN_RES 			(0xC4)
#define EMS_PAUSE_REQ 				(0x45)
#define EMS_PAUSE_RES 				(0xC5)
#define SET_UDID_REQ 				(0x46)
#define SET_UDID_RES 				(0xC6)
#define GET_PINCODE_REQ 			(0x47)
#define GET_PINCODE_RES 			(0xC7)
#define SET_PINCODE_REQ 			(0x48)
#define SET_PINCODE_RES 			(0xC8)
#define GET_UDID_REQ 				(0x49)
#define GET_UDID_RES 				(0xC9)
#define SET_DYNAMIC_TIME_CHANGE_REQ (0x4A)
#define SET_DYNAMIC_TIME_CHANGE_RES (0xCA)
#define SET_DYNAMIC_TIME_SAVE_REQ 	(0x4B)
#define SET_DYNAMIC_TIME_SAVE_RES 	(0xCB)
#define SET_TEST_REQ				(0x4C)
#define SET_TEST_RES				(0xCC)
#define SET_PITCH_TIME_CHANGE_REQ   (0x4D)
#define SET_PITCH_TIME_CHANGE_RES   (0xCD)
#define SET_PITCH_TIME_SAVE_REQ 	(0x4E)
#define SET_PITCH_TIME_SAVE_RES 	(0xCE)

#define CONF_KIND_ECG                       1 /* 心電 */
#define CONF_KIND_EMG                       2 /* 筋電 */
#define CONF_NOTCH_ON                       1 /* Notch Filter ON */
#define CONF_NOTCH_OFF                      2 /* Notch Filter OFF */
#define CONF_NOTCH_FC_50                    1 /* Notch Filter 中心周波数　50[Hz] */
#define CONF_NOTCH_FC_60                    2 /* Notch Filter 中心周波数　60[Hz] */
#define CONF_EMG_TINT_100                   1 /* RMS平均の積算時間(Tint) 100[ms] */
#define CONF_EMG_TINT_200                   2 /* RMS平均の積算時間(Tint) 200[ms] */
#define CONF_EMG_TINT_300                   3 /* RMS平均の積算時間(Tint) 300[ms] */
#define CONF_ECG_TAV_20                     1 /* 単純平滑化積算時間(Tav) 20[ms] */
#define CONF_ECG_TAV_40                     2 /* 単純平滑化積算時間(Tav) 40[ms] */
#define CONF_SEND_DATA_20                   1 /* データ送信周期(Tt) 20[ms] */
#define CONF_SEND_DATA_40                   2 /* データ送信周期(Tt) 40[ms] */
#define CONF_AFE_GAIN                       1000 /* 倍 */

#ifdef HARDWARE_EMG
#define CONF_LPF_HZ							4000 /* 400Hz x 10 */
#define CONF_HPF_HZ							100	 /*	 10Hz x 10 */
#define OUTPUT_SAMPLING						2
#endif
#ifdef HARDWARE_ECG
#define CONF_LPF_HZ							400	/* 40Hz x 10 */
#define CONF_HPF_HZ							20	/* 2Hz x 10 */
#define OUTPUT_SAMPLING						1
#endif
#if defined (HARDWARE_ASICS)
#define CONF_LPF_HZ							4000 /* 400Hz x 10 */
#define CONF_HPF_HZ							100	 /*	 10Hz x 10 */
#define OUTPUT_SAMPLING						2

#define TIMER_PERIOD                       (32768*1) /* 1秒間隔 */
#define TIMER_HANDLE                       (1)       /* timerID 刺激用*/
#define REPEATED_TIMER                     (0)       /* リピートあり */

#define TIMER_HANDLE_DELAY                 (2)       /* timerID 遅延スタート用 */
#define NO_REPEATED_TIMER                  (1)       /* リピートなし */

#define TIMER_HANDLE_PAUSE                 (3)       /* timerID Pause2分タイマー */
#define TIMER_HANDLE_STANBY                (4)       /* timerID スタンバイ2分タイマー */
#define TIMER_HANDLE_PAIRING               (5)       /* timerID ペアリング1分タイマー */
#define TIMER_HANDLE_IDAC	               (6)       /* timerID idacを戻す5秒タイマー */
#define TIMER_HANDLE_BATTERY               (7)       /* timerID batteryチェック 1秒タイマー */
#define TIMER_HANDLE_TEST_DELAY            (8)       /* timerID テスト遅延スタート用 */
#endif


struct _ConfigData_t {
    uint8_t No;
    uint8_t Kind_ECG_EMG;
    uint8_t Notch_ON_OFF;
    uint8_t Notch_Fc;
    uint8_t EMG_Tint;
    uint8_t ECG_Tav;
    uint16_t Digital_Gain;
    uint8_t SendData_Tt;
    uint16_t AFE_Gain;
    uint16_t LPF_F;
    uint16_t HPF_F;
    uint16_t Max_Power;
    uint8_t Output_Sampling;
    uint8_t Wear_ID;
} ;
extern struct _ConfigData_t confData[NUM_SAMPLES];

struct _LedStrong_t {
	uint8_t no[12];
};
extern struct _LedStrong_t ledStrong;

struct _EMS_Flash_Data_t {
	uint32_t pincode;
	char udid[16];
};
extern struct _EMS_Flash_Data_t ems_flash_data;

struct _EMS_Flash_Dynamic_Time_Data_t {
	uint16_t s_time;	//ダイナミックモード強時間
	uint16_t w_time;	//ダイナミックモード弱時間
	uint8_t tr_time;	//ダイナミックモードトレーニング時間
	uint16_t pitch_idac_on_time;	//ピッチモードidacON時間
	uint16_t pitch_idac_off_time;	//ピッチモードidacOFF時間
	uint8_t pitch_tr_time;			//ピッチモードトレーニング時間
};
extern struct _EMS_Flash_Dynamic_Time_Data_t ems_flash_dynamic_time_data;

extern uint8_t     Connection_Id;
extern uint64_t    Sync_Time;
extern bool        Measure_Flag;
extern bool        Connection_Flag;
extern uint32_t    EMG_Tint;
extern uint32_t    ECG_Tav;
extern uint8_t     Wear_ID;
extern bool        CLed_Req_Flag;

void delay_timer_reset();
void pause_timer_reset();
void pairing_timer_reset();
void stanby_timer_reset();
void idac_timer_reset();
void flash_data_reset();
#endif /* MAIN_H_ */
