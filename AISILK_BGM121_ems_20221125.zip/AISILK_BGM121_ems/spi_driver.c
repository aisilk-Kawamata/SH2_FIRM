/*
 * spi_driver.c
 *
 *  Created on: 2017/08/09
 *      Author: D-CLUE
 */

#include "em_cmu.h"
#include "em_gpio.h"
#include "em_usart.h"

#include "main.h"
#include "spi_driver.h"

#define B_LO				0xC0
#define B_HI				0xF0

#if defined (HARDWARE_ASICS)
	#define SPI_MOSI_PORT	gpioPortF
	#define SPI_MOSI_PIN		6
#else
	#define SPI_MOSI_PORT	gpioPortC
	#define SPI_MOSI_PIN		10
#endif

#define SPI_MISO_PORT	gpioPortA
#define SPI_MISO_PIN		1
#define SPI_SCK_PORT		gpioPortA
#define SPI_SCK_PIN		2
#define SPI_CS_PORT		gpioPortA
#define SPI_CS_PIN		3

USART_TypeDef           * spi0    = USART0;
USART_InitSync_TypeDef  spiInit0  = USART_INITSYNC_DEFAULT;

void spi0_driver_put_char(uint8_t ch);
uint8_t spi0_driver_get_char(void);

uint8_t color_table_cnt;
bool color_table_flag;

uint8_t trans_buffer[24]={
							B_LO,B_LO,B_LO,B_LO,B_LO,B_LO,B_LO,B_LO,
							B_LO,B_LO,B_LO,B_LO,B_LO,B_LO,B_LO,B_LO,
							B_LO,B_LO,B_LO,B_LO,B_LO,B_LO,B_LO,B_LO
						};

const uint8_t COLOR_TABLE_BASE_TEST[10][8] =
{
	{B_LO,B_LO,B_LO,B_LO,B_LO,B_LO,B_LO,B_LO},// 0x00
	{B_LO,B_LO,B_HI,B_LO,B_LO,B_LO,B_HI,B_LO},// 0x22
	{B_LO,B_HI,B_LO,B_LO,B_LO,B_HI,B_LO,B_LO},// 0x44
	{B_LO,B_HI,B_HI,B_LO,B_LO,B_HI,B_HI,B_LO},// 0x66
	{B_LO,B_HI,B_HI,B_HI,B_HI,B_HI,B_HI,B_HI},// 0x7F
	{B_HI,B_LO,B_LO,B_LO,B_HI,B_LO,B_LO,B_LO},// 0x88
	{B_HI,B_LO,B_HI,B_LO,B_HI,B_LO,B_HI,B_LO},// 0xAA
	{B_HI,B_HI,B_LO,B_LO,B_HI,B_HI,B_LO,B_LO},// 0xCC
	{B_HI,B_HI,B_HI,B_LO,B_HI,B_HI,B_HI,B_LO},// 0xEE
	{B_HI,B_HI,B_HI,B_HI,B_HI,B_HI,B_HI,B_HI},// 0xFF
};

const uint8_t COLOR_TABLE_TEST_0[7][3] =
{
	{0x00,0x00,0x02},// 0x00,0x00,0x44(B:25%)
	{0x02,0x00,0x00},// 0x44,0x00,0x00(G:25%)
	{0x00,0x02,0x00},// 0x00,0x44,0x00(R:25%)
	{0x00,0x00,0x00},// 0x00,0x00,0x00
	{0x01,0x02,0x00},// 0x22,0x44,0x00(ORANGE)
	{0x01,0x00,0x01},// 0x22,0x00,0x22(LIGHT BLUE)
	{0x01,0x01,0x00},// 0x22,0x22,0x00(YELLOW)
};
const uint8_t COLOR_TABLE_TEST_1[7][3] =
{
	{0x00,0x00,0x04},// 0x00,0x00,0x7F(B:50%)
	{0x04,0x00,0x00},// 0x7F,0x00,0x00(G:50%)
	{0x00,0x04,0x00},// 0x00,0x7F,0x00(R:50%)
	{0x00,0x00,0x00},// 0x00,0x00,0x00
	{0x02,0x04,0x00},// 0x44,0x88,0x00(ORANGE)
	{0x02,0x00,0x02},// 0x44,0x00,0x44(LIGHT BLUE)
	{0x02,0x02,0x00},// 0x44,0x44,0x00(YELLOW)
};
const uint8_t COLOR_TABLE_TEST_2[7][3] =
{
	{0x00,0x00,0x09},// 0x00,0x00,0xFF(B:100%)
	{0x09,0x00,0x00},// 0xFF,0x00,0x00(G:100%)
	{0x00,0x09,0x00},// 0x00,0xFF,0x00(R:100%)
	{0x00,0x00,0x00},// 0x00,0x00,0x00
	{0x05,0x08,0x00},// 0xAA,0xFF,0x00(ORANGE)
	{0x04,0x00,0x04},// 0x88,0x00,0x88(LIGHT BLUE)
	{0x04,0x04,0x00},// 0x88,0x88,0x00(YELLOW)
};

const uint8_t COLOR_TABLE_BASE[9][8] =
{
//	{B_LO,B_LO,B_LO,B_LO,B_LO,B_LO,B_LO,B_LO},// 0x00
//	{B_LO,B_LO,B_HI,B_LO,B_LO,B_LO,B_HI,B_LO},// 0x22
//	{B_LO,B_HI,B_LO,B_LO,B_LO,B_HI,B_LO,B_LO},// 0x44
//	{B_LO,B_HI,B_HI,B_LO,B_LO,B_HI,B_HI,B_LO},// 0x66
//	{B_HI,B_LO,B_LO,B_LO,B_HI,B_LO,B_LO,B_LO},// 0x88
//	{B_HI,B_LO,B_HI,B_LO,B_HI,B_LO,B_HI,B_LO},// 0xAA
//	{B_HI,B_HI,B_LO,B_LO,B_HI,B_HI,B_LO,B_LO},// 0xCC
//	{B_HI,B_HI,B_HI,B_LO,B_HI,B_HI,B_HI,B_LO},// 0xEE
//	{B_HI,B_HI,B_HI,B_HI,B_HI,B_HI,B_HI,B_HI},// 0xFF
	{B_LO,B_LO,B_LO,B_LO,B_LO,B_LO,B_LO,B_LO},// 0x00
	{B_LO,B_LO,B_LO,B_HI,B_LO,B_LO,B_LO,B_HI},// 0x11
	{B_LO,B_LO,B_HI,B_LO,B_LO,B_LO,B_HI,B_LO},// 0x22
	{B_LO,B_LO,B_HI,B_HI,B_LO,B_LO,B_HI,B_HI},// 0x33
	{B_LO,B_HI,B_LO,B_LO,B_LO,B_HI,B_LO,B_LO},// 0x44
	{B_LO,B_HI,B_LO,B_HI,B_LO,B_HI,B_LO,B_HI},// 0x55
	{B_LO,B_HI,B_HI,B_LO,B_LO,B_HI,B_HI,B_LO},// 0x66
	{B_LO,B_HI,B_HI,B_HI,B_LO,B_HI,B_HI,B_HI},// 0x77
	{B_HI,B_LO,B_LO,B_LO,B_HI,B_LO,B_LO,B_LO},// 0x88
};
const uint8_t COLOR_TABLE[16][3] =
{
	{0x00,0x00,0x08},// 0x00,0x00,0xFF
	{0x02,0x00,0x08},// 0x44,0x00,0xFF
	{0x04,0x00,0x08},// 0x88,0x00,0xFF
	{0x06,0x00,0x08},// 0xCC,0x00,0xFF
	{0x08,0x00,0x07},// 0xFF,0x00,0xEE
	{0x08,0x00,0x05},// 0xFF,0x00,0xAA
	{0x08,0x00,0x03},// 0xFF,0x00,0x66
	{0x08,0x00,0x01},// 0xFF,0x00,0x22
	{0x08,0x01,0x00},// 0xFF,0x22,0x00
	{0x08,0x03,0x00},// 0xFF,0x66,0x00
	{0x08,0x05,0x00},// 0xFF,0xAA,0x00
	{0x08,0x07,0x00},// 0xFF,0xEE,0x00
	{0x06,0x08,0x00},// 0xCC,0xFF,0x00
	{0x04,0x08,0x00},// 0x88,0xFF,0x00
	{0x02,0x08,0x00},// 0x44,0xFF,0x00
	{0x00,0x08,0x00},// 0x00,0xFF,0x00
};

void spi0_driver_init(void)
{
  CMU_ClockEnable(cmuClock_GPIO, true);
  CMU_ClockEnable(cmuClock_USART0, true);

  GPIO_PinModeSet(SPI_MOSI_PORT, SPI_MOSI_PIN, gpioModePushPull, 1);
  GPIO_PinModeSet(SPI_MISO_PORT, SPI_MISO_PIN, gpioModeInput, 0);
  GPIO_PinModeSet(SPI_SCK_PORT,  SPI_SCK_PIN,  gpioModePushPull, 1);
  GPIO_PinModeSet(SPI_CS_PORT,   SPI_CS_PIN,   gpioModePushPull, 1);

  spiInit0.msbf = true;
  spiInit0.baudrate = 8000000;
  spiInit0.prsRxCh = usartPrsRxCh0;
  USART_InitSync(spi0, &spiInit0);

  USART_IntClear(spi0, _USART_IFC_MASK);
  NVIC_ClearPendingIRQ(USART0_RX_IRQn);
  NVIC_ClearPendingIRQ(USART0_TX_IRQn);

  spi0->CTRL = (USART_CTRL_SYNC | USART_CTRL_MSBF);
  spi0->CMD = USART_CMD_MASTEREN | USART_CMD_TXEN;
  spi0->ROUTEPEN = (USART_ROUTEPEN_TXPEN);
#if defined (HARDWARE_ASICS)
  spi0->ROUTELOC0 = (USART_ROUTELOC0_TXLOC_LOC30);
#else
  spi0->ROUTELOC0 = (USART_ROUTELOC0_TXLOC_LOC15);
#endif
  USART_Enable(spi0, usartEnable);

  color_table_cnt = 0;
  color_table_flag = true;
}

uint8_t spi0_driver_get_char(void)
{
	while(!(USART_StatusGet(spi0)& USART_STATUS_RXDATAV));
	return USART_Rx(spi0);
}

void spi0_driver_put_char(uint8_t ch)
{
	USART_Tx(spi0, ch);
	while(!(USART_StatusGet(spi0)& USART_STATUS_TXC));
}

void SRAM_Write_Data(uint32_t Address, int16_t Data)
{
	GPIO_PinModeSet(gpioPortA, 3, gpioModePushPull, 0);
	spi0_driver_put_char(0x02);
	spi0_driver_put_char((Address >> 16) & 0xFF);
	spi0_driver_put_char((Address >> 8) & 0xFF);
	spi0_driver_put_char((Address >> 0) & 0xFF);
	spi0_driver_put_char((Data >> 8) & 0xFF);
	GPIO_PinModeSet(gpioPortA, 3, gpioModePushPull, 1);

	Address += 1;
    GPIO_PinModeSet(gpioPortA, 3, gpioModePushPull, 0);
    spi0_driver_put_char(0x02);
    spi0_driver_put_char((Address >> 16) & 0xFF);
    spi0_driver_put_char((Address >> 8) & 0xFF);
    spi0_driver_put_char((Address >> 0) & 0xFF);
    spi0_driver_put_char((Data >> 0) & 0xFF);
	GPIO_PinModeSet(gpioPortA, 3, gpioModePushPull, 1);
}

int16_t SRAM_Read_Data(uint32_t Address)
{
	uint16_t read_data = 0;
	uint8_t tmp_data = 0;

	GPIO_PinModeSet(gpioPortA, 3, gpioModePushPull, 0);
	spi0_driver_put_char(0x03);
	spi0_driver_put_char((Address >> 16) & 0xFF);
	spi0_driver_put_char((Address >> 8) & 0xFF);
	spi0_driver_put_char((Address >> 0) & 0xFF);
	spi0_driver_put_char(0x00);
	GPIO_PinModeSet(gpioPortA, 3, gpioModePushPull, 1);
	tmp_data = spi0_driver_get_char();
	tmp_data = spi0_driver_get_char();
	tmp_data = spi0_driver_get_char();
	read_data = ((tmp_data << 8) & 0xFF00);

	Address += 1;
	GPIO_PinModeSet(gpioPortA, 3, gpioModePushPull, 0);
	spi0_driver_put_char(0x03);
	spi0_driver_put_char((Address >> 16) & 0xFF);
	spi0_driver_put_char((Address >> 8) & 0xFF);
	spi0_driver_put_char((Address >> 0) & 0xFF);
	spi0_driver_put_char(0x00);
	GPIO_PinModeSet(gpioPortA, 3, gpioModePushPull, 1);
	tmp_data = spi0_driver_get_char();
	tmp_data = spi0_driver_get_char();
	tmp_data = spi0_driver_get_char();
	read_data |= ((tmp_data << 0) & 0x00FF);

	return read_data;
}

void disp_led_strong(void)
{
	int i;
	int j;
	uint8_t led_g;
	uint8_t led_r;
	uint8_t led_b;

	for (i=0; i<12; i++){

		led_g = COLOR_TABLE[ledStrong.no[i]][0];
		led_r = COLOR_TABLE[ledStrong.no[i]][1];
		led_b = COLOR_TABLE[ledStrong.no[i]][2];

		for (j=0; j<8; j++) {
			USART_Tx(spi0, COLOR_TABLE_BASE[led_g][j]);
		}
		for (j=0; j<8; j++) {
			USART_Tx(spi0, COLOR_TABLE_BASE[led_r][j]);
		}
		for (j=0; j<8; j++) {
			USART_Tx(spi0, COLOR_TABLE_BASE[led_b][j]);
		}
	}
}

void disp_led_simple(int16_t lednum, int16_t test_led_table_num)
{
	int j;
	uint8_t led_g;
	uint8_t led_r;
	uint8_t led_b;

	switch(test_led_table_num)
	{
		case	0:
			led_g = COLOR_TABLE_TEST_0[lednum][0];
			led_r = COLOR_TABLE_TEST_0[lednum][1];
			led_b = COLOR_TABLE_TEST_0[lednum][2];
			break;
		case	1:
			led_g = COLOR_TABLE_TEST_1[lednum][0];
			led_r = COLOR_TABLE_TEST_1[lednum][1];
			led_b = COLOR_TABLE_TEST_1[lednum][2];
			break;
		case	2:
			led_g = COLOR_TABLE_TEST_2[lednum][0];
			led_r = COLOR_TABLE_TEST_2[lednum][1];
			led_b = COLOR_TABLE_TEST_2[lednum][2];
			break;
		default:
			led_g = COLOR_TABLE_TEST_0[lednum][0];
			led_r = COLOR_TABLE_TEST_0[lednum][1];
			led_b = COLOR_TABLE_TEST_0[lednum][2];
			break;
	}

	for (j=0; j<8; j++) {
		USART_Tx(spi0, COLOR_TABLE_BASE_TEST[led_g][j]);
	}
	for (j=0; j<8; j++) {
		USART_Tx(spi0, COLOR_TABLE_BASE_TEST[led_r][j]);
	}
	for (j=0; j<8; j++) {
		USART_Tx(spi0, COLOR_TABLE_BASE_TEST[led_b][j]);
	}
}

void set_led_rgb(uint8_t red, uint8_t green, uint8_t blue)
{
	uint8_t R[3]={green, red, blue};
	uint8_t i;
	uint8_t j;

	for(i=0;i<3;i++)
	{
		for(j=0;j<8;j++)
		{
		    if( R[i] & 1 << (7 - j) )
		    {
		        //bit ON
		        trans_buffer[i*8+j]=B_HI;
		    }
		    else
		    {
		        //bit off
		        trans_buffer[i*8+j]=B_LO;
		    }
		}
	}
}

void disp_led_rgb()
{
	uint8_t i;
	for (i=0; i<24; i++) {
		USART_Tx(spi0, trans_buffer[i]);
	}

}



