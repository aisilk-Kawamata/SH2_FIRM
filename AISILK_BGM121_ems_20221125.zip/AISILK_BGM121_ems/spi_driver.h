/*
 * spi_driver.h
 *
 *  Created on: 2017/08/09
 *      Author: D-CLUE
 */

#ifndef SPI_DRIVER_H_
#define SPI_DRIVER_H_

extern void spi0_driver_init(void);
extern void SRAM_Write_Data(uint32_t Address, int16_t Data);
extern int16_t SRAM_Read_Data(uint32_t Address);

extern void disp_led_strong(void);
extern void disp_led_simple(int16_t lednum, int16_t test_led_table_num);
extern void set_led_rgb(uint8_t red, uint8_t green, uint8_t blue);
extern void disp_led_rgb();

#endif /* SPI_DRIVER_H_ */
