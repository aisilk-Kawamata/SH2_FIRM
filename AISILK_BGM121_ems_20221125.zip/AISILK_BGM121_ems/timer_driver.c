/*
 * timer_driver.c
 *
 *  Created on: 2017/07/27
 *      Author: D-CLUE
 */

#include "em_emu.h"
#include "em_cmu.h"
#include "em_gpio.h"
#include "em_timer.h"

#include "main.h"
#include "adc_driver.h"
#include "timer_driver.h"
#include "emg.h"
#include "spi_driver.h"

#if defined (HARDWARE_ASICS)
#include "ems.h"
#endif

bool test_flag = false;

#if defined (HARDWARE_ASICS)
static	uint16_t	pwm_duty = 50;
bool test_buzzer_flag = false;
//static	volatile uint16_t	buzzer_counter=0;

#endif

void gpio_test(void)
{
	if (test_flag == false) {
		test_flag = true;
		//GPIO_PinModeSet(gpioPortC, 10, gpioModePushPull, 0);
		GPIO_PinModeSet(gpioPortF, 7, gpioModePushPull, 0);
	}
	else {
		test_flag = false;
		//GPIO_PinModeSet(gpioPortC, 10, gpioModePushPull, 1);
		GPIO_PinModeSet(gpioPortF, 7, gpioModePushPull, 1);
	}
}

#if defined (HARDWARE_ASICS)
#else
bool led_toggle;
void led_control(void)
{
	if (Connection_Flag == true) {
		GPIO_PinModeSet(L_ORANGE_PORT, L_ORANGE_PIN, gpioModePushPull, L_ORANGE_ON);
	}
	else {
		if (led_toggle == false) {
			led_toggle = true;
			GPIO_PinModeSet(L_ORANGE_PORT, L_ORANGE_PIN, gpioModePushPull, L_ORANGE_ON);
		}
		else {
			led_toggle = false;
			GPIO_PinModeSet(gpioPortF, 6, gpioModePushPull, L_ORANGE_OFF);
		}
	}
}
#endif

void timer0_driver_init(void)
{
	/* Enable clock for TIMER0 module */
	CMU_ClockEnable(cmuClock_TIMER0, true);

#if defined (HARDWARE_ASICS)
	/* Select CC channel parameters */
	TIMER_InitCC_TypeDef timerCC0Init =
	{
	    .eventCtrl  = timerEventEveryEdge,
	    .edge       = timerEdgeBoth,
	    .prsSel     = timerPRSSELCh0,
	    .cufoa      = timerOutputActionNone,
	    .cofoa      = timerOutputActionNone,
	    .cmoa       = timerOutputActionToggle,
	    .mode       = timerCCModePWM,
	    .filter     = false,
	    .prsInput   = false,
	    .coist      = false,
	    .outInvert  = false,
	};
	TIMER_InitCC(TIMER0, 0, &timerCC0Init);

	/* トップ値を設定 */
	TIMER_TopSet(TIMER0,REG_TIMER0_TOP);

	TIMER_Init_TypeDef timerInit =
	{
	    .enable     = true,
	    .debugRun   = true,
	    .prescale   = timerPrescale1,
	    .clkSel     = timerClkSelHFPerClk,
	    .fallAction = timerInputActionNone,
	    .riseAction = timerInputActionNone,
	    .mode       = timerModeUp,
	    .dmaClrAct  = false,
	    .quadModeX4 = false,
	    .oneShot    = false,
	    .sync       = false,
	};

	TIMER_Init(TIMER0, &timerInit);

	/*与えられたデューティサイクル値をタイマにセットする*/
	TIMER_CompareBufSet(TIMER0,0,TIMER_TopGet(TIMER0) * (pwm_duty/100));

#else
	/* Select CC channel parameters */
	TIMER_InitCC_TypeDef timerCCInit =
	{
	    .eventCtrl  = timerEventEveryEdge,
	    .edge       = timerEdgeBoth,
	    .prsSel     = timerPRSSELCh0,
	    .cufoa      = timerOutputActionNone,
	    .cofoa      = timerOutputActionNone,
	    .cmoa       = timerOutputActionToggle,
	    .mode       = timerCCModePWM,
	    .filter     = false,
	    .prsInput   = false,
	    .coist      = false,
	    .outInvert  = false,
	};
	TIMER_InitCC(TIMER0, 0, &timerCCInit);

	TIMER_CompareSet(TIMER0, REG_TIMER0_CHANNEL, 1);
	TIMER_TopSet(TIMER0, REG_TIMER0_TOP);

	TIMER_Init_TypeDef timerInit =
	{
	    .enable     = true,
	    .debugRun   = true,
	    .prescale   = timerPrescale1,
	    .clkSel     = timerClkSelHFPerClk,
	    .fallAction = timerInputActionNone,
	    .riseAction = timerInputActionNone,
	    .mode       = timerModeUp,
	    .dmaClrAct  = false,
	    .quadModeX4 = false,
	    .oneShot    = false,
	    .sync       = false,
	};
	TIMER_Init(TIMER0, &timerInit);
#endif
}

void timer1_driver_init(void)
{
	/* Enable clock for TIMER0 module */
	CMU_ClockEnable(cmuClock_TIMER1, true);

#if defined (HARDWARE_ASICS)
	/* Select CC channel parameters */
	TIMER_InitCC_TypeDef timerCCInit =
	{
	    .eventCtrl  = timerEventEveryEdge,
	    .edge       = timerEdgeBoth,
	    .prsSel     = timerPRSSELCh0,
	    .cufoa      = timerOutputActionNone,
	    .cofoa      = timerOutputActionNone,
	    .cmoa       = timerOutputActionToggle,
	    .mode       = timerCCModePWM,
	    .filter     = false,
	    .prsInput   = false,
	    .coist      = false,
	    .outInvert  = false,
	};
	TIMER_InitCC(TIMER1, 0, &timerCCInit);

	TIMER_CompareSet(TIMER1, REG_TIMER1_CHANNEL, 1);
	TIMER_TopSet(TIMER1, REG_TIMER1_TOP);

	TIMER_Init_TypeDef timerInit =
	{
	    .enable     = true,
	    .debugRun   = true,
	    .prescale   = timerPrescale1,
	    .clkSel     = timerClkSelHFPerClk,
	    .fallAction = timerInputActionNone,
	    .riseAction = timerInputActionNone,
	    .mode       = timerModeUp,
	    .dmaClrAct  = false,
	    .quadModeX4 = false,
	    .oneShot    = false,
	    .sync       = false,
	};

	TIMER_Init(TIMER1, &timerInit);

#else
	/* Select CC channel parameters */
	TIMER_InitCC_TypeDef timerCCInit =
	{
	    .eventCtrl  = timerEventEveryEdge,
	    .edge       = timerEdgeBoth,
	    .prsSel     = timerPRSSELCh0,
	    .cufoa      = timerOutputActionNone,
	    .cofoa      = timerOutputActionNone,
	    .cmoa       = timerOutputActionToggle,
	    .mode       = timerCCModePWM,
	    .filter     = false,
	    .prsInput   = false,
	    .coist      = false,
	    .outInvert  = false,
	};
	TIMER_InitCC(TIMER1, 0, &timerCCInit);

	TIMER_CompareSet(TIMER1, REG_TIMER1_CHANNEL, 1);
	TIMER_TopSet(TIMER1, REG_TIMER1_TOP);

	TIMER_Init_TypeDef timerInit =
	{
	    .enable     = true,
	    .debugRun   = true,
	    .prescale   = timerPrescale1024,
	    .clkSel     = timerClkSelHFPerClk,
	    .fallAction = timerInputActionNone,
	    .riseAction = timerInputActionNone,
	    .mode       = timerModeUp,
	    .dmaClrAct  = false,
	    .quadModeX4 = false,
	    .oneShot    = false,
	    .sync       = false,
	};
	TIMER_Init(TIMER1, &timerInit);

	led_toggle = false;
#endif
}

void timer0_driver_start(void)
{
	/* Enable TIMER0 interrupt vector in NVIC */
	NVIC_EnableIRQ(TIMER0_IRQn);

	/* Enable overflow interrupt */
#if defined (HARDWARE_ASICS)
	TIMER_IntEnable(TIMER0, TIMER_IF_OF);
#else
	TIMER_IntEnable(TIMER0, TIMER_IF_CC0);
#endif
}

void timer0_driver_stop(void)
{
	/* Enable overflow interrupt */
#if defined (HARDWARE_ASICS)
	TIMER_IntDisable(TIMER0, TIMER_IF_OF);
#else
	TIMER_IntDisable(TIMER0, TIMER_IF_CC0);
#endif
	/* Enable TIMER0 interrupt vector in NVIC */
	NVIC_DisableIRQ(TIMER0_IRQn);
}
void TIMER0_IRQHandler(void)
{
	uint32_t compareValue;

	/* Clear flag for TIMER0 overflow interrupt */
#if defined (HARDWARE_ASICS)
	TIMER_IntClear(TIMER0, TIMER_IF_OF);
	//GPIO_PinOutToggle(BUZZER_PORT, BUZZER_PIN);
	ems_buzzer_out();
#else
	TIMER_IntClear(TIMER0, TIMER_IF_CC0);
#endif

	compareValue = TIMER_CaptureGet(TIMER0, 0);

	if( compareValue == TIMER_TopGet(TIMER0)) {
		TIMER_CounterSet(TIMER0, 0);
	}
	else {
		TIMER_CounterSet(TIMER0, ++compareValue);
	}

#if defined (HARDWARE_ASICS)
	/*与えられたデューティサイクル値をタイマにセットする*/
	//TIMER_CompareBufSet(TIMER0,0,TIMER_TopGet(TIMER0) * (pwm_duty/100));
#else

	Sync_Time++;

  if (Measure_Flag == true) {

	  // 処理時間測定用
      //gpio_test();

      emg_data_get();

      //gpio_test();
	  // 処理時間測定用
  }
  else {
    if (CLed_Req_Flag == true) {
    		CLed_Req_Flag = false;
    		disp_led_strong();
    }
  }
#endif
}

void timer1_driver_start(void)
{
	/* Enable TIMER1 interrupt vector in NVIC */
	NVIC_EnableIRQ(TIMER1_IRQn);

	/* Enable overflow interrupt */
	TIMER_IntEnable(TIMER1, TIMER_IF_CC0);
}
void timer_driver_init_pwm(void)
{
#if defined (HARDWARE_ASICS)
	/* PWMに使用するピンを初期化する*/
	GPIO_PinModeSet(BUZZER_PORT,BUZZER_PIN,gpioModePushPull,0);

	/*CC0を設定*/
	TIMER0->ROUTELOC0	=(TIMER0-> ROUTELOC0&(~_TIMER_ROUTELOC0_CC0LOC_MASK))| TIMER_ROUTELOC0_CC0LOC_LOC7;
	TIMER0->ROUTEPEN	=TIMER0-> ROUTEPEN | TIMER_ROUTEPEN_CC0PEN;
#else
#endif
}

void timer1_driver_stop(void)
{
	/* Enable overflow interrupt */
	TIMER_IntDisable(TIMER1, TIMER_IF_CC0);

	/* Enable TIMER1 interrupt vector in NVIC */
	NVIC_DisableIRQ(TIMER1_IRQn);
}

void TIMER1_IRQHandler(void)
{
  uint32_t compareValue;

  /* Clear flag for TIMER0 overflow interrupt */

  TIMER_IntClear(TIMER1, TIMER_IF_CC0);

  compareValue = TIMER_CaptureGet(TIMER1, REG_TIMER1_CHANNEL);
  if( compareValue == TIMER_TopGet(TIMER1)) {
    TIMER_CounterSet(TIMER1, REG_TIMER1_CHANNEL);
  }

#if defined (HARDWARE_ASICS)
  	ems_timer();
#else
  led_control();
#endif
}

/*テスト用
void test_buzzer_flag_change()
{
	if (test_buzzer_flag == ON)
	{
		timer0_driver_stop();
		test_buzzer_flag = OFF;
	}
	else
	{
		timer0_driver_start();
		test_buzzer_flag = ON;
	}
}
*/

