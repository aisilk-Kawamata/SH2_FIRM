/*
 * timer_driver.h
 *
 *  Created on: 2017/07/27
 *      Author: D-CLUE
 */

#ifndef TIMER_DRIVER_H_
#define TIMER_DRIVER_H_

#if !defined (HARDWARE_ASICS)
#define L_ORANGE_PORT			gpioPortF
#define L_ORANGE_PIN				6
#define L_ORANGE_ON				0
#define L_ORANGE_OFF				1
#endif


#if defined (HARDWARE_ASICS)
	#define REG_TIMER0_TOP           27428 //1.4kHz:714.28us
	#define REG_TIMER0_CHANNEL       0

	#define REG_TIMER1_TOP           192	//5us
	#define REG_TIMER1_CHANNEL       0
#else
#define REG_TIMER0_TOP           38400
#define REG_TIMER0_CHANNEL       0
#define REG_TIMER1_TOP           38400
#define REG_TIMER1_CHANNEL       0
#endif
extern void timer0_driver_init(void);
extern void timer0_driver_start(void);
extern void timer0_driver_stop(void);

extern void timer1_driver_init(void);
extern void timer1_driver_start(void);
extern void timer1_driver_stop(void);

extern void timer_driver_init_pwm(void);

extern void test_buzzer_flag_change();
extern	volatile uint16_t	mode_1s_counter;

#endif /* TIMER_DRIVER_H_ */
