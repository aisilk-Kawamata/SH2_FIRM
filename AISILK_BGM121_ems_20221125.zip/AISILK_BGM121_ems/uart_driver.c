/*
 * uart_driver.c
 *
 *  Created on: 2017/05/08
 *      Author: D-CLUE
 */

#include <stdio.h>
#include <string.h>

#include "em_cmu.h"
#include "em_gpio.h"
#include "em_usart.h"

#include "main.h"
#include "uart_driver.h"
#include "ecg.h"

/* Declare a circular buffer structure to use for Rx and Tx queues */
#define BUFFERSIZE          32

/* Declare some strings */
const char     welcomeString[]  = "Welcome SH-2 System\n";
const uint32_t welLen           = sizeof(welcomeString) - 1;

volatile struct circularBuffer
{
  uint8_t  data[BUFFERSIZE];  /* data buffer */
  uint32_t rdI;               /* read index */
  uint32_t wrI;               /* write index */
  uint32_t pendingBytes;      /* count of how many bytes are not yet handled */
  bool     overflow;          /* buffer overflow indicator */
} rxBuf0, txBuf0 = { {0}, 0, 0, 0, false }, rxBuf1, txBuf1 = { {0}, 0, 0, 0, false };

static USART_TypeDef           * uart0   = USART0;
static USART_InitAsync_TypeDef uartInit0 = USART_INITASYNC_DEFAULT;
static USART_TypeDef           * uart1   = USART1;
static USART_InitAsync_TypeDef uartInit1 = USART_INITASYNC_DEFAULT;

bool test_flag_uart = false;
void gpio_test_uart(void)
{
	if (test_flag_uart == false) {
		test_flag_uart = true;
//		GPIO_PinModeSet(gpioPortC, 10, gpioModePushPull, 0);
		//GPIO_PinModeSet(gpioPortF, 6, gpioModePushPull, 0);
	}
	else {
		test_flag_uart = false;
//		GPIO_PinModeSet(gpioPortC, 10, gpioModePushPull, 1);
		//GPIO_PinModeSet(gpioPortF, 6, gpioModePushPull, 1);
	}
}

uint32_t uart1_driver_analysis_state;
uint32_t uart1_driver_analysis_cnt;
int16_t ecg_value;
void uart1_driver_analysis(uint8_t data)
{
	switch(uart1_driver_analysis_state) {
	case 0:
		if (data == 0xAA) {
			uart1_driver_analysis_state++;
		}
		else {
			uart1_driver_analysis_state = 0;
		}
		break;

	case 1:
		if (data == 0xAA) {
			uart1_driver_analysis_state++;
			//gpio_test_uart();
		}
		else {
			uart1_driver_analysis_state = 0;
		}
		break;

	case 2:
		if (data == 0x04) {
			uart1_driver_analysis_state = 3;
		}
		else if (data == 0x12) {
			uart1_driver_analysis_state = 13;
		}
		else {
			uart1_driver_analysis_state = 0;
		}
		break;

	case 3:
		if (data == 0x80) {
			uart1_driver_analysis_state++;
		}
		else {
			uart1_driver_analysis_state = 0;
		}
		break;


	case 4:
		if (data == 0x02) {
			uart1_driver_analysis_state++;
		}
		else {
			uart1_driver_analysis_state = 0;
		}
		break;

	case 5:
		ecg_value = 0;
		ecg_value = ((data << 8) & 0xFF00);
		uart1_driver_analysis_state++;
		break;

	case 6:
		ecg_value |= ((data << 0) & 0x00FF);
		uart1_driver_analysis_state = 0;
		ecg_rawdata_set(ecg_value);

		//uart0_driver_put_char(++uart1_driver_analysis_cnt);
		//uart0_driver_put_char((ecg_value >> 8) & 0xFF);
		//uart0_driver_put_char((ecg_value >> 0) & 0xFF);
		break;

	case 13:
		if (data == 0x02) {
			uart1_driver_analysis_state++;
		}
		else {
			uart1_driver_analysis_state = 0;
		}
		break;


	case 14:
		if (data == 0xC8) {
			uart1_driver_analysis_state++;
		}
		else {
			uart1_driver_analysis_state = 0;
		}
		break;

	case 15:
		if (data == 0x03) {
			uart1_driver_analysis_state++;
		}
		else {
			uart1_driver_analysis_state = 0;
		}
		break;

	case 16:
		ecg_hrdata1_set(data);
		uart1_driver_analysis_state = 0;
		break;
	}
}

uint8_t sensor_status;
void uart1_driver_analysis2(uint8_t data)
{
	switch(uart1_driver_analysis_state) {
	case 0:
		if (data == 0xAA) {
			uart1_driver_analysis_state++;
		}
		else {
			uart1_driver_analysis_state = 0;
		}
		break;

	case 1:
		if (data == 0xAA) {
			uart1_driver_analysis_state++;
		}
		else {
			uart1_driver_analysis_state = 0;
		}
		break;

	case 2:
		if (data == 0x12) {
			uart1_driver_analysis_state++;
		}
		else {
			uart1_driver_analysis_state = 0;
		}
		break;

	case 3:
		if (data == 0x02) {
			uart1_driver_analysis_state++;
		}
		else {
			uart1_driver_analysis_state = 0;
		}
		break;


	case 4:
		uart0_driver_put_char(0xFF);
		uart0_driver_put_char(data);
		uart1_driver_analysis_state++;
		break;

	case 5:
		if (data == 0x03) {
			uart1_driver_analysis_state++;
		}
		else {
			uart1_driver_analysis_state = 0;
		}
		break;

	case 6:
		uart0_driver_put_char(data);
		uart1_driver_analysis_state = 0;
		break;
	}

}
void uart0_driver_init(void)
{
  CMU_ClockEnable(cmuClock_GPIO, true);
  CMU_ClockEnable(cmuClock_USART0, true);

  GPIO_PinModeSet(gpioPortA, 0, gpioModePushPull, 1);
  GPIO_PinModeSet(gpioPortA, 1, gpioModeInput, 0);

  uartInit0.enable       = usartDisable;   /* Don't enable UART upon intialization */
  uartInit0.refFreq      = 0;              /* Provide information on reference frequency. When set to 0, the reference frequency is */
  uartInit0.baudrate     = 115200;         /* Baud rate */
  uartInit0.oversampling = usartOVS16;     /* Oversampling. Range is 4x, 6x, 8x or 16x */
  uartInit0.databits     = usartDatabits8; /* Number of data bits. Range is 4 to 10 */
  uartInit0.parity       = usartNoParity;  /* Parity mode */
  uartInit0.stopbits     = usartStopbits1; /* Number of stop bits. Range is 0 to 2 */
  uartInit0.mvdis        = false;          /* Disable majority voting */
  uartInit0.prsRxEnable  = false;          /* Enable USART Rx via Peripheral Reflex System */
  uartInit0.prsRxCh      = usartPrsRxCh0;  /* Select PRS channel if enabled */

  USART_InitAsync(uart0, &uartInit0);

  USART_IntClear(uart0, _USART_IFC_MASK);
  USART_IntEnable(uart0, USART_IEN_RXDATAV);
  NVIC_ClearPendingIRQ(USART0_RX_IRQn);
  NVIC_ClearPendingIRQ(USART0_TX_IRQn);
  NVIC_EnableIRQ(USART0_RX_IRQn);
  NVIC_EnableIRQ(USART0_TX_IRQn);
  uart0->ROUTEPEN = (USART_ROUTEPEN_RXPEN | USART_ROUTEPEN_TXPEN);
  uart0->ROUTELOC0 = (USART_ROUTELOC0_TXLOC_DEFAULT | USART_ROUTELOC0_RXLOC_DEFAULT);
  USART_Enable(uart0, usartEnable);

  uart0_driver_put_data((uint8_t *)welcomeString, welLen);
}

void uart1_driver_init(void)
{
  CMU_ClockEnable(cmuClock_GPIO, true);
  CMU_ClockEnable(cmuClock_USART1, true);

  GPIO_PinModeSet(gpioPortC, 8, gpioModePushPull, 1); // Tx
  GPIO_PinModeSet(gpioPortC, 9, gpioModeInput, 0);    // Rx

  uartInit1.enable       = usartDisable;   /* Don't enable UART upon intialization */
  uartInit1.refFreq      = 0;              /* Provide information on reference frequency. When set to 0, the reference frequency is */
  uartInit1.baudrate     = 57600;          /* Baud rate */
  uartInit1.oversampling = usartOVS16;     /* Oversampling. Range is 4x, 6x, 8x or 16x */
  uartInit1.databits     = usartDatabits8; /* Number of data bits. Range is 4 to 10 */
  uartInit1.parity       = usartNoParity;  /* Parity mode */
  uartInit1.stopbits     = usartStopbits1; /* Number of stop bits. Range is 0 to 2 */
  uartInit1.mvdis        = false;          /* Disable majority voting */
  uartInit1.prsRxEnable  = false;          /* Enable USART Rx via Peripheral Reflex System */
  uartInit1.prsRxCh      = usartPrsRxCh0;  /* Select PRS channel if enabled */

  USART_InitAsync(uart1, &uartInit1);

  USART_IntClear(uart1, _USART_IFC_MASK);
  USART_IntEnable(uart1, USART_IEN_RXDATAV);
  NVIC_ClearPendingIRQ(USART1_RX_IRQn);
  NVIC_ClearPendingIRQ(USART1_TX_IRQn);
  NVIC_EnableIRQ(USART1_RX_IRQn);
  NVIC_EnableIRQ(USART1_TX_IRQn);
  uart1->ROUTEPEN = (USART_ROUTEPEN_RXPEN | USART_ROUTEPEN_TXPEN);
  uart1->ROUTELOC0 = (USART_ROUTELOC0_TXLOC_LOC13 | USART_ROUTELOC0_RXLOC_LOC13);
  USART_Enable(uart1, usartEnable);

  uart1_driver_analysis_state = 0;
  uart1_driver_analysis_cnt = 0;
}

uint8_t uart0_driver_get_char(void)
{
  uint8_t ch;

  /* Check if there is a byte that is ready to be fetched. If no byte is ready, wait for incoming data */
  if (rxBuf0.pendingBytes < 1)
  {
    while (rxBuf0.pendingBytes < 1) ;
  }

  /* Copy data from buffer */
  ch        = rxBuf0.data[rxBuf0.rdI];
  rxBuf0.rdI = (rxBuf0.rdI + 1) % BUFFERSIZE;

  /* Decrement pending byte counter */
  rxBuf0.pendingBytes--;

  return ch;
}

void uart0_driver_put_char(uint8_t ch)
{
  /* Check if Tx queue has room for new data */
  if ((txBuf0.pendingBytes + 1) > BUFFERSIZE)
  {
    /* Wait until there is room in queue */
    while ((txBuf0.pendingBytes + 1) > BUFFERSIZE) ;
  }

  /* Copy ch into txBuffer */
  txBuf0.data[txBuf0.wrI] = ch;
  txBuf0.wrI              = (txBuf0.wrI + 1) % BUFFERSIZE;

  /* Increment pending byte counter */
  txBuf0.pendingBytes++;

  /* Enable interrupt on USART TX Buffer*/
  USART_IntEnable(uart0, USART_IEN_TXBL);
}

uint32_t uart0_driver_get_data(uint8_t * dataPtr, uint32_t dataLen)
{
  uint32_t i = 0;

  /* Wait until the requested number of bytes are available */
  if (rxBuf0.pendingBytes < dataLen)
  {
    while (rxBuf0.pendingBytes < dataLen) ;
  }

  if (dataLen == 0)
  {
    dataLen = rxBuf0.pendingBytes;
  }

  /* Copy data from Rx buffer to dataPtr */
  while (i < dataLen)
  {
    *(dataPtr + i) = rxBuf0.data[rxBuf0.rdI];
    rxBuf0.rdI     = (rxBuf0.rdI + 1) % BUFFERSIZE;
    i++;
  }

  /* Decrement pending byte counter */
  rxBuf0.pendingBytes -= dataLen;

  return i;
}

void uart0_driver_put_data(uint8_t * dataPtr, uint32_t dataLen)
{
  uint32_t i = 0;

  /* Check if buffer is large enough for data */
  if (dataLen > BUFFERSIZE)
  {
    /* Buffer can never fit the requested amount of data */
    return;
  }

  /* Check if buffer has room for new data */
  if ((txBuf0.pendingBytes + dataLen) > BUFFERSIZE)
  {
    /* Wait until room */
    while ((txBuf0.pendingBytes + dataLen) > BUFFERSIZE) ;
  }

  /* Fill dataPtr[0:dataLen-1] into txBuffer */
  while (i < dataLen)
  {
    txBuf0.data[txBuf0.wrI] = *(dataPtr + i);
    txBuf0.wrI              = (txBuf0.wrI + 1) % BUFFERSIZE;
    i++;
  }

  /* Increment pending byte counter */
  txBuf0.pendingBytes += dataLen;

  /* Enable interrupt on USART TX Buffer*/
  USART_IntEnable(uart0, USART_IEN_TXBL);
}

uint8_t uart1_driver_get_char( )
{
  uint8_t ch;

  /* Check if there is a byte that is ready to be fetched. If no byte is ready, wait for incoming data */
  if (rxBuf1.pendingBytes < 1)
  {
    while (rxBuf1.pendingBytes < 1) ;
  }

  /* Copy data from buffer */
  ch        = rxBuf1.data[rxBuf1.rdI];
  rxBuf1.rdI = (rxBuf1.rdI + 1) % BUFFERSIZE;

  /* Decrement pending byte counter */
  rxBuf1.pendingBytes--;

  return ch;
}

void uart1_driver_put_char(uint8_t ch)
{
  /* Check if Tx queue has room for new data */
  if ((txBuf1.pendingBytes + 1) > BUFFERSIZE)
  {
    /* Wait until there is room in queue */
    while ((txBuf1.pendingBytes + 1) > BUFFERSIZE) ;
  }

  /* Copy ch into txBuffer */
  txBuf1.data[txBuf1.wrI] = ch;
  txBuf1.wrI             = (txBuf1.wrI + 1) % BUFFERSIZE;

  /* Increment pending byte counter */
  txBuf1.pendingBytes++;

  /* Enable interrupt on USART TX Buffer*/
  USART_IntEnable(uart1, USART_IEN_TXBL);
}

uint32_t uart1_driver_get_data(uint8_t * dataPtr, uint32_t dataLen)
{
  uint32_t i = 0;

  /* Wait until the requested number of bytes are available */
  if (rxBuf1.pendingBytes < dataLen)
  {
    while (rxBuf1.pendingBytes < dataLen) ;
  }

  if (dataLen == 0)
  {
    dataLen = rxBuf1.pendingBytes;
  }

  /* Copy data from Rx buffer to dataPtr */
  while (i < dataLen)
  {
    *(dataPtr + i) = rxBuf1.data[rxBuf1.rdI];
    rxBuf1.rdI      = (rxBuf1.rdI + 1) % BUFFERSIZE;
    i++;
  }

  /* Decrement pending byte counter */
  rxBuf1.pendingBytes -= dataLen;

  return i;
}

void uart1_driver_put_data(uint8_t * dataPtr, uint32_t dataLen)
{
  uint32_t i = 0;

  /* Check if buffer is large enough for data */
  if (dataLen > BUFFERSIZE)
  {
    /* Buffer can never fit the requested amount of data */
    return;
  }

  /* Check if buffer has room for new data */
  if ((txBuf1.pendingBytes + dataLen) > BUFFERSIZE)
  {
    /* Wait until room */
    while ((txBuf1.pendingBytes + dataLen) > BUFFERSIZE) ;
  }

  /* Fill dataPtr[0:dataLen-1] into txBuffer */
  while (i < dataLen)
  {
    txBuf1.data[txBuf1.wrI] = *(dataPtr + i);
    txBuf1.wrI              = (txBuf1.wrI + 1) % BUFFERSIZE;
    i++;
  }

  /* Increment pending byte counter */
  txBuf1.pendingBytes += dataLen;

  /* Enable interrupt on USART TX Buffer*/
  USART_IntEnable(uart1, USART_IEN_TXBL);
}

void USART0_RX_IRQHandler(void)
{
  /* Check for RX data valid interrupt */
  if (uart0->IF & USART_IF_RXDATAV)
  {
    /* Copy data into RX Buffer */
    uint8_t rxData = USART_Rx(uart0);
    rxBuf0.data[rxBuf0.wrI] = rxData;
    rxBuf0.wrI             = (rxBuf0.wrI + 1) % BUFFERSIZE;
    rxBuf0.pendingBytes++;

    /* Flag Rx overflow */
    if (rxBuf0.pendingBytes > BUFFERSIZE)
    {
      rxBuf0.overflow = true;
    }
  }
}

void USART0_TX_IRQHandler(void)
{
  /* Check TX buffer level status */
  if (uart0->IF & USART_IF_TXBL)
  {
    if (txBuf0.pendingBytes > 0)
    {
      /* Transmit pending character */
      USART_Tx(uart0, txBuf0.data[txBuf0.rdI]);
      txBuf0.rdI = (txBuf0.rdI + 1) % BUFFERSIZE;
      txBuf0.pendingBytes--;
    }

    /* Disable Tx interrupt if no more bytes in queue */
    if (txBuf0.pendingBytes == 0)
    {
      USART_IntDisable(uart0, USART_IEN_TXBL);
    }
  }
}

void USART1_RX_IRQHandler(void)
{
  /* Check for RX data valid interrupt */
  if (uart1->IF & USART_IF_RXDATAV)
  {
    /* Copy data into RX Buffer */
    uint8_t rxData = USART_Rx(uart1);
    rxBuf1.data[rxBuf1.wrI] = rxData;
    rxBuf1.wrI             = (rxBuf1.wrI + 1) % BUFFERSIZE;
    rxBuf1.pendingBytes++;

    /* Flag Rx overflow */
    if (rxBuf1.pendingBytes > BUFFERSIZE)
    {
      rxBuf1.overflow = true;
    }

    //uart0_driver_put_char(rxData);
    //gpio_test_uart();
    uart1_driver_analysis(rxData);
    //uart1_driver_analysis2(rxData);
  }
}

void USART1_TX_IRQHandler(void)
{
  /* Check TX buffer level status */
  if (uart1->IF & USART_IF_TXBL)
  {
    if (txBuf1.pendingBytes > 0)
    {
      /* Transmit pending character */
      USART_Tx(uart1, txBuf1.data[txBuf1.rdI]);
      txBuf1.rdI = (txBuf1.rdI + 1) % BUFFERSIZE;
      txBuf1.pendingBytes--;
    }

    /* Disable Tx interrupt if no more bytes in queue */
    if (txBuf1.pendingBytes == 0)
    {
      USART_IntDisable(uart1, USART_IEN_TXBL);
    }
  }
}
