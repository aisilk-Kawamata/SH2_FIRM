/*
 * uart_driver.h
 *
 *  Created on: 2017/05/08
 *      Author: D-CLUE
 */

#ifndef UART_DRIVER_H_
#define UART_DRIVER_H_

extern void uart0_driver_init(void);
extern uint8_t uart0_driver_get_char(void);
extern void uart0_driver_put_char(uint8_t ch);
extern uint32_t uart0_driver_get_data(uint8_t * dataPtr, uint32_t dataLen);
extern void uart0_driver_put_data(uint8_t * dataPtr, uint32_t dataLen);

extern void uart1_driver_init(void);
extern uint8_t uart1_driver_get_char(void);
extern void uart1_driver_put_char(uint8_t ch);
extern uint32_t uart1_driver_get_data(uint8_t * dataPtr, uint32_t dataLen);
extern void uart1_driver_put_data(uint8_t * dataPtr, uint32_t dataLen);

extern void spi0_driver_init(void);

#endif /* UART_DRIVER_H_ */
